# Widyartha — Product Requirements Document
**Versi:** 1.2.0  
**Terakhir diperbarui:** Juli 2026  
**Status:** Draft — In Review  

---

## Daftar Isi

1. [Ringkasan Produk](#1-ringkasan-produk)
2. [Target Pengguna](#2-target-pengguna)
3. [Arsitektur Sistem](#3-arsitektur-sistem)
4. [Stack Teknologi](#4-stack-teknologi)
5. [Fitur Utama](#5-fitur-utama)
6. [AI-Powered API Connector](#6-ai-powered-api-connector)
7. [Manajemen Channel](#7-manajemen-channel)
8. [AI & LLM Layer](#8-ai--llm-layer)
9. [Manajemen Tim & Sesi](#9-manajemen-tim--sesi)
10. [Data Produk & Koneksi DB](#10-data-produk--koneksi-db)
11. [Payment Gateway](#11-payment-gateway)
12. [Analytics & Reporting](#12-analytics--reporting)
13. [Role & Akses](#13-role--akses)
14. [Skema Database](#14-skema-database)
15. [Alur Kerja Pesan](#15-alur-kerja-pesan)
16. [Model Lisensi](#16-model-lisensi)
17. [Roadmap](#17-roadmap)
18. [Risiko & Mitigasi](#18-risiko--mitigasi)

---

## 1. Ringkasan Produk

**Widyartha** adalah platform customer service berbasis AI yang berjalan sepenuhnya secara lokal (_local-first_) di infrastruktur milik pelanggan. Tidak ada data pelanggan yang keluar dari jaringan mereka.

### Proposisi Nilai Utama

- **Data sovereignty penuh** — semua pemrosesan terjadi on-premise, tidak ada data keluar jaringan lokal
- **AI-first, bukan rule-based** — AI memahami konteks natural language, bukan if-else berlapis
- **Universal API Connector** — upload Postman Collection / OpenAPI dari sistem manapun, AI langsung bisa menggunakannya tanpa coding
- **Multi-channel terpadu** — WhatsApp, Telegram, Facebook Messenger, Web Widget dalam satu inbox
- **Ringan & efisien** — berjalan di Raspberry Pi 4/5 (8GB RAM) atau PC lama
- **Tanpa biaya per-pesan** — Ollama lokal sebagai default, cloud LLM sebagai opsional
- **Single command deploy** — satu `docker compose up` langsung jalan

### Paradigma: AI sebagai Universal Connector

> Widyartha bukan chatbot rule-based. AI-nya bertindak sebagai agen cerdas yang memahami pertanyaan customer dalam bahasa natural, memutuskan tool/API mana yang harus dipanggil, mengeksekusi, dan merangkai jawaban — semua secara otomatis.

```
RULE-BASED (kompetitor):
"ongkir" → template ongkir
"stok"   → template stok
❌ Kaku, tidak kontekstual

widyartha (tool calling AI):
"kak mau beli 2 pcs produk A dikirim ke Surabaya bisa transfer?"
  → AI paham konteks
  → panggil: GET /products?name=A       (dari collection toko)
  → panggil: GET /inventory/SKU-A       (dari collection toko)
  → panggil: POST /shipping/calculate   (dari collection toko)
  → panggil: GET /payment/methods       (dari collection toko)
  → rangkai jawaban lengkap
✅ Natural, fleksibel, kontekstual
```

### Prinsip Desain

> Setiap keputusan stack dievaluasi terhadap batasan RPi 4/5 (8GB RAM). Bila ragu, potong layanannya. AI adaptasi ke sistem customer — bukan sebaliknya.

---

## 2. Target Pengguna

### Segmen Utama

**UMKM Indonesia** dengan karakteristik:
- Volume pesan WhatsApp/Telegram tinggi setiap hari
- Tim CS kecil (1–5 orang)
- Sudah punya sistem/API sendiri (ERP, toko online, DB) yang ingin dihubungkan
- Tidak memiliki tim IT khusus untuk integrasi kompleks
- Sensitif terhadap biaya langganan SaaS per-bulan atau per-pesan
- Ingin kendali penuh atas data customer

### Persona Pengguna

| Persona | Deskripsi | Kebutuhan Utama |
|---|---|---|
| **Pemilik Toko** | Owner UMKM, non-teknis | Setup mudah, AI langsung paham sistem mereka |
| **Admin Toko** | Staf senior, kelola sistem | Upload collection, kelola CS, lihat analytics |
| **CS Agent** | Staf CS harian | Balas chat, eskalasi, AI bantu jawab otomatis |
| **Developer Toko** | IT internal customer | Export collection dari sistem mereka, upload ke Widyartha |

### Competitive Positioning

| | Mekari Qontak | ManyChat | **Widyartha** |
|---|---|---|---|
| Data lokal (on-premise) | ❌ Cloud | ❌ Cloud | ✅ Lokal penuh |
| Rule-based vs AI | Rule-based | Rule-based | ✅ Tool calling AI |
| Integrasi API custom | Manual, berbayar | Terbatas | ✅ Upload collection |
| Harga | Mahal + per pesan | Sedang | Terjangkau |
| Bahasa Indonesia | ✅ | ⚠️ | ✅ via Ollama |
| Kontrol data | ❌ | ❌ | ✅ Penuh |

**Celah unik Widyartha:** Satu-satunya platform CS di Indonesia yang memungkinkan AI terhubung ke sistem/API customer hanya dengan upload collection — tanpa coding, tanpa rule mapping, tanpa pindah data.

---

## 3. Arsitektur Sistem

```
┌─────────────────────────────────────────────────────────┐
│                 Widyartha Dashboard                    │
│          React (Vite) + Tailwind CSS + shadcn/ui         │
│                served by Express (static)                │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP REST / WebSocket (Socket.io)
            ┌────────────▼────────────┐
            │     Express Backend      │
            │  - REST API              │
            │  - WebSocket (chat)      │
            │  - Tool Loader           │ ← dynamic tool dari collection
            │  - LLM abstraction layer │
            │  - Session manager       │
            │  - Escalation handler    │
            │  - Message router        │
            │  - Scheduler (node-cron) │
            └──┬──────────┬───────────┘
               │          │
      ┌─────────▼──┐  ┌───▼────────────────────────────────┐
      │   Ollama   │  │        Channel Adapter Layer        │
      │ qwen2.5:3b │  │     (built-in, dalam Express)       │
      │  (default) │  │                                     │
      └────────────┘  │  whatsapp.adapter.js  (Baileys)     │
                      │  telegram.adapter.js               │
                      │  messenger.adapter.js (FB)          │
                      │  web.adapter.js       (Widget)      │
                      └────────────────────────────────────┘
                                   │
                      ┌────────────▼────────────┐
                      │  Tool Execution Engine   │
                      │  - Built-in tools        │
                      │  - Dynamic tools         │ ← dari API collections
                      │    (REST API / DB / dll) │
                      └────────────┬────────────┘
                                   │
                      ┌────────────▼────────────┐
                      │      SQLite (file)       │
                      │  - sessions & messages   │
                      │  - users & roles         │
                      │  - channel config        │
                      │  - llm_configs           │
                      │  - ai_memory             │
                      │  - products (fallback)   │
                      │  - api_collections       │ ← NEW
                      │  - generated_tools       │ ← NEW
                      │  - payment_configs       │
                      │  - app_settings          │
                      └─────────────────────────┘
```

### Prinsip Arsitektur

- **Monolitik Express** — satu service serve API + frontend build statis
- **SQLite** — satu file database, zero konfigurasi
- **Channel Adapter Pattern** — setiap channel adalah modul adapter di dalam Express
- **Tool Calling AI** — Ollama dengan tool definitions, bukan rule-based keyword matching
- **Dynamic Tool Loading** — tools di-generate dari API collections yang diupload user, dimuat saat runtime
- **Ollama sebagai fallback lokal** — jika cloud LLM gagal, otomatis fallback ke model lokal
- **Tanpa n8n** — semua workflow CS diimplementasikan langsung di Express

---

## 4. Stack Teknologi

### Docker Compose Services

```yaml
services:
  backend:  # Express API backend
  frontend: # React + Vite (di-serve via Nginx)
  ollama:   # Local LLM inference
  # SQLite = file-based, ada di dalam backend/data
  # Total: 3 services aktif (konfigurasi saat ini)
```

### Estimasi Penggunaan RAM (RPi 5, 8GB)

| Service | RAM |
|---|---|
| Frontend (Nginx/React) | ~50 MB |
| Backend (Express) | ~150 MB |
| Ollama + qwen2.5:3b | ~2.000 MB |
| OS + buffer | ~1.000 MB |
| **Total** | **~3.200 MB** |
| **Sisa headroom** | **~4.800 MB** |

### Model LLM Rekomendasi

| Model | Tool Calling | RAM | Rekomendasi |
|---|---|---|---|
| **qwen2.5:3b** | ✅ Sangat baik | ~2GB | ⭐ Default Widyartha |
| **llama3.2:3b** | ✅ Baik | ~2GB | Alternatif solid |
| gemma2:2b | ⚠️ Terbatas | ~1.5GB | Tidak direkomendasikan |
| mistral:7b | ✅ Sangat baik | ~4.5GB | Terlalu berat untuk RPi |

### Frontend

- **React** (Vite) — SPA
- **Tailwind CSS** — utility-first styling
- **shadcn/ui** — komponen UI langsung di project
- **React Query** — data fetching & caching
- **Zustand** — state management ringan
- **Socket.io-client** — real-time chat inbox
- **Axios** — HTTP client

### Backend

- **Node.js / Express** — API server + serve static frontend
- **better-sqlite3** — SQLite driver sinkronus
- **Socket.io** — WebSocket untuk live inbox
- **Baileys** — WhatsApp Web API
- **node-telegram-bot-api** — Telegram Bot API resmi
- **messenger-flow** — Facebook Messenger API resmi
- **node-cron** — scheduler broadcast & jadwal pesan
- **bcrypt** — hash password
- **jsonwebtoken** — autentikasi JWT
- **AES-256** (Node.js crypto) — enkripsi credentials di SQLite

---

## 5. Fitur Utama

### 5.1 Dashboard Utama

- Statistik harian: total chat, ditangani AI, eskalasi ke CS, average response time
- Daftar percakapan aktif real-time
- Feed aktivitas terkini
- Status tiap channel dan connector aktif

### 5.2 Unified Inbox

- Semua percakapan dari semua channel dalam satu tampilan real-time
- **Human vs AI Toggle** per sesi — CS bisa ambil alih atau serahkan ke AI
- Filter channel, status, agent
- Panel info customer (nama, channel, history, tag, memory AI)
- Quick reply templates
- Tag & kategori percakapan
- Typing indicator real-time

### 5.3 AI Assistant di Dashboard

- Chat dengan AI langsung dari dashboard
- AI bisa bantu setup sistem, analisis collection yang diupload, troubleshooting
- AI tahu konteks sistem yang aktif (channel, connector, konfigurasi)

---

## 6. AI-Powered API Connector

### 6.1 Konsep

Fitur inti yang membedakan Widyartha dari semua kompetitor. Admin cukup upload API collection dari sistem mereka — AI membaca, memahami semua endpoint, dan otomatis menjadikannya tool yang bisa dipanggil saat chat dengan customer.

**AI adaptasi ke sistem customer — bukan sebaliknya.**

### 6.2 Format Collection yang Didukung

| Format | Cara Import |
|---|---|
| **Postman Collection v2.0 / v2.1** | Upload file JSON |
| **OpenAPI 3.0 / Swagger 2.0** | Upload file JSON/YAML atau paste URL |
| **cURL command** | Paste langsung, AI parse otomatis |
| **Plain JSON manual** | Definisikan endpoint sendiri via form |

### 6.3 Alur Import Collection

```
1. Admin buka: Connectors → Import Collection
2. Upload file JSON (Postman / OpenAPI) atau paste cURL
3. AI membaca seluruh collection:
   - Identifikasi semua endpoint
   - Pahami method, URL, params, body, headers
   - Generate deskripsi natural language per endpoint
   - Buat tool definition format Ollama
4. Preview: Admin lihat daftar tools yang akan di-generate
5. Konfigurasi:
   - Base URL (bisa beda dari collection)
   - Auth: API Key / Bearer Token / Basic Auth
   - Variable substitution ({{api_key}}, {{base_url}}, dll)
6. Klik "Aktifkan" → tools tersimpan di SQLite
7. AI langsung bisa menggunakan semua tools itu
```

### 6.4 Contoh: Upload Collection Toko

Admin upload `toko_maju_api.json` (Postman Collection):

```
Collection berisi:
  GET  /products              → list semua produk
  GET  /products/{id}         → detail produk
  GET  /inventory/{sku}       → cek stok by SKU
  GET  /orders/{order_id}     → detail pesanan
  POST /orders                → buat pesanan baru
  POST /shipping/calculate    → hitung ongkir
  GET  /payment/methods       → metode pembayaran tersedia
  GET  /customers/{id}        → profil customer
```

AI generate tools otomatis:

```javascript
// Auto-generated dari collection — tidak perlu coding
tools = [
  {
    name: 'get_products',
    description: 'Ambil daftar produk yang tersedia di toko',
    parameters: { search: 'string?', category: 'string?' }
  },
  {
    name: 'check_stock',
    description: 'Cek ketersediaan stok produk berdasarkan SKU',
    parameters: { sku: 'string (required)' }
  },
  {
    name: 'get_order_detail',
    description: 'Cek status dan detail pesanan berdasarkan nomor order',
    parameters: { order_id: 'string (required)' }
  },
  {
    name: 'calculate_shipping',
    description: 'Hitung biaya ongkir ke kota tujuan',
    parameters: { destination: 'string', weight: 'number', courier: 'string?' }
  },
  // ... semua endpoint lain
]
```

### 6.5 Contoh Percakapan Setelah Collection Aktif

```
Customer: "kak mau nanya stok produk sepatu ukuran 42 masih ada?"

AI (internal):
  → panggil: get_products({ search: "sepatu" })
  → hasil: [{ id: 12, name: "Sepatu Sport", sku: "SPT-42", ... }]
  → panggil: check_stock({ sku: "SPT-42" })
  → hasil: { stock: 8, available: true }

AI (ke customer):
  "Halo! Sepatu ukuran 42 masih tersedia, stok ada 8 pasang. 
   Mau langsung order atau ada pertanyaan lain?"

---

Customer: "pesanan saya #ORD-2847 sudah sampai mana?"

AI (internal):
  → panggil: get_order_detail({ order_id: "ORD-2847" })
  → hasil: { status: "shipped", courier: "JNE", resi: "JNE123XXX", eta: "besok" }

AI (ke customer):
  "Pesanan #ORD-2847 sedang dalam pengiriman via JNE 
   dengan resi JNE123XXX, estimasi tiba besok."

---

Customer: "ongkir ke Medan berapa kalau beli 2 pcs?"

AI (internal):
  → panggil: get_products({ search: "produk yang dimaksud" })
  → hasil: [{ weight_gram: 500, ... }]
  → panggil: calculate_shipping({ destination: "Medan", weight: 1000 })
  → hasil: [{ courier: "JNE", price: 35000 }, { courier: "J&T", price: 28000 }]

AI (ke customer):
  "Ongkir ke Medan untuk 2 pcs (total 1kg):
   - JNE: Rp 35.000 (estimasi 3-4 hari)
   - J&T: Rp 28.000 (estimasi 2-3 hari)"
```

### 6.6 Multi-Collection Support

Admin bisa install lebih dari satu collection sekaligus:

```
Connector Store (aktif):
├── ✅ Toko Maju API         → 8 tools (produk, stok, pesanan, ongkir)
├── ✅ RajaOngkir API        → 3 tools (cek ongkir, lacak resi, cek kota)
├── ✅ Midtrans API          → 2 tools (buat transaksi, cek status bayar)
└── ✅ ERP Internal          → 5 tools (dari OpenAPI mereka)
```

AI memiliki semua tools dari semua connector yang aktif — memutuskan sendiri mana yang relevan untuk tiap pertanyaan customer.

### 6.7 Built-in Tools (selalu tersedia)

Selain dynamic tools dari collection, ada tools bawaan sistem:

| Tool | Fungsi |
|---|---|
| `get_products_local` | Baca katalog produk dari SQLite Widyartha (fallback) |
| `escalate_to_cs` | Eskalasi percakapan ke CS manusia |
| `save_customer_memory` | Simpan konteks customer ke ai_memory |
| `get_operating_hours` | Cek jam operasional dari app_settings |
| `send_payment_link` | Generate link pembayaran dari gateway aktif |

### 6.8 Keamanan Connector

- Credentials API (key, token, password) disimpan terenkripsi AES-256 di SQLite
- Semua request dari Tool Execution Engine dilakukan server-side (tidak expose ke frontend)
- Admin bisa set whitelist domain — hanya URL tertentu yang boleh dipanggil
- Log semua tool call tersimpan di SQLite untuk audit

### 6.9 Antarmuka Linter & Preview (Validasi & Simulasi)

- **Validasi Otomatis (Linter)**: Sistem backend akan mendeteksi hasil ekstraksi API dan memberikan bendera peringatan (flag) pada endpoint yang memiliki deskripsi AI yang terlalu singkat, tipe data ambigu, atau berisiko tinggi (seperti modifikasi data via POST/PUT/DELETE).
- **Editor Tool Interaktif**: Admin memiliki kebebasan untuk menyortir, mengaktifkan, atau menonaktifkan endpoint tertentu. Terdapat field teks untuk merevisi instruksi natural language AI secara manual jika hasil generate otomatis kurang spesifik.
- **Test Drive (Simulasi)**: Disediakan antarmuka obrolan mini di halaman preview agar Admin bisa menguji apakah AI berhasil memanggil tool yang tepat sebelum collection tersebut diaktifkan di production.

---

## 7. Manajemen Channel

### Konsep: Channel Store

Channel dikelola seperti inventori digital — admin browse, aktifkan, dan konfigurasi dari dashboard. Semua diimplementasikan sebagai adapter module di dalam Express.

```
Channel Store
├── ✅ v1.0 — Tersedia
│   ├── WhatsApp (Baileys — tidak resmi, risiko ToS dikomunikasikan)
│   ├── Telegram (API resmi — gratis, setup 5 menit)
│   └── Web Chatbot Widget (embeddable script)
├── ⬇️ v1.5 — Segera
│   ├── Facebook Messenger (API resmi Meta — gratis)
│   └── Email (SMTP/IMAP)
└── 🔜 v2.0 — Roadmap
    ├── Instagram DM (API resmi Meta)
    ├── Line
    └── Discord
```

### Risiko per Channel

| Channel | API | Risiko Ban | Biaya | Kemudahan |
|---|---|---|---|---|
| **Telegram** | Resmi | Tidak ada | Gratis | ⭐⭐⭐⭐⭐ |
| **Web Widget** | Internal | Tidak ada | Gratis | ⭐⭐⭐⭐⭐ |
| **FB Messenger** | Resmi Meta | Tidak ada | Gratis | ⭐⭐⭐⭐ |
| **WhatsApp** (Baileys) | Tidak resmi | ⚠️ Ada | Gratis | ⭐⭐⭐⭐ |
| **Instagram DM** | Resmi Meta | Tidak ada | Gratis | ⭐⭐ (approval lama) |

### Pengaturan Global Channel

- **Jam operasional** — per channel atau global
- **Di luar jam kerja** — AI full handle, auto-reply, atau nonaktifkan
- **Bahasa** — auto-detect atau paksa bahasa tertentu

---

## 8. AI & LLM Layer

### 8.1 Abstraction Layer

```javascript
// llm.service.js — interface tunggal, provider bisa diganti bebas
class LLMService {
  async chat(messages, tools, config) {
    switch (config.provider) {
      case 'ollama':   return this.callOllama(messages, tools, config)
      case 'claude':   return this.callAnthropic(messages, tools, config)
      case 'openai':   return this.callOpenAI(messages, tools, config)
      case 'gemini':   return this.callGemini(messages, tools, config)
      default:         return this.callOllama(messages, tools, config)
    }
  }
}
```

### 8.2 Provider yang Didukung

| Provider | Model Default | Mode |
|---|---|---|
| **Ollama** (default & fallback) | qwen2.5:3b | Lokal, offline, selalu tersedia |
| **Anthropic Claude** | claude-sonnet-4-6 | Cloud API |
| **OpenAI** | gpt-4o | Cloud API |
| **Google Gemini** | gemini-1.5-flash | Cloud API |

### 8.3 Fallback Chain

```
Provider utama (misal: Claude)
  │ gagal / kuota habis / timeout
  ▼
Fallback 1 (misal: OpenAI)  [opsional]
  │ gagal
  ▼
Ollama lokal (tidak bisa dimatikan — always available)
```

### 8.4 Tool Calling Flow

```
Customer kirim pesan
  │
  ▼
LLM Service
  │ siapkan: system prompt + ai_memory + tools (built-in + dynamic dari collections)
  │ kirim ke Ollama/cloud provider
  ▼
AI response
  ├── Jawaban langsung → kirim ke customer
  └── Tool call request → Tool Execution Engine
        │ eksekusi tool (query SQLite / call external API)
        │ kembalikan hasil ke AI
        ▼
      AI rangkai jawaban final → kirim ke customer
```

### 8.5 AI Memory per Customer

- Setiap customer punya konteks percakapan tersimpan di `ai_memory`
- AI diberi ringkasan memory setiap percakapan baru — tidak perlu mengulang info
- Kedalaman memory: configurable (default: 10 sesi terakhir)
- Retensi: configurable (default: 90 hari)
- Reset manual dari dashboard

### 8.6 Konfigurasi dari Dashboard

- Pilih provider & model aktif
- Input API key (terenkripsi AES-256)
- Confidence threshold (default: 75%) — di bawahnya auto-eskalasi ke CS
- System prompt / persona AI
- Fallback chain

### 8.7 System Guardrails (Aturan Sistem)
- **Definisi:** Aturan ketat anti-halusinasi yang disisipkan secara paksa di tingkat kode (bukan sekadar prompt persona)
- **Penyimpanan:** Disimpan dalam tabel `system_rules`
- **Manajemen:** Hanya dapat diatur (tambah/edit/hapus/aktifkan) oleh **Super Admin** via Dashboard (AI & LLM Config)
- **Tujuan:** Mencegah model kecil (seperti 3B) mengarang data produk atau menjawab hal yang tidak ada dalam hasil *tool calling*.

### 8.8 Fallback Parser Tool Calling
- Karena model kecil sering membocorkan tag XML mentah (seperti `<tool_name>...</tool_name>` atau `<tool_call>...</tool_call>`) ke dalam chat teks, backend LLM Service dilengkapi parser bawaan.
- Jika API Ollama tidak mendeteksi `tool_calls` terstruktur namun teksnya memuat pola pemanggilan tool, parser akan mengekstrak perintah tersebut, mengeksekusinya secara tak kasat mata, dan membersihkan sisa kode XML dari pesan yang sampai ke pengguna.

---

## 9. Manajemen Tim & Sesi

### 9.1 Role

| Role | Kemampuan |
|---|---|
| **Super Admin** | Akses penuh semua menu dan konfigurasi |
| **Admin** | Kelola CS, channel, connector, produk, lihat analytics |
| **CS Agent** | Inbox (sesi assigned), balas pesan, lihat profil customer |

### 9.2 Session Lock

- Saat AI eskalasi → assign satu CS spesifik ke percakapan
- Hanya CS yang di-assign yang bisa reply — CS lain read-only
- Admin bisa override assignment
- Sesi selesai: CS klik "Selesaikan" atau timeout (default: 30 menit)

### 9.3 Metode Assignment

| Metode | Deskripsi |
|---|---|
| **Round-robin** | Giliran merata ke semua CS online |
| **Beban kerja** | Prioritas ke CS dengan sesi paling sedikit |
| **Manual** | Admin assign dari dashboard |

### 9.4 Notifikasi Eskalasi

- Push notifikasi real-time di dashboard (WebSocket)
- Opsional: notifikasi ke CS via WhatsApp/Telegram yang aktif

---

## 10. Data Produk & Koneksi DB

### 10.1 Hierarki Sumber Data Produk

Widyartha membaca data produk dari beberapa sumber dengan prioritas:

```
1. API Collection (prioritas tertinggi) 
   → data real-time dari sistem customer
2. Koneksi DB Eksternal (MySQL/PostgreSQL/MongoDB)
   → sync berkala atau real-time
3. Import File (Excel/CSV)
   → upload manual
4. Input Manual (form dashboard)
   → fallback terakhir
```

### 10.2 Import Produk

| Metode | Format | Keterangan |
|---|---|---|
| API Collection | Postman / OpenAPI | Real-time via tool calling |
| Koneksi database | MySQL, PostgreSQL, MongoDB | Sync berkala |
| Upload file | Excel (.xlsx), CSV (.csv) | Dengan template download |
| Google Sheets | URL sheet | Auto-sync |
| Input manual | Form dashboard | Satu per satu |

### 10.3 CRUD Katalog

- Tambah, edit, hapus produk
- Search & pagination
- Import massal dengan validasi format
- Setiap produk otomatis masuk knowledge base AI

### 10.4 Database Connector berbasis "Schema-Only Mapping" (Untuk Baca Data)

- **Zero Data Duplication**: Data produk dari pelanggan tidak akan di-copy ke SQLite internal. SQLite hanya bertindak sebagai penyimpan referensi atau aturan pemetaan (mapping config), menjaga sistem tetap ringan.
- **AI-Assisted Schema Mapping**: Backend akan membaca struktur tabel (MySQL/PostgreSQL) dan AI akan memberikan rekomendasi pemetaan (misal: menebak tabel `tbl_barang` sebagai katalog). Admin hanya perlu meninjau dan mengonfirmasi.
- **Parameterized Query Engine (Keamanan)**: AI tidak akan pernah menulis raw query (Text-to-SQL). Saat berjalan, backend menggunakan hasil pemetaan untuk merakit parameterized query yang aman, lalu mengeksekusinya untuk mendapatkan data real-time tanpa risiko SQL Injection.

### 10.5 Transaksi, Order, dan Local Ledger

Sistem Widyartha memisahkan antara data operasional (Order) dengan data keuangan (Local Ledger):

- **Otomatisasi Pesanan (AI Closing)**: AI dapat mendeteksi niat pembelian, mengumpulkan data pesanan (item, alamat, kurir), dan menyimpan data tersebut sebagai **Draft Order** di dalam database lokal.
- **Manajemen Pesanan (Accept Order)**: Admin memiliki menu **Orders** di dashboard untuk meninjau pesanan. Admin dapat menyetujui (Accept) atau menolak (Reject) pesanan tersebut.
- **Penagihan (Invoice)**: Ketika pesanan di-Accept, sistem secara otomatis menerbitkan **Invoice** dan AI akan menginstruksikan pelanggan untuk melakukan pembayaran (termasuk transfer manual).
- **Local Ledger (Buku Besar Keuangan)**: Berbeda dengan Order yang melacak status pengiriman barang, **Local Ledger** khusus melacak mutasi kas (uang masuk/keluar). Entri ledger akan dicatat otomatis hanya *setelah* admin memverifikasi pembayaran (misal: verifikasi bukti transfer manual).
- **Manual Sync Pipeline**: Pesanan yang sudah lunas (Paid) dapat disinkronisasi ke database/ERP eksternal pelanggan melalui pemetaan skema.

---

## 11. Payment Gateway & Manual Payment

Widyartha mendukung pembayaran otomatis dan manual:

### 11.1 Manual Payment (Transfer Bank / E-Wallet)
- **Pengaturan Dinamis**: Admin dapat mengatur daftar rekening bank atau e-wallet yang aktif melalui menu **Settings > Payment Methods**.
- **Injeksi AI**: Data rekening aktif ini otomatis diinjeksikan ke dalam persona AI, sehingga AI selalu memberikan instruksi dan nomor rekening yang tepat kepada pelanggan.
- **Verifikasi Bukti Transfer (Image Proof)**: Pelanggan dapat mengirimkan foto resi/bukti transfer via WhatsApp/Telegram. Sistem akan mengunduh gambar, menautkannya ke data *Order/Invoice* terkait, dan menampilkannya di Dashboard Admin untuk diverifikasi secara manual.
- **AI Vision (Opsional)**: Dukungan pembacaan teks (OCR) pada bukti transfer oleh AI untuk merekomendasikan verifikasi ke Admin.

### 11.2 Payment Gateway Otomatis
| Provider | Keterangan |
|---|---|
| **Midtrans** | Populer di Indonesia, multi-payment |
| **Xendit** | Virtual account, e-wallet, kartu kredit |
| **Doku** | Virtual account, transfer bank |

- Konfigurasi Sandbox / Production
- Credentials terenkripsi AES-256
- AI bisa generate link pembayaran via tool `send_payment_link`

---

## 12. Analytics & Reporting

### Metrik

| Kategori | Metrik |
|---|---|
| **Volume** | Total chat per hari/minggu/bulan, per channel |
| **AI Performance** | % resolved AI, % eskalasi, confidence avg, tool calls per sesi |
| **Tool Usage** | Tool mana yang paling sering dipanggil AI |
| **CS Performance** | Avg response time, durasi sesi, sesi per CS |
| **Connector Health** | Success rate tiap API connector, error rate |
| **Customer** | Satisfaction score, repeat customers |

---

## 13. Role & Akses

| Fitur | Super Admin | Admin | CS Agent |
|---|---|---|---|
| Dashboard stats | ✅ | ✅ | ✅ terbatas |
| Inbox semua | ✅ | ✅ | ❌ |
| Inbox milik sendiri | ✅ | ✅ | ✅ |
| Balas pesan | ✅ | ✅ | ✅ sesi assigned |
| Toggle AI/Human | ✅ | ✅ | ✅ |
| **API Connector / Collections** | ✅ | ✅ | ❌ |
| AI Config | ✅ | ❌ | ❌ |
| Channel Config | ✅ | ✅ | ❌ |
| Kelola produk | ✅ | ✅ | ❌ |
| Payment config | ✅ | ❌ | ❌ |
| Tambah/hapus CS | ✅ | ✅ | ❌ |
| Analytics penuh | ✅ | ✅ | ❌ |
| Analytics diri | ✅ | ✅ | ✅ |
| Settings sistem | ✅ | ❌ | ❌ |

---

## 14. Skema Database

```sql
-- Pengguna sistem
CREATE TABLE users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  email         TEXT UNIQUE NOT NULL,
  password      TEXT NOT NULL,              -- bcrypt hash
  role          TEXT NOT NULL DEFAULT 'cs',             -- 'super_admin'|'admin'|'cs'
  channels      TEXT DEFAULT '[]',                      -- JSON array
  max_sessions  INTEGER DEFAULT 5,
  status        TEXT DEFAULT 'offline',
  avatar        TEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Konfigurasi channel
CREATE TABLE channels (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  type          TEXT NOT NULL,             -- 'whatsapp'|'telegram'|'messenger'|'web'
  name          TEXT NOT NULL,
  is_active     INTEGER DEFAULT 0,
  credentials   TEXT,                      -- JSON terenkripsi AES-256
  config        TEXT DEFAULT '{}',                      -- JSON (jam operasional, dll)
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Customer
CREATE TABLE customers (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT,
  phone         TEXT,
  channel_ref   TEXT,                      -- nomor WA / username TG / PSID FB
  channel_type  TEXT,
  tags          TEXT DEFAULT '[]',                      -- JSON array
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Sesi percakapan
CREATE TABLE sessions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id    INTEGER REFERENCES channels(id),
  customer_id   INTEGER REFERENCES customers(id),
  assigned_cs   INTEGER REFERENCES users(id),
  mode          TEXT DEFAULT 'ai',         -- 'ai'|'human'
  status        TEXT DEFAULT 'active',     -- 'active'|'waiting'|'done'
  tags          TEXT DEFAULT '[]',
  started_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  ended_at      DATETIME,
  escalated_at  DATETIME,
  lock_expires  DATETIME,
  last_message  TEXT,
  last_message_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Pesan
CREATE TABLE messages (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER REFERENCES sessions(id),
  sender_type   TEXT NOT NULL,             -- 'customer'|'ai'|'cs'|'system'
  sender_id     INTEGER,
  content       TEXT NOT NULL,
  tool_calls    TEXT,                      -- JSON log tool yang dipanggil AI
  is_read       INTEGER DEFAULT 0,
  sent_at       DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Memory AI per customer
CREATE TABLE ai_memory (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id   INTEGER REFERENCES customers(id) UNIQUE,
  summary       TEXT,
  preferences   TEXT DEFAULT '{}',
  last_updated  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- API Collections yang diupload
CREATE TABLE api_collections (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,             -- 'Toko Maju API'
  description   TEXT,
  format        TEXT NOT NULL,             -- 'postman'|'openapi'|'curl'|'manual'
  raw_content   TEXT NOT NULL,             -- JSON/YAML original
  base_url      TEXT,
  auth_type     TEXT DEFAULT 'none',                      -- 'api_key'|'bearer'|'basic'|'none'
  auth_config   TEXT,                      -- JSON terenkripsi AES-256
  is_active     INTEGER DEFAULT 0,
  tool_count    INTEGER DEFAULT 0,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tools yang di-generate dari collections (atau built-in)
CREATE TABLE generated_tools (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  collection_id   INTEGER REFERENCES api_collections(id),
  name            TEXT NOT NULL,           -- 'check_stock'
  display_name    TEXT,                    -- 'Cek Stok Produk'
  description     TEXT NOT NULL,          -- deskripsi untuk AI
  tool_definition TEXT NOT NULL,          -- JSON schema format Ollama
  endpoint        TEXT,                   -- URL template
  method          TEXT DEFAULT 'GET',
  headers         TEXT DEFAULT '{}',                   -- JSON
  body_template   TEXT,                   -- JSON template dengan {variable}
  is_active       INTEGER DEFAULT 1,
  is_builtin      INTEGER DEFAULT 0,
  linter_warnings TEXT DEFAULT '[]',
  risk_level      TEXT DEFAULT 'low',
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Log eksekusi tool (untuk analytics & audit)
CREATE TABLE tool_call_logs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER REFERENCES sessions(id),
  tool_id       INTEGER REFERENCES generated_tools(id),
  tool_name     TEXT NOT NULL,
  arguments     TEXT,                      -- JSON args yang dikirim AI
  result        TEXT,                      -- JSON hasil
  status        TEXT,                      -- 'success'|'error'|'timeout'
  duration_ms   INTEGER,
  called_at     DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Konfigurasi LLM
CREATE TABLE llm_configs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT,
  provider      TEXT NOT NULL,
  model         TEXT NOT NULL,
  api_key       TEXT,                      -- terenkripsi AES-256
  base_url      TEXT,
  is_active     INTEGER DEFAULT 0,
  is_fallback   INTEGER DEFAULT 0,
  priority      INTEGER DEFAULT 0,
  threshold     INTEGER DEFAULT 75,
  system_prompt TEXT,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- System Rules (Guardrails / Anti-halusinasi)
CREATE TABLE system_rules (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  rule_text     TEXT NOT NULL,
  is_active     INTEGER DEFAULT 1,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Katalog produk (fallback jika tidak ada API collection)
CREATE TABLE products (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  sku           TEXT,
  category      TEXT,
  price         REAL,
  stock         INTEGER DEFAULT 0,
  description   TEXT,
  image_url     TEXT,
  source        TEXT DEFAULT 'manual',
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Payment gateway
CREATE TABLE payment_configs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  provider      TEXT NOT NULL,
  environment   TEXT DEFAULT 'sandbox',
  credentials   TEXT,                      -- JSON terenkripsi AES-256
  is_active     INTEGER DEFAULT 0,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Pengaturan global
CREATE TABLE app_settings (
  key           TEXT PRIMARY KEY,
  value         TEXT,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Pengaturan Rekening Manual
CREATE TABLE manual_payment_methods (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  bank_name     TEXT NOT NULL,
  account_no    TEXT NOT NULL,
  account_name  TEXT NOT NULL,
  is_active     INTEGER DEFAULT 1,
  instructions  TEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Transaksi: Orders (Operasional)
CREATE TABLE orders (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER REFERENCES sessions(id),
  customer_id   INTEGER REFERENCES customers(id),
  total_amount  REAL,
  status        TEXT DEFAULT 'pending', -- 'pending', 'accepted', 'paid', 'shipped', 'cancelled'
  shipping_address TEXT,
  payment_proof_url TEXT,               -- Link gambar resi transfer
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Detail Item Pesanan
CREATE TABLE order_items (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id      INTEGER REFERENCES orders(id),
  product_id    INTEGER REFERENCES products(id),
  product_name  TEXT NOT NULL,
  product_sku   TEXT,
  quantity      INTEGER NOT NULL DEFAULT 1,
  unit_price    REAL NOT NULL,
  subtotal      REAL NOT NULL
);

-- Transaksi: Invoices (Tagihan)
CREATE TABLE invoices (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id      INTEGER REFERENCES orders(id),
  invoice_number TEXT UNIQUE NOT NULL,
  amount_due    REAL,
  status        TEXT DEFAULT 'unpaid', -- 'unpaid', 'paid', 'void'
  issued_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
  paid_at       DATETIME
);

-- Local Ledger (Keuangan)
CREATE TABLE local_ledger (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  type          TEXT NOT NULL,         -- 'debit' (masuk), 'credit' (keluar)
  amount        REAL NOT NULL,
  description   TEXT,
  reference_id  TEXT                   -- Misalnya 'INV-001' atau 'ORD-102'
);

-- Sales Backup (Untuk Sync Database Eksternal)
CREATE TABLE sales_backup (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id      INTEGER REFERENCES orders(id),
  sync_status   TEXT DEFAULT 'pending_sync',
  sync_target   TEXT,
  sync_mapping  TEXT,
  sync_attempts INTEGER DEFAULT 0,
  synced_at     DATETIME,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  notes         TEXT
);

-- DB Connector mappings (schema-only)
CREATE TABLE db_connectors (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  db_type       TEXT NOT NULL,
  host          TEXT,
  port          INTEGER,
  database_name TEXT,
  credentials   TEXT,
  schema_cache  TEXT,
  mapping_config TEXT,
  is_active     INTEGER DEFAULT 0,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Quick reply templates
CREATE TABLE quick_replies (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  title         TEXT NOT NULL,
  content       TEXT NOT NULL,
  category      TEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

---

## 15. Alur Kerja Pesan

### Pesan Masuk dengan Tool Calling

```
Customer kirim pesan
  │
  ▼
Channel Adapter (Baileys / Telegram / Messenger / Web)
  │
  ▼
Message Router
  ├── Sesi baru → buat session, mode: AI
  └── Sesi existing → cek mode
        ├── Human → teruskan ke assigned CS via Socket.io
        └── AI → teruskan ke LLM Service
  │
  ▼ (mode AI)
Tool Loader
  │ muat semua active tools:
  │   - built-in tools
  │   - generated_tools dari api_collections aktif
  ▼
LLM Service
  │ kirim: system_prompt + ai_memory + tools + pesan customer
  ▼
AI Response
  ├── Jawaban langsung
  │     → simpan ke messages → kirim ke customer
  │
  └── Tool call(s)
        │
        ▼
      Tool Execution Engine
        │ eksekusi tool:
        │   REST API call ke endpoint collection
        │   atau query built-in (SQLite, payment, dll)
        │ catat ke tool_call_logs
        │ kembalikan hasil ke AI
        ▼
      AI rangkai jawaban final
        → simpan ke messages → kirim ke customer
  │
  ▼
Evaluasi confidence
  ├── ≥ threshold → selesai
  └── < threshold → Escalation Handler
        │ assign CS (round-robin / beban / manual)
        │ update session mode → 'human'
        ▼
      Notifikasi ke CS (Socket.io + opsional WA/TG)
```

---

## 16. Model Lisensi

| Tier | Harga | CS Agent | Channel | Connector | AI Provider |
|---|---|---|---|---|---|
| **Trial** | Gratis 14 hari | 1 | 1 | 1 collection | Ollama saja |
| **Basic** | Rp 299.000/bln | 3 | 2 | 3 collections | Ollama + 1 cloud |
| **Pro** | Rp 699.000/bln | 10 | 5 | Unlimited | Semua provider |
| **Enterprise** | Custom | Unlimited | Unlimited | Unlimited | Semua + SLA |

Lisensi divalidasi secara lokal — tidak memerlukan koneksi internet untuk verifikasi harian.

---

## 17. Roadmap

### v1.0 — Core Platform + Tool Calling (Target: Q3 2026)

- [x] Docker Compose: Frontend, Backend Express + Ollama (3 service)
- [x] Auth: JWT, role-based (Super Admin, Admin, CS)
- [x] Unified Inbox real-time (WebSocket)
- [x] Channel: Telegram + Web Widget (WhatsApp segera)
- [x] **AI Tool Calling** — Ollama dengan tool definitions (qwen2.5:3b)
- [x] **API Collection Import** — Postman Collection v2.1
- [x] **Dynamic Tool Generation** dari collection
- [x] **Tool Execution Engine** — REST API caller
- [x] Built-in tools: cek_produk, eskalasi, memory, jam_operasional
- [x] AI memory per customer
- [x] LLM abstraction layer: Ollama + Claude + OpenAI + Gemini
- [ ] Fallback chain LLM
- [ ] Import produk via Excel/CSV
- [x] Session lock & assignment CS
- [ ] Payment gateway: Midtrans, Xendit, Doku
- [x] Dashboard analytics + tool usage stats
- [ ] AI Assistant di dashboard
- [x] Enkripsi AES-256 semua credentials
- [x] Local Ledger / Sales Backup
- [x] Skema koneksi DB eksternal (DB Connector)

### v1.5 — Extended Connectors (Target: Q4 2026)

- [ ] Import OpenAPI 3.0 / Swagger
- [ ] Import via cURL paste
- [ ] DB Connector langsung (MySQL, PostgreSQL, MongoDB, Google Sheets)
- [ ] Channel: Facebook Messenger + Email
- [ ] Broadcast terjadwal (node-cron)
- [ ] Tool call logs & analytics detail
- [ ] Connector health monitoring
- [ ] Quick reply templates
- [ ] Export laporan Excel/CSV
- [ ] Webhook outbound

### v2.0 — Intelligence & Scale (Target: Q1 2027)

- [ ] Channel: Instagram DM, Line, Discord
- [ ] GraphQL connector support
- [ ] Multi-tenant
- [ ] Mobile app CS agent
- [ ] WhatsApp Business API resmi (opsi premium)
- [ ] Community connector marketplace

---

## 18. Risiko & Mitigasi

| Risiko | Dampak | Mitigasi |
|---|---|---|
| WhatsApp ban nomor (Baileys) | Tinggi | Informasikan risiko saat setup, sarankan nomor terpisah, sediakan recovery guide |
| AI memanggil tool yang salah | Tinggi | Tool description yang jelas, log semua tool calls, confidence threshold |
| API eksternal customer berubah / down | Sedang | Error handling graceful, fallback ke produk lokal SQLite, alert ke admin |
| Credentials API customer bocor | Tinggi | AES-256, tidak expose di log/frontend, whitelist domain |
| Overload RAM di RPi | Tinggi | Monitor RAM di dashboard, batasi concurrent sessions, dokumentasi min specs |
| SQLite corruption saat power loss | Sedang | WAL mode, backup harian otomatis |
| AI hallucinate data produk | Sedang | Tool calling ke API real → tidak bergantung pengetahuan model, data selalu dari sumber asli |
| Customer data regulasi UU PDP | Sedang | Local-first compliant, fitur export & hapus data on-request |

---

*Dokumen ini adalah referensi hidup — diperbarui seiring perkembangan produk.*  
*Versi 1.2.0 — Tambah: AI-Powered API Connector, Tool Calling, Dynamic Tool Generation dari Postman/OpenAPI Collection.*
*Versi 1.3.0 — Tambah: Manajemen Order, Invoice, Local Ledger, dan Konfigurasi Manual Payment.*
