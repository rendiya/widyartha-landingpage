# Simulasi Order Barang via Widyartha

Berikut adalah simulasi percakapan antara Pelanggan (Customer) dan AI Agent Widyartha untuk menguji alur pemesanan barang hingga proses pembayaran dan konfirmasi menggunakan produk bawaan (fallback) toko.

## Skenario: Pembelian Produk "Sepatu Sport A"

### 1. Inisiasi Percakapan & Tanya Produk
**Customer:** "Halo, saya lagi cari sepatu sport buat olahraga nih, ada rekomendasi yang ready?"
**AI Agent:** *(Memanggil tool: `get_products` dengan kategori: 'Sepatu')* 
"Halo kak! Kami merekomendasikan **Sepatu Sport A**. Sepatu ini sangat nyaman untuk olahraga sehari-hari (ukuran 42). Harganya Rp 250.000. Apakah kakak tertarik dengan sepatu ini?"

### 2. Cek Stok / Ketersediaan
**Customer:** "Boleh deh, saya mau order 1 pasang ukuran 42. Masih ada barangnya kan?"
**AI Agent:** *(Memanggil tool: `check_availability`)* 
"Masih kak! Saat ini stoknya tersisa 8 pasang dan siap dikirim hari ini. Untuk proses pemesanan, boleh dibantu informasikan **nama penerima**, **alamat lengkap**, dan **nomor HP** aktif kakak?"

### 3. Pengumpulan Data Order
**Customer:** "Atas nama Budi, alamat Jl. Sudirman No 123, Jakarta. HP: 081234567890"
**AI Agent:** 
"Terima kasih kak Budi. Pesanannya saya proses ya."
*(Memanggil tool: `create_order`)*
"Pesanan dengan nomor **#ORD-7742** telah berhasil dibuat untuk 1x Sepatu Sport A. Total tagihannya adalah **Rp 250.000**."

### 4. Pembayaran (Payment Link)
**AI Agent:** *(Memanggil tool: `send_payment_link`)*
"Silakan lakukan pembayaran senilai **Rp 250.000** ke rekening BCA 1234567890 a/n Widyartha. Jika sudah transfer, mohon kirimkan bukti transfernya di sini ya kak."

### 5. Pengiriman Bukti Transfer
**Customer:** *(Mengirimkan gambar bukti transfer)* "Sudah saya transfer ya kak."

![Bukti Transfer Simulasi](./bukti_transfer.png)

### 6. Proses di Local Ledger (Pending Sync)
**AI Agent:** "Terima kasih! Bukti transfer telah kami terima dan sedang diproses. Mohon ditunggu sebentar ya kak, pesanan akan segera diproses setelah pembayaran diverifikasi admin."
*(Sistem di backend menyimpan order ini ke dalam SQLite Local Ledger dengan status `pending_sync`)*

### 7. Verifikasi oleh Admin (Manual Sync)
Pada tahap ini, percakapan untuk sementara selesai di sisi AI.
- Admin Widyartha membuka menu **Local Ledger** (`/ledger`) di Dashboard.
- Admin melihat Order **#ORD-7742** dengan status `⏳ Pending Sync`.
- Admin memeriksa kecocokan bukti transfer yang dilampirkan pelanggan.
- Admin mengklik tombol **Approve & Sync**.
- *(Backend Widyartha mengeksekusi insert data pesanan ke database utama / sinkronisasi stok)*.

### 8. Penyelesaian
**Sistem / AI:** *(Otomatis mengirim pesan lanjutan ke pelanggan)* 
"Pembayaran untuk order **#ORD-7742** telah berhasil diverifikasi! 🎉 Pesanan Sepatu Sport A kakak sedang dalam tahap pengemasan dan akan segera dikirim. Terima kasih telah berbelanja!"
