# Widyartha - Progress Task

Berdasarkan implementasi sebelumnya dan sinkronisasi dengan PRD, berikut adalah status pengembangan proyek Widyartha saat ini:

## 🟢 Selesai (Completed)

### Infrastruktur & Deployment
- [x] Docker Compose: Setup 3 service (`backend` Express, `frontend` Nginx/Vite, dan `ollama`) untuk single-command deploy.
- [x] Konfigurasi variabel environment (`.env` dan `docker-compose.yml`).

### Backend (Node.js/Express)
- [x] Inisialisasi proyek dan struktur arsitektur.
- [x] Konfigurasi SQLite (`better-sqlite3` dengan mode WAL):
  - Skema lengkap sesuai PRD 100% (Tabel Users, Channels, Customers, Sessions, Messages, AI Memory, API Collections, Tools, LLM Configs, Products, Ledger, App Settings, System Rules, dll).
  - Skrip *seed* data awal (super admin, LLM default, produk dummy, rule anti-halusinasi).
- [x] Autentikasi JWT & Enkripsi (AES-256).
- [x] Layanan Inti (*Core Services*):
  - `collectionParser.service.js`: AI-Powered API Connector (Ekstrak JSON/Postman menjadi Ollama tools).
  - `llm.service.js`: AI Inference layer, tool calling loop, fallback, dan system guardrails.
  - Penuh mendukung integrasi API Google Gemini (Google AI Studio) dengan Tool Calling dan System Prompt (Status: Done, Untested).
- [x] Routing & Endpoint APIs (`/api/*`):
  - `connectors.js`: Upload dan manajemen API Collection.
  - `llm.js`: Konfigurasi provider AI (Ollama, OpenAI, dll).
  - `channels.js`: Manajemen channel komunikasi.
  - `users.js`: Manajemen agen CS dan peran.
  - `products.js`: Katalog produk lokal.
  - `analytics.js`: Metrik dan statistik dashboard.
  - `settings.js`: Pengaturan aplikasi global (jam operasional, batas confidence).
  - `ledger.js`: Antarmuka Staging/Buffer (Local Ledger) untuk order sync.
  - `dbConnector.js`: Skema mapping database eksternal (Schema-only).
  - `inbox.js`: Manajemen data percakapan.
- [x] Real-time Messaging (Socket.io) & Session.
- [x] Channel Adapter:
  - `telegram.js` terimplementasi penuh.

### Frontend (React/Vite)
- [x] Inisialisasi Vite + React + Tailwind + shadcn/ui.
- [x] Setup Global CSS (`index.css`) dengan desain premium & dark mode.
- [x] Konfigurasi Axios & API Interceptors (`api.js`).
- [x] Layout & Sidebar Navigation (`Layout.jsx`).
- [x] Halaman-halaman UI (*Completed Pages*):
  - `LoginPage.jsx`: Autentikasi.
  - `DashboardPage.jsx`: Overview statistik dan mini-chat AI.
  - `InboxPage.jsx`: Unified inbox dengan toggle AI/Human.
  - `ConnectorsPage.jsx`: Linter & preview tools untuk API Collection.
  - `LedgerPage.jsx`: Review pesanan (Local Ledger) sebelum sync.
  - `AnalyticsPage.jsx`: Visualisasi grafik.
  - `UsersPage.jsx`: Kelola agen.
  - `LLMPage.jsx`: Atur koneksi Ollama dan system rules.
  - `ProductsPage.jsx`: Tabel katalog produk.
  - `ChannelsPage.jsx`: Pengaturan channel (WA, Telegram, Web).
  - `DBConnectorPage.jsx`: Pemetaan tabel skema eksternal.
  - `SettingsPage.jsx`: Pengaturan operasional toko.

## 🟡 Sedang Berjalan / Perlu Disempurnakan (In Progress / To Do)

### Testing & Debugging Frontend
- [ ] Memastikan HMR (Hot Module Replacement) Vite berjalan mulus (sebelumnya ada error di `main.jsx`/`index.html` pada browser testing).
- [ ] Validasi navigasi dan flow end-to-end (memastikan komponen UI terhubung sempurna dengan backend API).

### Pembaruan Skema Database (PRD v1.3.0)
- [x] Update skema SQLite backend (tambah tabel `orders`, `invoices`, `order_items`, dan `manual_payment_methods`).
- [x] Fix duplikasi invoice (sebelumnya dibuat ganda: saat AI create_order DAN saat admin Accept).
- [x] Implementasi Hybrid order flow: AI langsung buat order+invoice, admin verify/cancel.
- [x] Stok otomatis berkurang saat order, dikembalikan saat cancel.
- [ ] Refaktor logika `sales_backup` untuk mendukung arsitektur *Local Ledger* yang baru.

### Integrasi Eksternal & Channels
- [ ] Implementasi konkret adapter channel **WhatsApp** (menggunakan library Baileys).
- [ ] Implementasi *executor* konkret untuk konektor database eksternal (menjalankan query ter-parameter ke MySQL/Postgres sungguhan).
- [ ] Menambahkan dukungan untuk upload format *OpenAPI/Swagger*.

## 🔴 Belum Dimulai (Not Started)
- [ ] **Upload Bukti Transfer (Image Proof)**: Penerimaan gambar bukti transfer via WhatsApp/Telegram dan menautkannya ke order terkait.
- [ ] **Notifikasi Post-Payment**: Kirim pesan otomatis ke customer via channel setelah admin verify payment.
- [ ] **Multi-Product Order**: Support order beberapa produk berbeda sekaligus.
- [ ] **Fix LedgerPage**: Arahkan LedgerPage ke tabel `local_ledger` bukan `sales_backup`.
- [ ] Fallback chain perpindahan model LLM otomatis jika provider utama down.
- [ ] Integrasi Payment Gateway Otomatis (Midtrans, Xendit, Doku).
- [ ] Fitur broadcast pesan massal / broadcast terjadwal.
- [ ] Unit testing / E2E Testing komprehensif.

