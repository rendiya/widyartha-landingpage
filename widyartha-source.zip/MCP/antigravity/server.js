import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8088;
const envPath = path.join(__dirname, '.env');

// Locate Widyartha SQLite Database
const possibleDbPaths = [
  process.env.DB_PATH,
  path.resolve(__dirname, 'widyartha.db'),
  path.resolve(__dirname, 'data/widyartha.db'),
  path.resolve(__dirname, '../../backend/data/widyartha.db'),
  path.resolve(__dirname, '../../backend/widyartha.db'),
  path.resolve(process.cwd(), 'widyartha.db'),
  path.resolve(process.cwd(), 'backend/data/widyartha.db'),
].filter(Boolean);

let dbPath = possibleDbPaths.find((p) => fs.existsSync(p));
let db = null;

if (dbPath) {
  try {
    db = new Database(dbPath);
    db.pragma('journal_mode = WAL');
    console.log(`[Database] SQLite DB loaded from: ${dbPath}`);
  } catch (err) {
    console.error(`[Database] Error loading SQLite:`, err.message);
  }
} else {
  console.log('[Database] Info: SQLite database not found yet. Using local smart fallback.');
}

// Auto-Generate Local API Key if missing
let defaultKey = process.env.GEMINI_API_KEY || '';

if (!defaultKey || defaultKey === 'YOUR_GEMINI_API_KEY_HERE') {
  const generatedLocalToken = 'sk-agv-' + crypto.randomBytes(16).toString('hex');
  let envContent = '';
  if (fs.existsSync(envPath)) {
    envContent = fs.readFileSync(envPath, 'utf8');
    if (envContent.includes('GEMINI_API_KEY=')) {
      envContent = envContent.replace(/GEMINI_API_KEY=.*/g, `GEMINI_API_KEY=${generatedLocalToken}`);
    } else {
      envContent += `\nGEMINI_API_KEY=${generatedLocalToken}\n`;
    }
  } else {
    envContent = `PORT=${PORT}\nGEMINI_API_KEY=${generatedLocalToken}\n`;
  }
  try {
    fs.writeFileSync(envPath, envContent, 'utf8');
    process.env.GEMINI_API_KEY = generatedLocalToken;
    defaultKey = generatedLocalToken;
  } catch (_) {}
}

// Model Mapping Table matching Antigravity IDE Models
const MODEL_MAP = {
  'antigravity': 'gemini-3.6-flash-medium',
  'default': 'gemini-3.6-flash-medium',
  'gemini-3.6-flash': 'gemini-3.6-flash-medium',
  'gemini-3.6-flash-high': 'gemini-3.6-flash-high',
  'gemini-3.6-flash-medium': 'gemini-3.6-flash-medium',
  'gemini-3.6-flash-low': 'gemini-3.6-flash-low',
  'gemini-3.5-flash-high': 'gemini-3.5-flash-high',
  'gemini-3.5-flash-medium': 'gemini-3.5-flash-medium',
  'gemini-3.5-flash-low': 'gemini-3.5-flash-low',
  'gemini-3.1-pro-high': 'gemini-3.1-pro-high',
  'gemini-3.1-pro-low': 'gemini-3.1-pro-low',
  'claude-sonnet-4.6': 'claude-sonnet-4.6',
  'claude-opus-4.6': 'claude-opus-4.6',
  'gpt-oss-120b': 'gpt-oss-120b',
  'gpt-4o-mini': 'gemini-3.6-flash-medium',
  'gpt-4o': 'gemini-3.1-pro-high',
};

// Available Models List matching Antigravity IDE UI
const STATIC_MODELS = [
  { id: 'antigravity', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Antigravity Default Model' },
  { id: 'gemini-3.6-flash-high', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.6 Flash (High)' },
  { id: 'gemini-3.6-flash-medium', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.6 Flash (Medium)' },
  { id: 'gemini-3.6-flash-low', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.6 Flash (Low)' },
  { id: 'gemini-3.5-flash-high', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.5 Flash (High)' },
  { id: 'gemini-3.5-flash-medium', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.5 Flash (Medium)' },
  { id: 'gemini-3.5-flash-low', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.5 Flash (Low)' },
  { id: 'gemini-3.1-pro-high', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.1 Pro (High)' },
  { id: 'gemini-3.1-pro-low', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Gemini 3.1 Pro (Low)' },
  { id: 'claude-sonnet-4.6', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Claude Sonnet 4.6 (Thinking)' },
  { id: 'claude-opus-4.6', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'Claude Opus 4.6 (Thinking)' },
  { id: 'gpt-oss-120b', object: 'model', created: 1700000000, owned_by: 'antigravity', description: 'GPT-OSS 120B (Medium)' },
];

// Helper: Query Database for Context Enrichment (Full MCP Bridge)
function getMcpContextForPrompt(userPrompt) {
  if (!db) return '';
  const promptLower = userPrompt.toLowerCase();
  let contextParts = [];

  try {
    // 1. Check Product Search / Stock
    if (promptLower.includes('stok') || promptLower.includes('stock') || promptLower.includes('produk') || promptLower.includes('product') || promptLower.includes('harga') || promptLower.includes('price')) {
      const products = db.prepare('SELECT name, price, stock, description FROM products LIMIT 10').all();
      if (products.length > 0) {
        contextParts.push(`[Widyartha Product & Stock Data]:\n` + JSON.stringify(products, null, 2));
      }
    }

    // 2. Check Order Info
    const orderMatch = promptLower.match(/order\s*#?(\d+)/i) || promptLower.match(/pesanan\s*#?(\d+)/i);
    if (orderMatch) {
      const orderId = orderMatch[1];
      const order = db.prepare(`
        SELECT o.*, c.name as customer_name, c.phone as customer_phone
        FROM orders o LEFT JOIN customers c ON o.customer_id = c.id
        WHERE o.id = ?
      `).get(orderId);
      if (order) {
        order.items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
        contextParts.push(`[Order #${orderId} Details]:\n` + JSON.stringify(order, null, 2));
      }
    }

    // 3. Knowledge / Rules
    if (promptLower.includes('rule') || promptLower.includes('aturan') || promptLower.includes('policy') || promptLower.includes('kebijakan')) {
      const rules = db.prepare('SELECT rule_text FROM system_rules WHERE is_active = 1').all();
      if (rules.length > 0) {
        contextParts.push(`[Widyartha CS System Rules]:\n` + rules.map(r => r.rule_text).join('\n'));
      }
    }
  } catch (err) {
    console.error('[MCP Helper Error]:', err.message);
  }

  return contextParts.join('\n\n');
}

// GET /v1/models - List models endpoint
app.get('/v1/models', async (req, res) => {
  res.json({ object: 'list', data: STATIC_MODELS });
});

// POST /v1/chat/completions - Full Antigravity + MCP OpenAI Bridge Endpoint
app.post('/v1/chat/completions', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    let apiKey = defaultKey;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      apiKey = authHeader.substring(7).trim();
    }

    const { model = 'antigravity', messages = [], temperature = 0.7, max_tokens, stream = false } = req.body;
    const targetModel = MODEL_MAP[model.toLowerCase()] || model;

    const userMessages = messages.filter((m) => m.role === 'user');
    const lastUserPrompt = userMessages[userMessages.length - 1]?.content || '';

    // Retrieve Data Context from MCP Database automatically
    const mcpData = getMcpContextForPrompt(lastUserPrompt);
    console.log(`[Full Bridge] Model: "${model}" | MCP Context Data Found: ${mcpData ? 'YES' : 'NO'}`);

    // If API Key is a local / generated token
    if (!apiKey || !apiKey.startsWith('AIzaSy')) {
      let replyText = `Hello! Thank you for reaching out to Widyartha Customer Support.\n\nYour Message: "${lastUserPrompt}"`;

      if (mcpData) {
        replyText += `\n\n🔍 Information from Widyartha Database:\n${mcpData}`;
      } else {
        replyText += `\n\n💡 (Tip: Provide a valid GEMINI_API_KEY in .env to enable full interactive cloud LLM completions).`;
      }

      if (stream) {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        const chunkResponse = {
          id: `chatcmpl-${Date.now()}`,
          object: 'chat.completion.chunk',
          created: Math.floor(Date.now() / 1000),
          model,
          choices: [{ index: 0, delta: { content: replyText }, finish_reason: null }],
        };
        res.write(`data: ${JSON.stringify(chunkResponse)}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
        return;
      }

      return res.json({
        id: `chatcmpl-${Date.now()}`,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model,
        choices: [
          {
            index: 0,
            message: {
              role: 'assistant',
              content: replyText,
            },
            finish_reason: 'stop',
          },
        ],
        usage: {
          prompt_tokens: 15,
          completion_tokens: 35,
          total_tokens: 50,
        },
      });
    }

    // If official AIzaSy... API Key is set, forward to Google Gemini API with MCP data enrichment!
    const systemMessages = messages.filter((m) => m.role === 'system');
    const userAndAssistantMessages = messages.filter((m) => m.role !== 'system');

    let systemText = systemMessages.map((m) => m.content).join('\n\n');
    if (mcpData) {
      systemText += `\n\n[WIDYARTHA LOCAL DATABASE & DOCUMENTS]:\n${mcpData}`;
    }

    const systemInstruction = systemText ? { parts: [{ text: systemText }] } : undefined;

    const contents = userAndAssistantMessages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }],
    }));

    const generationConfig = {
      temperature,
      ...(max_tokens ? { maxOutputTokens: max_tokens } : {}),
    };

    const payload = {
      contents,
      ...(systemInstruction ? { systemInstruction } : {}),
      generationConfig,
    };

    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${targetModel}:generateContent?key=${apiKey}`;
    const apiRes = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await apiRes.json();
    const replyText = data.candidates?.[0]?.content?.parts?.[0]?.text || JSON.stringify(data);

    res.json({
      id: `chatcmpl-${Date.now()}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      model,
      choices: [
        {
          index: 0,
          message: {
            role: 'assistant',
            content: replyText,
          },
          finish_reason: 'stop',
        },
      ],
    });
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({
      error: {
        message: error.message || 'Internal Server Error',
        type: 'server_error',
      },
    });
  }
});

const serverInstance = app.listen(PORT, () => {
  console.log(`
🚀 Antigravity Full MCP + OpenAI Bridge Server Running!
   - Base URL  : http://localhost:${PORT}/v1
   - Features  : OpenAI REST API + MCP SQLite Database Integration (Stock, Orders, Invoices)
  `);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`\nℹ️ Port ${PORT} is already in use by a running Antigravity server instance.`);
    console.log(`👉 Server is READY at http://localhost:${PORT}/v1 - You can run your client scripts directly!\n`);
  } else {
    console.error('Server error:', err);
  }
});
