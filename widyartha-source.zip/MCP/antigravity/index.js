import 'dotenv/config';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';

// Pure Local MCP Server for Antigravity IDE (Zero API Key Needed)
const server = new Server(
  {
    name: 'antigravity-mcp-server',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Define Local Tools provided to Antigravity IDE
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: 'get_system_info',
        description: 'Retrieves local system information (OS Platform, Node version, memory, & uptime) for Antigravity Agent.',
        inputSchema: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'echo_tool',
        description: 'Local test tool for verifying MCP Server connectivity with Antigravity IDE.',
        inputSchema: {
          type: 'object',
          properties: {
            message: { type: 'string', description: 'Message to echo back' },
          },
          required: ['message'],
        },
      },
    ],
  };
});

// Process Tool Execution from Antigravity IDE
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  if (name === 'get_system_info') {
    const info = {
      platform: process.platform,
      arch: process.arch,
      nodeVersion: process.version,
      memoryUsage: process.memoryUsage(),
      uptime: process.uptime(),
      cwd: process.cwd(),
    };

    return {
      content: [{ type: 'text', text: JSON.stringify(info, null, 2) }],
    };
  }

  if (name === 'echo_tool') {
    const { message } = args || {};
    return {
      content: [{ type: 'text', text: `Echo from Local MCP Server: ${message}` }],
    };
  }

  throw new Error(`Tool ${name} not found`);
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('🚀 Antigravity MCP Server running on Stdio (Zero API Key Needed)');
}

main().catch((err) => {
  console.error('Fatal error starting MCP Server:', err);
  process.exit(1);
});
