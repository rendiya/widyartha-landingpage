#!/usr/bin/env bash
CD="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$CD"

if [ ! -d "node_modules" ]; then
    echo "[Info] node_modules not found. Auto-installing dependencies..."
    npm install
fi

echo "======================================================="
echo "🚀 Starting Antigravity OpenAI-Compatible API Server..."
echo "======================================================="
node server.js
