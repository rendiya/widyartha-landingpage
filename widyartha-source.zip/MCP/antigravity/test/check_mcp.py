import sys
import os
import json
import subprocess

# Ensure UTF-8 output encoding for Windows terminal compatibility
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

def main():
    print("==================================================")
    print("[CHECKER] MCP Server Health & Protocol Checker (Python)")
    print("==================================================\n")

    test_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.abspath(os.path.join(test_dir, ".."))
    index_js_path = os.path.join(root_dir, "index.js")

    if not os.path.exists(index_js_path):
        print(f"[ERROR] File not found: {index_js_path}")
        sys.exit(1)

    print(f"MCP Root Directory : {root_dir}")
    print(f"Starting subprocess : node index.js\n")

    # Start MCP Server subprocess over stdio
    process = subprocess.Popen(
        ["node", "index.js"],
        cwd=root_dir,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding='utf-8',
        bufsize=1
    )

    def send_request(req):
        json_str = json.dumps(req)
        process.stdin.write(json_str + "\n")
        process.stdin.flush()

    def read_response():
        line = process.stdout.readline()
        if not line:
            return None
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            return line

    try:
        # Step 1: Send 'initialize'
        init_req = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "python-mcp-checker", "version": "1.0.0"}
            }
        }
        print("[1] Sending 'initialize' request...")
        send_request(init_req)
        init_res = read_response()
        print("    [OK] Initialized Response:")
        print("   ", json.dumps(init_res, indent=2))
        print()

        # Step 2: Send 'notifications/initialized'
        initialized_notification = {
            "jsonrpc": "2.0",
            "method": "notifications/initialized"
        }
        send_request(initialized_notification)

        # Step 3: Send 'tools/list'
        tools_req = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/list",
            "params": {}
        }
        print("[2] Sending 'tools/list' request...")
        send_request(tools_req)
        tools_res = read_response()
        tools = tools_res.get("result", {}).get("tools", []) if isinstance(tools_res, dict) else []

        print(f"    [OK] Found {len(tools)} Tool(s):")
        for tool in tools:
            print(f"       - [{tool.get('name')}] : {tool.get('description')}")
        print()

        # Step 4: Test Tool Call 'echo_tool'
        echo_req = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "echo_tool",
                "arguments": {
                    "message": "Hello from Python MCP Checker in test folder!"
                }
            }
        }
        print("[3] Testing 'echo_tool' call...")
        send_request(echo_req)
        echo_res = read_response()
        print("    [OK] Tool Call Result:")
        print("   ", json.dumps(echo_res, indent=2))
        print()

        # Step 5: Test Tool Call 'get_system_info'
        sys_req = {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {
                "name": "get_system_info",
                "arguments": {}
            }
        }
        print("[4] Testing 'get_system_info' call...")
        send_request(sys_req)
        sys_res = read_response()
        print("    [OK] Tool Call Result:")
        print("   ", json.dumps(sys_res, indent=2))
        print()

        print("==================================================")
        print("[SUCCESS] MCP Server Stdio protocol is 100% operational.")
        print("==================================================")

    except Exception as e:
        print(f"[ERROR] An error occurred during test: {e}")
    finally:
        process.terminate()

if __name__ == "__main__":
    main()
