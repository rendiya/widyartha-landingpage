import { OpenAI } from 'openai';

// Initialize OpenAI client pointing to local Full Bridge Server (Port 8088)
const openai = new OpenAI({
  apiKey: process.env.GEMINI_API_KEY || 'sk-dummy-key',
  baseURL: 'http://localhost:8088/v1'
});

async function main() {
  try {
    console.log('⚡ Sending request to Antigravity Full Bridge Server via OpenAI SDK...\n');

    const response = await openai.chat.completions.create({
      model: 'antigravity', // Options: 'antigravity', 'gemini-3.6-flash-medium', 'gpt-4o-mini'
      messages: [
        { role: 'system', content: 'You are a friendly Widyartha CS assistant.' },
        { role: 'user', content: 'Check batik shirt stock and order #1' }
      ],
      max_tokens: 150,
      temperature: 0.7
    });

    console.log('--- Response from Antigravity Full Bridge Server ---');
    console.log(response.choices[0].message.content);
  } catch (error) {
    console.error('Error:', error);
  }
}

main();
