import sys
import os

# Ensure UTF-8 output encoding for Windows terminal compatibility
if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

try:
    from openai import OpenAI
except ImportError:
    print("[INFO] Module 'openai' is not installed in Python. Installing automatically via pip...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "openai"])
    from openai import OpenAI

def get_active_api_key():
    """Automatically reads GEMINI_API_KEY from .env in the root folder or environment variables"""
    test_dir = os.path.dirname(os.path.abspath(__file__))
    root_dir = os.path.abspath(os.path.join(test_dir, ".."))
    
    possible_envs = [
        os.path.join(root_dir, ".env"),
        os.path.join(test_dir, ".env")
    ]
    
    for env_path in possible_envs:
        if os.path.exists(env_path):
            try:
                with open(env_path, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.strip().startswith("GEMINI_API_KEY="):
                            key = line.split("=", 1)[1].strip()
                            if key and key != "YOUR_GEMINI_API_KEY_HERE":
                                return key
            except Exception:
                pass
    return os.environ.get("GEMINI_API_KEY", "sk-dummy-key")

def main():
    print("==================================================")
    print("[PYTHON CLIENT] OpenAI Client Test for Antigravity Server")
    print("==================================================\n")

    api_key = get_active_api_key()
    key_preview = api_key[:12] + "..." if len(api_key) > 12 else api_key
    print(f"Detected API Key  : {key_preview}")
    print(f"Server Base URL   : http://localhost:8088/v1\n")

    # Initialize Python OpenAI client pointing to local server (Port 8088)
    client = OpenAI(
        api_key=api_key,
        base_url="http://localhost:8088/v1"
    )

    try:
        # 1. Test List Models
        print("[1] Retrieving Models List (client.models.list())...")
        models = client.models.list()
        print(f"    [OK] Found {len(models.data)} model(s):")
        for m in models.data[:5]:
            print(f"       - ID: {m.id} ({m.owned_by})")
        print()

        # 2. Test Chat Completions with Product Stock query
        selected_model = "antigravity"  # Or 'gemini-3.6-flash-medium'
        print(f"[2] Sending Chat Completion to Model '{selected_model}' (Check Product Stock)...")
        response = client.chat.completions.create(
            model=selected_model,
            messages=[
                {"role": "system", "content": "You are a friendly Widyartha CS assistant."},
                {"role": "user", "content": "Check batik shirt stock and order #1"}
            ],
            max_tokens=150,
            temperature=0.7
        )

        print("\n--- Response from Antigravity Full Bridge Server ---")
        print(response.choices[0].message.content)
        print("\n==================================================")
        print("[SUCCESS] Full Bridge MCP + OpenAI Client is 100% operational.")
        print("==================================================")

    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        print("\n💡 Troubleshooting Tips:")
        print("1. Ensure the HTTP server (server.js) is running via `npm start` or `start-server.bat` on port 8088.")

if __name__ == "__main__":
    main()
