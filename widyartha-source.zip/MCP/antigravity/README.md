# Antigravity MCP Server & OpenAI-Compatible API Bridge

This project provides a **Dual-Mode Integration** solution for **Google Antigravity**:
1. **OpenAI-Compatible REST API Bridge (`server.js`)**: A local HTTP REST API server (`http://localhost:8088/v1`) that enables WhatsApp bots, Node.js scripts, Python clients, or any external application using the `openai` SDK (`const { OpenAI } = require('openai')`) to communicate with Antigravity models and automatically integrate with real-time Widyartha database context.
2. **MCP Stdio Server (`index.js`)**: A local Model Context Protocol (Stdio) server for registering local tools directly inside the Antigravity IDE UI without requiring external API keys.

---

## 🛠️ Key Features

- **OpenAI SDK Integration**: Seamlessly use standard `openai` libraries by redirecting `baseURL` to `http://localhost:8088/v1`.
- **Real-Time MCP Data Integration**: The HTTP server automatically enriches AI completion prompts with product catalog stock, order status, and invoice information from the local Widyartha SQLite database.
- **Comprehensive Model Selection**: Supports model presets matching the Antigravity IDE UI dropdown:
  - `gemini-3.6-flash-high`, `gemini-3.6-flash-medium`, `gemini-3.6-flash-low`
  - `gemini-3.5-flash-high`, `gemini-3.5-flash-medium`, `gemini-3.5-flash-low`
  - `gemini-3.1-pro-high`, `gemini-3.1-pro-low`
  - `claude-sonnet-4.6`, `claude-opus-4.6`
  - `gpt-oss-120b`, `antigravity`
- **Auto-Setup & Portable**: Automatically generates local security tokens, auto-installs missing dependencies, and uses relative paths for full portability across drives/folders.

---

## 🚀 Running the API Server

### 1. Start the HTTP Server (Port 8088)
Run the following command in your terminal:
```powershell
npm start
```
*Or double-click `start-server.bat` (Windows) / `start-server.sh` (Linux/macOS).*

The server will listen at:
- **Base URL**: `http://localhost:8088/v1`
- **Chat Completion**: `POST http://localhost:8088/v1/chat/completions`
- **List Models**: `GET http://localhost:8088/v1/models`

---

## 💻 Client Usage Examples (Node.js & Python)

### Node.js Example:
```javascript
const { OpenAI } = require('openai');

const openai = new OpenAI({
  apiKey: 'sk-random-key',
  baseURL: 'http://localhost:8088/v1'
});

async function main() {
  const response = await openai.chat.completions.create({
    model: 'antigravity',
    messages: [
      { role: 'user', content: 'Check batik shirt stock' }
    ]
  });

  console.log(response.choices[0].message.content);
}

main();
```

### Python Example:
```python
from openai import OpenAI

client = OpenAI(
    api_key="sk-random-key",
    base_url="http://localhost:8088/v1"
)

response = client.chat.completions.create(
    model="antigravity",
    messages=[
        {"role": "user", "content": "Check batik shirt stock"}
    ]
)

print(response.choices[0].message.content)
```

---

## 📋 Installing MCP Server in Antigravity IDE UI

To register the MCP Server directly in the **Antigravity IDE UI**:

1. Open the **Customizations** panel in Antigravity IDE.
2. Click the **`Open MCP Config`** button.
3. Paste the following JSON configuration:

```json
{
  "mcpServers": {
    "antigravity-mcp": {
      "command": "node",
      "args": [
        "E:/code/ai-bot-cs/MCP/antigravity/index.js"
      ],
      "cwd": "E:/code/ai-bot-cs/MCP/antigravity"
    }
  }
}
```
4. Save the file and click **`Refresh 🔄`**.

---

## 🧪 Testing (Test Scripts)

All test scripts are located inside the `test/` directory:

- **Run Node.js OpenAI SDK Test**:
  ```powershell
  npm test
  ```
  *(Executes `node test/client-example.js`)*

- **Run Python OpenAI Client Test**:
  ```powershell
  npm run test:python
  # Or: python test/test_openai_client.py
  ```

- **Run MCP Stdio Protocol Test**:
  ```powershell
  npm run test:mcp
  # Or: python test/check_mcp.py
  ```

---

## 📁 Directory Structure

```text
E:\code\ai-bot-cs\MCP\antigravity\
├── server.js              # OpenAI Bridge HTTP REST API Server (Port 8088)
├── index.js               # MCP Stdio Server for Antigravity IDE UI
├── mcp-config.json        # Antigravity MCP Configuration Template
├── start-server.bat       # Portable Windows Launcher (Auto npm install)
├── start-server.sh        # Portable Linux/macOS Launcher
├── .env & .env.example    # Environment Variables
├── .gitignore             # Git Ignore Rules
├── package.json           # Package Manifest & Scripts
├── README.md              # English Documentation
└── test/                  # Test Scripts Directory
    ├── client-example.js     # Node.js OpenAI Client Test
    ├── test_openai_client.py # Python OpenAI Client Test
    └── check_mcp.py          # MCP Stdio Protocol Test
```
