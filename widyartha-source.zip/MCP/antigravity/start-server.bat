@echo off
title Antigravity OpenAI Bridge Server
cd /d "%~dp0"

IF NOT EXIST node_modules (
    echo [Info] node_modules not found. Auto-installing dependencies...
    cmd /c "npm install"
)

echo.
echo =======================================================
echo 🚀 Starting Antigravity OpenAI-Compatible API Server...
echo =======================================================
echo.

node server.js
pause
