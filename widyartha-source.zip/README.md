# Widyartha 🤖💼

An AI-powered, omni-channel customer service platform designed to automate customer interactions, process transactions, and manage external API integrations seamlessly. Built with modern web technologies, it supports both local LLMs (via Ollama) and cloud-based LLMs (like Google Gemini).

## 🌟 Key Features

- **Omni-Channel Inbox**: Unified dashboard to manage conversations from Telegram and WhatsApp.
- **AI Agent & Tool Calling**: Intelligent bot capable of answering FAQs, checking stock, and creating orders via dynamically injected tools/functions.
- **Dynamic API Connectors**: Import Postman collections or JSON payloads to dynamically create tools for the AI agent to use.
- **Local Ledger System**: A staging/buffer area for incoming orders before they are manually or automatically synced to your main database.
- **Real-time Dashboard**: Built with React, Vite, and TailwindCSS (shadcn/ui) for a premium, responsive user experience.
- **Secure & Robust**: Implements JWT authentication, AES-256 encryption for API credentials, and runs on a local SQLite database with WAL mode for performance.

## 🛠️ Tech Stack

- **Frontend**: React.js, Vite, TailwindCSS, shadcn/ui
- **Backend**: Node.js, Express.js, Socket.io, better-sqlite3
- **AI Engine**: Ollama (Local), Google Gemini (Cloud)
- **Infrastructure**: Docker & Docker Compose

## 🚀 Quick Start

The easiest way to run Widyartha is using Docker. 

### Prerequisites
- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/widyartha.git
   cd widyartha
   ```

2. **Run with Docker Compose**
   ```bash
   docker compose up -d
   ```
   *This command will build and start the Frontend, Backend, and Ollama services. The SQLite database will be initialized and seeded automatically.*

3. **(Optional) Pull Local LLM Model**
   If you plan to use Ollama for local AI inference, pull your preferred model (e.g., `llama3` or `mistral`):
   ```bash
   docker exec -it ollama ollama pull llama3
   ```

4. **Access the Dashboard**
   - Open your browser and navigate to: `http://localhost:5173` (or `http://localhost` depending on your setup).
   - Login with the default system credentials:
     - **Account**: `admin`
     - **Password**: `admin`

5. **Initial Configuration**
   - **LLM Config**: Navigate to the LLM settings to input your Google Gemini API Key or set up your local Ollama configuration.
   - **Channels**: Go to the Channels menu to set up your Telegram Bot Token or link your WhatsApp.

## 📂 Project Structure

```text
widyartha/
├── backend/          # Node.js/Express server, Database init, AI & Bot adapters
├── frontend/         # React/Vite dashboard UI components and state
├── simulasi_order/   # Order simulation flows and documentation
├── docker-compose.yml# Docker orchestration
└── ...
```

## 🤝 Contributing

Contributions, issues, and feature requests are welcome! Feel free to check the [issues page](https://github.com/yourusername/widyartha/issues).

## 📝 License

This project is licensed under the [MIT License](LICENSE).
