import { initDb } from './src/db/database.js';

const db = initDb();
console.log('Resetting sessions and messages...');

// Delete child tables first to avoid FOREIGN KEY constraint failures
db.exec('DELETE FROM tool_call_logs');
db.exec('DELETE FROM sales_backup');
db.exec('DELETE FROM messages');
db.exec('DELETE FROM sessions');

// Optionally reset sqlite sequence so IDs start from 1 again
db.exec("DELETE FROM sqlite_sequence WHERE name IN ('tool_call_logs', 'sales_backup', 'messages', 'sessions')");

console.log('Sessions reset successfully.');
