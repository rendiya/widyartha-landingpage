import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, 'data/widyartha.db');
const walPath = path.join(__dirname, 'data/widyartha.db-wal');
const shmPath = path.join(__dirname, 'data/widyartha.db-shm');

console.log('🛑 Memulai proses Factory Reset Database...');

// Hapus file DB jika ada
[dbPath, walPath, shmPath].forEach((file) => {
  if (fs.existsSync(file)) {
    try {
      fs.unlinkSync(file);
      console.log(`✅ File terhapus: ${path.basename(file)}`);
    } catch (err) {
      console.error(`❌ Gagal menghapus file ${path.basename(file)}:`, err.message);
      console.error('⚠️ Pastikan server backend sudah dimatikan sebelum menjalankan skrip ini!');
      process.exit(1);
    }
  }
});

console.log('🌱 Melakukan inisialisasi ulang database dengan data default...');
// Panggil initDb untuk membuat ulang database dan menjalankan seed
import('./src/db/database.js').then((module) => {
  try {
    module.initDb();
    console.log('✨ Factory Reset Selesai! Database Anda sekarang bersih seperti baru.');
    process.exit(0);
  } catch (err) {
    console.error('❌ Gagal melakukan inisialisasi database:', err);
    process.exit(1);
  }
}).catch((err) => {
  console.error('❌ Gagal memuat modul database:', err);
  process.exit(1);
});
