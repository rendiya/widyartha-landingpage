const db = require('better-sqlite3')('data/database.sqlite');
db.prepare("UPDATE llm_configs SET base_url = '' WHERE provider = 'sumopod'").run();
console.log('Done');
