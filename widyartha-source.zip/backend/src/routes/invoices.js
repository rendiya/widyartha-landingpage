import express from 'express';
import axios from 'axios';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// Get all invoices
router.get('/', authenticate, (req, res) => {
  try {
    const db = getDb();
    const invoices = db.prepare(`
      SELECT i.*, o.customer_id, c.name as customer_name
      FROM invoices i
      JOIN orders o ON i.order_id = o.id
      LEFT JOIN customers c ON o.customer_id = c.id
      ORDER BY i.issued_at DESC
    `).all();
    res.json(invoices);
  } catch (error) {
    console.error('Error fetching invoices:', error);
    res.status(500).json({ error: 'Failed to fetch invoices' });
  }
});

// Get invoice HTML for viewing
router.get('/:id/html', (req, res) => {
  try {
    const db = getDb();
    const invoice = db.prepare(`
      SELECT i.*, o.shipping_address, o.id as order_id, c.name as customer_name
      FROM invoices i
      JOIN orders o ON i.order_id = o.id
      LEFT JOIN customers c ON o.customer_id = c.id
      WHERE i.id = ?
    `).get(req.params.id);

    if (!invoice) return res.status(404).send('Invoice not found');

    // Get order items
    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(invoice.order_id);

    const paymentMethods = db.prepare('SELECT * FROM manual_payment_methods WHERE is_active = 1').all();
    const paymentInfo = paymentMethods.map(pm => `${pm.bank_name}: ${pm.account_no} a/n ${pm.account_name}`).join('<br/>');
    const appName = db.prepare("SELECT value FROM app_settings WHERE key = 'app_name'").get()?.value || 'Widyartha';

    const itemRows = items.length > 0
      ? items.map(item => `
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;">${item.product_name} (${item.product_sku || '-'})</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${item.quantity}</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">Rp ${item.unit_price?.toLocaleString()}</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">Rp ${item.subtotal?.toLocaleString()}</td>
          </tr>
        `).join('')
      : `<tr>
           <td colspan="4" style="padding: 10px; border: 1px solid #ddd; text-align: center; color: #999;">Pembayaran Pesanan #${invoice.order_id}</td>
         </tr>`;

    const html = `
      <html>
      <head>
        <title>Invoice ${invoice.invoice_number}</title>
        <style>body { font-family: sans-serif; background: #f0f0f0; padding: 40px; display: flex; justify-content: center; }</style>
      </head>
      <body>
        <div style="padding: 40px; background: #ffffff; width: 600px; height: auto; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); box-sizing: border-box;">
          <div style="text-align: center; border-bottom: 2px dashed #ddd; padding-bottom: 20px; margin-bottom: 20px;">
            <h1 style="margin: 0; color: #333; font-size: 28px;">${appName}</h1>
            <p style="margin: 5px 0 0 0; color: #777; font-size: 14px;">INVOICE PEMBAYARAN</p>
          </div>
          <div style="display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 14px;">
            <div>
              <strong>Kepada:</strong><br/>
              ${invoice.customer_name || 'Pelanggan'}<br/>
              ${invoice.shipping_address || '-'}
            </div>
            <div style="text-align: right;">
              <strong>No. Invoice:</strong> ${invoice.invoice_number}<br/>
              <strong>Status:</strong> <span style="color: ${invoice.status === 'paid' ? 'green' : invoice.status === 'void' ? '#999' : 'red'};">${invoice.status === 'paid' ? 'LUNAS' : invoice.status === 'void' ? 'DIBATALKAN' : 'BELUM DIBAYAR'}</span>
            </div>
          </div>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px;">
            <tr style="background: #f8f9fa;">
              <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Produk</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Qty</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Harga</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Subtotal</th>
            </tr>
            ${itemRows}
          </table>
          <div style="text-align: right; font-size: 18px; margin-bottom: 30px;">
            <strong>Total Tagihan: Rp ${invoice.amount_due?.toLocaleString()}</strong>
          </div>
          <div style="font-size: 12px; color: #555; background: #f1f5f9; padding: 15px; border-radius: 6px;">
            <strong>Instruksi Pembayaran:</strong><br/>
            ${paymentInfo}
          </div>
        </div>
      </body>
      </html>
    `;
    res.send(html);
  } catch (error) {
    console.error('Error generating invoice HTML:', error);
    res.status(500).send('Failed to generate invoice');
  }
});

// Get invoice image (Proxy to QuickChart via POST to avoid URL length limits)
router.get('/:id/image', async (req, res) => {
  try {
    const db = getDb();
    const invoice = db.prepare(`
      SELECT i.*, o.shipping_address, o.id as order_id, c.name as customer_name
      FROM invoices i
      JOIN orders o ON i.order_id = o.id
      LEFT JOIN customers c ON o.customer_id = c.id
      WHERE i.id = ?
    `).get(req.params.id);

    if (!invoice) return res.status(404).send('Invoice not found');

    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(invoice.order_id);
    const paymentMethods = db.prepare('SELECT * FROM manual_payment_methods WHERE is_active = 1').all();
    const paymentInfo = paymentMethods.map(pm => `${pm.bank_name}: ${pm.account_no} a/n ${pm.account_name}`).join('<br/>');
    const appName = db.prepare("SELECT value FROM app_settings WHERE key = 'app_name'").get()?.value || 'Widyartha';

    const itemRows = items.length > 0
      ? items.map(item => `
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd;">${item.product_name} (${item.product_sku || '-'})</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${item.quantity}</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">Rp ${item.unit_price?.toLocaleString()}</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">Rp ${item.subtotal?.toLocaleString()}</td>
          </tr>
        `).join('')
      : '';

    const html = `
      <div style="font-family: Arial, sans-serif; padding: 30px; background: #ffffff; width: 600px; height: auto; border: 1px solid #ddd; box-sizing: border-box;">
        <div style="text-align: center; border-bottom: 2px dashed #ddd; padding-bottom: 20px; margin-bottom: 20px;">
          <h1 style="margin: 0; color: #333; font-size: 28px;">${appName}</h1>
          <p style="margin: 5px 0 0 0; color: #777; font-size: 14px;">INVOICE PEMBAYARAN</p>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 14px;">
          <div>
            <strong>Kepada:</strong><br/>
            ${invoice.customer_name || 'Pelanggan'}<br/>
            ${invoice.shipping_address || '-'}
          </div>
          <div style="text-align: right;">
            <strong>No. Invoice:</strong> ${invoice.invoice_number}<br/>
            <strong>Status:</strong> <span style="color: ${invoice.status === 'paid' ? 'green' : invoice.status === 'void' ? '#999' : 'red'};">${invoice.status === 'paid' ? 'LUNAS' : invoice.status === 'void' ? 'DIBATALKAN' : 'BELUM DIBAYAR'}</span>
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px;">
          <tr style="background: #f8f9fa;">
            <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Produk</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Qty</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Harga</th>
            <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Subtotal</th>
          </tr>
          ${itemRows}
        </table>
        <div style="text-align: right; font-size: 18px; margin-bottom: 30px;">
          <strong>Total Tagihan: Rp ${invoice.amount_due?.toLocaleString()}</strong>
        </div>
        <div style="font-size: 12px; color: #555; background: #f1f5f9; padding: 15px; border-radius: 6px;">
          <strong>Instruksi Pembayaran:</strong><br/>
          ${paymentInfo}
        </div>
      </div>
    `;

    // POST to QuickChart
    const response = await axios.post('https://quickchart.io/html-to-image', {
      html,
      width: 600,
      height: 500
    }, {
      responseType: 'stream'
    });

    res.set('Content-Type', 'image/png');
    response.data.pipe(res);

  } catch (error) {
    console.error('Error generating invoice image:', error);
    res.status(500).send('Failed to generate invoice image');
  }
});

export default router;
