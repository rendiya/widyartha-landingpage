import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

// GET /api/ledger — List orders in buffer
router.get('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { status = 'pending_sync', page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;

  const items = db.prepare(`
    SELECT sb.*, c.name as customer_name, c.phone, s.mode
    FROM sales_backup sb
    LEFT JOIN customers c ON c.id = sb.customer_id
    LEFT JOIN sessions s ON s.id = sb.session_id
    WHERE sb.sync_status = ?
    ORDER BY sb.created_at DESC
    LIMIT ? OFFSET ?
  `).all(status, parseInt(limit), parseInt(offset));

  const total = db.prepare(`SELECT COUNT(*) as count FROM sales_backup WHERE sync_status = ?`).get(status);

  res.json({ items: items.map(i => ({ ...i, order_data: safeParseJSON(i.order_data, {}) })), total: total.count });
});

// GET /api/ledger/:id
router.get('/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const item = db.prepare(`
    SELECT sb.*, c.name as customer_name, c.phone
    FROM sales_backup sb
    LEFT JOIN customers c ON c.id = sb.customer_id
    WHERE sb.id = ?
  `).get(req.params.id);

  if (!item) return res.status(404).json({ error: 'Order not found' });
  res.json({ ...item, order_data: safeParseJSON(item.order_data, {}) });
});

// PATCH /api/ledger/:id/approve — Approve and sync
router.patch('/:id/approve', authenticate, requireRole('super_admin', 'admin'), async (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM sales_backup WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'Order not found' });

  // Update status to syncing
  db.prepare('UPDATE sales_backup SET sync_status = ?, sync_attempts = sync_attempts + 1 WHERE id = ?')
    .run('syncing', req.params.id);

  try {
    // If there's a sync target connector, attempt sync
    if (item.sync_target) {
      const connector = db.prepare('SELECT * FROM db_connectors WHERE id = ?').get(item.sync_target);
      if (connector) {
        // TODO: Execute parameterized insert via mapping
        // For now, mark as synced
      }
    }

    db.prepare(`UPDATE sales_backup SET sync_status = 'synced', synced_at = CURRENT_TIMESTAMP WHERE id = ?`)
      .run(req.params.id);
    
    res.json({ success: true, status: 'synced' });
  } catch (err) {
    db.prepare(`UPDATE sales_backup SET sync_status = 'sync_failed', notes = ? WHERE id = ?`)
      .run(err.message, req.params.id);
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/ledger/:id/reject — Reject/cancel order
router.patch('/:id/reject', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { reason } = req.body;
  db.prepare(`UPDATE sales_backup SET sync_status = 'rejected', notes = ? WHERE id = ?`)
    .run(reason || 'Ditolak admin', req.params.id);
  res.json({ success: true });
});

// POST /api/ledger — Manually add order to buffer
router.post('/', authenticate, (req, res) => {
  const db = getDb();
  const { session_id, customer_id, order_data, sync_target, sync_mapping } = req.body;

  const result = db.prepare(`
    INSERT INTO sales_backup (session_id, customer_id, order_data, sync_target, sync_mapping)
    VALUES (?, ?, ?, ?, ?)
  `).run(session_id, customer_id, JSON.stringify(order_data), sync_target, sync_mapping ? JSON.stringify(sync_mapping) : null);

  res.status(201).json({ id: result.lastInsertRowid });
});

// GET /api/ledger/stats/summary
router.get('/stats/summary', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const stats = db.prepare(`
    SELECT 
      sync_status,
      COUNT(*) as count
    FROM sales_backup
    GROUP BY sync_status
  `).all();

  const result = { pending_sync: 0, synced: 0, rejected: 0, sync_failed: 0, syncing: 0 };
  stats.forEach(s => { result[s.sync_status] = s.count; });
  res.json(result);
});

function safeParseJSON(str, fallback) {
  try { return JSON.parse(str || '{}'); } catch { return fallback; }
}

export default router;
