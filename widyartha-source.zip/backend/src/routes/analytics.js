import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// GET /api/analytics/overview
router.get('/overview', authenticate, (req, res) => {
  const db = getDb();
  const { period = '7d' } = req.query;

  const daysMap = { '7d': 7, '30d': 30, '90d': 90 };
  const days = daysMap[period] || 7;

  // Daily sessions trend
  const sessionsTrend = db.prepare(`
    SELECT DATE(started_at) as date, 
           COUNT(*) as total,
           SUM(CASE WHEN escalated_at IS NOT NULL THEN 1 ELSE 0 END) as escalated,
           SUM(CASE WHEN mode = 'ai' AND status = 'done' THEN 1 ELSE 0 END) as ai_resolved
    FROM sessions
    WHERE started_at >= datetime('now', ? || ' days')
    GROUP BY DATE(started_at)
    ORDER BY date ASC
  `).all(`-${days}`);

  // Channel breakdown
  const channelBreakdown = db.prepare(`
    SELECT ch.type, ch.name, COUNT(s.id) as sessions
    FROM sessions s
    JOIN channels ch ON ch.id = s.channel_id
    WHERE s.started_at >= datetime('now', ? || ' days')
    GROUP BY ch.type
  `).all(`-${days}`);

  // Tool usage
  const toolUsage = db.prepare(`
    SELECT tool_name, COUNT(*) as calls, 
           SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
           AVG(duration_ms) as avg_duration
    FROM tool_call_logs
    WHERE called_at >= datetime('now', ? || ' days')
    GROUP BY tool_name
    ORDER BY calls DESC
    LIMIT 10
  `).all(`-${days}`);

  // CS performance
  const csPerformance = db.prepare(`
    SELECT u.name, u.id,
           COUNT(s.id) as sessions_handled,
           AVG(julianday(s.ended_at) - julianday(s.escalated_at)) * 24 * 60 as avg_handling_minutes
    FROM sessions s
    JOIN users u ON u.id = s.assigned_cs
    WHERE s.started_at >= datetime('now', ? || ' days')
    AND u.role = 'cs'
    GROUP BY u.id
    ORDER BY sessions_handled DESC
  `).all(`-${days}`);

  // Summary totals
  const totals = db.prepare(`
    SELECT 
      COUNT(*) as total_sessions,
      SUM(CASE WHEN escalated_at IS NOT NULL THEN 1 ELSE 0 END) as escalated,
      SUM(CASE WHEN status = 'done' AND mode = 'ai' THEN 1 ELSE 0 END) as ai_resolved,
      ROUND(SUM(CASE WHEN status = 'done' AND mode = 'ai' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(*), 0), 1) as ai_rate
    FROM sessions
    WHERE started_at >= datetime('now', ? || ' days')
  `).get(`-${days}`);

  res.json({ sessionsTrend, channelBreakdown, toolUsage, csPerformance, totals, period });
});

// GET /api/analytics/connector-health
router.get('/connector-health', authenticate, (req, res) => {
  const db = getDb();
  const health = db.prepare(`
    SELECT 
      ac.id, ac.name,
      COUNT(tcl.id) as total_calls,
      SUM(CASE WHEN tcl.status = 'success' THEN 1 ELSE 0 END) as success_calls,
      SUM(CASE WHEN tcl.status = 'error' THEN 1 ELSE 0 END) as error_calls,
      AVG(tcl.duration_ms) as avg_duration,
      ROUND(SUM(CASE WHEN tcl.status = 'success' THEN 1 ELSE 0 END) * 100.0 / NULLIF(COUNT(tcl.id), 0), 1) as success_rate
    FROM api_collections ac
    LEFT JOIN generated_tools gt ON gt.collection_id = ac.id
    LEFT JOIN tool_call_logs tcl ON tcl.tool_name = gt.name
    GROUP BY ac.id
  `).all();
  res.json(health);
});

export default router;
