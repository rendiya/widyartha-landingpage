import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';
import { LLMService } from '../services/llm.service.js';
import { sendTelegramMessage } from '../channels/telegram.js';

const router = express.Router();

// GET /api/inbox/unread-count
router.get('/unread-count', authenticate, (req, res) => {
  const db = getDb();
  let query = `
    SELECT COUNT(*) as count 
    FROM messages m
    JOIN sessions s ON s.id = m.session_id
    WHERE m.is_read = 0 AND m.sender_type = 'customer'
  `;
  const params = [];
  
  if (req.user.role === 'cs') {
    query += ` AND (s.assigned_cs = ? OR s.mode = 'ai')`;
    params.push(req.user.id);
  }

  const result = db.prepare(query).get(...params);
  res.json({ count: result.count });
});

// GET /api/inbox/sessions
router.get('/sessions', authenticate, (req, res) => {
  const db = getDb();
  const { status, mode, channel, search, page = 1, limit = 30 } = req.query;
  const offset = (page - 1) * limit;

  let query = `
    SELECT s.*, c.name as customer_name, c.channel_type, c.phone,
           ch.name as channel_name, ch.type,
           u.name as cs_name, u.avatar as cs_avatar,
           (SELECT COUNT(*) FROM messages m WHERE m.session_id = s.id AND m.is_read = 0 AND m.sender_type = 'customer') as unread_count
    FROM sessions s
    JOIN customers c ON c.id = s.customer_id
    JOIN channels ch ON ch.id = s.channel_id
    LEFT JOIN users u ON u.id = s.assigned_cs
    WHERE 1=1
  `;
  const params = [];

  if (status) { query += ' AND s.status = ?'; params.push(status); }
  if (mode) { query += ' AND s.mode = ?'; params.push(mode); }
  if (channel) { query += ' AND ch.type = ?'; params.push(channel); }
  if (search) {
    query += ' AND (c.name LIKE ? OR c.phone LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }

  // CS can only see assigned sessions
  if (req.user.role === 'cs') {
    query += ' AND (s.assigned_cs = ? OR s.mode = \'ai\')';
    params.push(req.user.id);
  }

  query += ' ORDER BY s.last_message_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), parseInt(offset));

  const sessions = db.prepare(query).all(...params);
  
  const totalQuery = query.replace(/SELECT.*?FROM sessions/, 'SELECT COUNT(*) as count FROM sessions').split('ORDER BY')[0];

  res.json({ sessions, page: parseInt(page), limit: parseInt(limit) });
});

// GET /api/inbox/sessions/:id
router.get('/sessions/:id', authenticate, (req, res) => {
  const db = getDb();
  const session = db.prepare(`
    SELECT s.*, c.name as customer_name, c.channel_type, c.phone, c.tags as customer_tags,
           ch.name as channel_name, ch.type, u.name as cs_name
    FROM sessions s
    JOIN customers c ON c.id = s.customer_id
    JOIN channels ch ON ch.id = s.channel_id
    LEFT JOIN users u ON u.id = s.assigned_cs
    WHERE s.id = ?
  `).get(req.params.id);

  if (!session) return res.status(404).json({ error: 'Session not found' });

  const messages = db.prepare(`
    SELECT m.*, u.name as sender_name, u.avatar
    FROM messages m
    LEFT JOIN users u ON u.id = m.sender_id AND m.sender_type IN ('cs','ai')
    WHERE m.session_id = ?
    ORDER BY m.sent_at ASC
  `).all(req.params.id);

  const memory = db.prepare('SELECT * FROM ai_memory WHERE customer_id = ?').get(session.customer_id);

  // Mark messages as read
  db.prepare(`UPDATE messages SET is_read = 1 WHERE session_id = ? AND sender_type = 'customer'`).run(req.params.id);

  res.json({ session, messages, memory });
});

// POST /api/inbox/sessions/:id/send
router.post('/sessions/:id/send', authenticate, async (req, res) => {
  const db = getDb();
  const { content } = req.body;
  const sessionId = req.params.id;

  const session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
  if (!session) return res.status(404).json({ error: 'Session not found' });

  // Insert CS message
  const result = db.prepare(`
    INSERT INTO messages (session_id, sender_type, sender_id, content)
    VALUES (?, 'cs', ?, ?)
  `).run(sessionId, req.user.id, content);

  db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?')
    .run(content, sessionId);

  const message = db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid);

  // Send to Telegram if applicable
  const customer = db.prepare('SELECT channel_type, channel_ref FROM customers WHERE id = ?').get(session.customer_id);
  if (customer && customer.channel_type === 'telegram') {
    sendTelegramMessage(session.channel_id, customer.channel_ref, content);
  }

  // Emit via Socket.io
  const io = req.app.get('io');
  if (io) {
    io.to(`session:${sessionId}`).emit('new_message', message);
  }

  res.json(message);
});

// PATCH /api/inbox/sessions/:id/mode
router.patch('/sessions/:id/mode', authenticate, (req, res) => {
  const db = getDb();
  const { mode, assigned_cs } = req.body;
  const sessionId = req.params.id;

  const updates = { mode };
  let query = 'UPDATE sessions SET mode = ?';
  const params = [mode];

  if (mode === 'human' && assigned_cs) {
    query += ', assigned_cs = ?';
    params.push(assigned_cs);
  }

  if (mode === 'human') {
    query += ', escalated_at = CURRENT_TIMESTAMP';
  }

  query += ' WHERE id = ?';
  params.push(sessionId);

  db.prepare(query).run(...params);

  const io = req.app.get('io');
  if (io) {
    io.to(`session:${sessionId}`).emit('mode_changed', { sessionId, mode, assigned_cs });
    io.emit('session_updated', { sessionId, mode });
  }

  res.json({ success: true, mode });
});

// PATCH /api/inbox/sessions/:id/close
router.patch('/sessions/:id/close', authenticate, (req, res) => {
  const db = getDb();
  db.prepare(`
    UPDATE sessions SET status = 'done', ended_at = CURRENT_TIMESTAMP WHERE id = ?
  `).run(req.params.id);

  const io = req.app.get('io');
  if (io) {
    io.emit('session_closed', { sessionId: req.params.id });
  }

  res.json({ success: true });
});

// POST /api/inbox/sessions/:id/ai-reply
router.post('/sessions/:id/ai-reply', authenticate, async (req, res) => {
  const db = getDb();
  const { message } = req.body;
  const sessionId = req.params.id;

  try {
    const session = db.prepare(`
      SELECT s.*, c.name as customer_name, c.channel_type
      FROM sessions s JOIN customers c ON c.id = s.customer_id
      WHERE s.id = ?
    `).get(sessionId);

    if (!session) return res.status(404).json({ error: 'Session not found' });

    const llmService = new LLMService();
    const aiResponse = await llmService.chat(sessionId, message, session);

    // Save AI message
    const result = db.prepare(`
      INSERT INTO messages (session_id, sender_type, content, tool_calls)
      VALUES ('ai', ?, ?, ?)
    `).run(sessionId, aiResponse.content, JSON.stringify(aiResponse.toolCalls || []));

    db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(aiResponse.content, sessionId);

    if (session.channel_type === 'telegram') {
      const customer = db.prepare('SELECT channel_ref FROM customers WHERE id = ?').get(session.customer_id);
      if (customer) {
        sendTelegramMessage(session.channel_id, customer.channel_ref, aiResponse.content);
      }
    }

    const io = req.app.get('io');
    if (io) {
      io.to(`session:${sessionId}`).emit('new_message', {
        id: result.lastInsertRowid,
        session_id: sessionId,
        sender_type: 'ai',
        content: aiResponse.content,
        tool_calls: aiResponse.toolCalls,
        sent_at: new Date().toISOString(),
      });
    }

    res.json({ content: aiResponse.content, toolCalls: aiResponse.toolCalls });
  } catch (err) {
    console.error('AI Reply error:', err);
    res.status(500).json({ error: err.message });
  }
});

// GET /api/inbox/quick-replies
router.get('/quick-replies', authenticate, (req, res) => {
  const db = getDb();
  const replies = db.prepare('SELECT * FROM quick_replies ORDER BY category, title').all();
  res.json(replies);
});

export default router;
