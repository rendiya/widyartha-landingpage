import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { LLMService } from '../services/llm.service.js';

const router = express.Router();

// GET /api/llm/rules
router.get('/rules', authenticate, (req, res) => {
  const db = getDb();
  const rules = db.prepare('SELECT * FROM system_rules ORDER BY id ASC').all();
  res.json(rules);
});

// POST /api/llm/rules
router.post('/rules', authenticate, requireRole('super_admin'), (req, res) => {
  const db = getDb();
  const { rule_text, is_active = 1 } = req.body;
  const result = db.prepare('INSERT INTO system_rules (rule_text, is_active) VALUES (?, ?)').run(rule_text, is_active);
  res.status(201).json({ id: result.lastInsertRowid });
});

// PATCH /api/llm/rules/:id
router.patch('/rules/:id', authenticate, requireRole('super_admin'), (req, res) => {
  const db = getDb();
  const { rule_text, is_active } = req.body;
  db.prepare('UPDATE system_rules SET rule_text = COALESCE(?, rule_text), is_active = COALESCE(?, is_active) WHERE id = ?').run(rule_text, is_active, req.params.id);
  res.json({ success: true });
});

// DELETE /api/llm/rules/:id
router.delete('/rules/:id', authenticate, requireRole('super_admin'), (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM system_rules WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// GET /api/llm/configs
router.get('/configs', authenticate, (req, res) => {
  const db = getDb();
  const configs = db.prepare(`
    SELECT id, name, provider, model, api_key, base_url, is_active, is_fallback, priority, threshold, system_prompt, updated_at
    FROM llm_configs ORDER BY priority DESC
  `).all();
  res.json(configs);
});

// POST /api/llm/configs
router.post('/configs', authenticate, (req, res) => {
  const db = getDb();
  const { name, provider, model, api_key, base_url, is_active, is_fallback, priority, threshold, system_prompt } = req.body;

  // If setting as active, deactivate others
  if (is_active) {
    db.prepare('UPDATE llm_configs SET is_active = 0').run();
  }

  const result = db.prepare(`
    INSERT INTO llm_configs (name, provider, model, api_key, base_url, is_active, is_fallback, priority, threshold, system_prompt)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(name, provider, model, api_key, base_url, is_active ? 1 : 0, is_fallback ? 1 : 0, priority || 0, threshold || 75, system_prompt);

  res.status(201).json({ id: result.lastInsertRowid });
});

// PATCH /api/llm/configs/:id
router.patch('/configs/:id', authenticate, (req, res) => {
  const db = getDb();
  const { name, model, api_key, base_url, is_active, threshold, system_prompt } = req.body;

  if (is_active) {
    db.prepare('UPDATE llm_configs SET is_active = 0').run();
  }

  if (api_key) {
    db.prepare(`
      UPDATE llm_configs SET name=?, model=?, api_key=?, base_url=?, is_active=?, threshold=?, system_prompt=?, updated_at=CURRENT_TIMESTAMP WHERE id=?
    `).run(name, model, api_key, base_url, is_active ? 1 : 0, threshold, system_prompt, req.params.id);
  } else {
    db.prepare(`
      UPDATE llm_configs SET name=?, model=?, base_url=?, is_active=?, threshold=?, system_prompt=?, updated_at=CURRENT_TIMESTAMP WHERE id=?
    `).run(name, model, base_url, is_active ? 1 : 0, threshold, system_prompt, req.params.id);
  }

  res.json({ success: true });
});

// DELETE /api/llm/configs/:id
router.delete('/configs/:id', authenticate, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM llm_configs WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// POST /api/llm/test — Test LLM connection
router.post('/test', authenticate, async (req, res) => {
  const { provider, model, api_key, base_url } = req.body;
  try {
    const llmService = new LLMService();
    const testConfig = { provider, model, api_key, base_url };
    const result = await llmService.callLLM(testConfig, [
      { role: 'user', content: 'Balas dengan "OK" saja.' }
    ], []);
    res.json({ success: true, response: result.content });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// POST /api/llm/assistant — AI Assistant for dashboard
router.post('/assistant', authenticate, async (req, res) => {
  const { message, history = [] } = req.body;
  try {
    const llmService = new LLMService();
    const result = await llmService.assistantChat(message, history);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/llm/remote-models — Fetch models dynamically from provider
router.post('/remote-models', authenticate, async (req, res) => {
  const { provider, api_key, base_url } = req.body;
  if (!api_key) return res.status(400).json({ error: 'API Key diperlukan' });

  try {
    const axios = (await import('axios')).default;
    let models = [];

    if (provider === 'gemini') {
      const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${api_key}`;
      const response = await axios.get(url, { timeout: 15000 });
      // Filter models that support text generation (generateContent)
      models = response.data.models
        .filter(m => m.supportedGenerationMethods?.includes('generateContent'))
        .map(m => m.name.replace('models/', ''));
    } else if (provider === 'openai' || provider === 'sumopod') {
      let cleanBaseUrl = base_url;
      if (cleanBaseUrl && (cleanBaseUrl.includes('ollama:11434') || cleanBaseUrl.includes('127.0.0.1:11434'))) {
        cleanBaseUrl = undefined;
      }
      const defaultUrl = provider === 'sumopod' ? 'https://ai.sumopod.com/v1/models' : 'https://api.openai.com/v1/models';
      let url = defaultUrl;
      if (cleanBaseUrl) {
        let baseUrlTrimmed = cleanBaseUrl.replace(/\/chat\/completions$/, '').replace(/\/models$/, '');
        if (!baseUrlTrimmed.endsWith('/models')) {
          url = `${baseUrlTrimmed}/models`;
        } else {
          url = baseUrlTrimmed;
        }
      }
      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${api_key}` },
        timeout: 15000
      });
      // OpenAI/Sumopod models
      models = response.data.data
        .map(m => m.id)
        .sort((a, b) => b.localeCompare(a));
    } else {
      return res.status(400).json({ error: `Provider ${provider} tidak mendukung fitur auto-fetch model.` });
    }

    res.json({ models });
  } catch (err) {
    res.status(500).json({ error: err.response?.data?.error?.message || err.message });
  }
});

// GET /api/llm/status — Check Ollama status
router.get('/status', authenticate, async (req, res) => {
  try {
    const axios = (await import('axios')).default;
    const ollamaUrl = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
    const response = await axios.get(`${ollamaUrl}/api/tags`, { timeout: 5000 });
    const models = response.data?.models || [];
    res.json({ ollama: true, models: models.map(m => m.name) });
  } catch {
    res.json({ ollama: false, models: [] });
  }
});

// POST /api/llm/pull — Pull model from Ollama
router.post('/pull', authenticate, async (req, res) => {
  const { model, base_url } = req.body;
  try {
    const axios = (await import('axios')).default;
    let ollamaUrl = base_url || process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
    if (ollamaUrl.includes('://ollama:') && process.env.OLLAMA_URL?.includes('localhost')) {
      ollamaUrl = process.env.OLLAMA_URL;
    }
    const io = req.app.get('io');

    // Trigger in background with stream
    axios({
      method: 'post',
      url: `${ollamaUrl}/api/pull`,
      data: { name: model, stream: true },
      responseType: 'stream',
      timeout: 300000
    }).then(response => {
      response.data.on('data', (chunk) => {
        try {
          const lines = chunk.toString().split('\n').filter(line => line.trim() !== '');
          for (const line of lines) {
            const data = JSON.parse(line);

            let progress = 0;
            if (data.total && data.completed) {
              progress = Math.round((data.completed / data.total) * 100);
            }

            if (io) {
              io.emit('model_download_progress', {
                model,
                status: data.status,
                completed: data.completed || 0,
                total: data.total || 0,
                progress,
                isCompleted: data.status === 'success'
              });
            }
          }
        } catch (e) { }
      });

      response.data.on('end', () => {
        if (io) io.emit('model_download_progress', { model, status: 'success', isCompleted: true, progress: 100 });
      });
    }).catch(err => {
      console.error('Error pulling model:', err.message);
      if (io) io.emit('model_download_progress', { model, status: 'error', error: err.message, isCompleted: true });
    });

    res.json({ success: true, message: 'Downloading in background...' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/llm/model — Delete model from Ollama
router.delete('/model', authenticate, async (req, res) => {
  const { model, base_url } = req.body;
  try {
    const axios = (await import('axios')).default;
    let ollamaUrl = base_url || process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
    if (ollamaUrl.includes('://ollama:') && process.env.OLLAMA_URL?.includes('localhost')) {
      ollamaUrl = process.env.OLLAMA_URL;
    }
    await axios.delete(`${ollamaUrl}/api/delete`, { data: { name: model } });
    res.json({ success: true, message: 'Model deleted successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
