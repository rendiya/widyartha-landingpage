import express from 'express';
import multer from 'multer';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { parseCollection, lintTools } from '../services/collectionParser.service.js';
import { LLMService } from '../services/llm.service.js';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });

// GET /api/connectors
router.get('/', authenticate, (req, res) => {
  const db = getDb();
  const collections = db.prepare(`
    SELECT ac.*, 
           COUNT(gt.id) as tool_count_actual,
           COUNT(CASE WHEN gt.is_active = 1 THEN 1 END) as active_tools
    FROM api_collections ac
    LEFT JOIN generated_tools gt ON gt.collection_id = ac.id
    GROUP BY ac.id
    ORDER BY ac.created_at DESC
  `).all();
  res.json(collections);
});

// GET /api/connectors/:id
router.get('/:id', authenticate, (req, res) => {
  const db = getDb();
  const collection = db.prepare('SELECT * FROM api_collections WHERE id = ?').get(req.params.id);
  if (!collection) return res.status(404).json({ error: 'Collection not found' });

  const tools = db.prepare(`
    SELECT * FROM generated_tools WHERE collection_id = ? ORDER BY name
  `).all(req.params.id);

  res.json({ collection, tools });
});

// POST /api/connectors/parse — Preview sebelum simpan
router.post('/parse', authenticate, requireRole('super_admin', 'admin'), upload.single('file'), async (req, res) => {
  try {
    let rawContent = '';
    let format = req.body.format || 'postman';

    if (req.file) {
      rawContent = req.file.buffer.toString('utf-8');
      // Auto-detect format
      if (req.file.originalname.endsWith('.yaml') || req.file.originalname.endsWith('.yml')) {
        format = 'openapi';
      }
    } else if (req.body.curl) {
      rawContent = req.body.curl;
      format = 'curl';
    } else if (req.body.content) {
      rawContent = req.body.content;
    }

    if (!rawContent) {
      return res.status(400).json({ error: 'No content provided' });
    }

    // Parse the collection
    const parsed = parseCollection(rawContent, format);
    
    // Run linter on extracted tools
    const lintedTools = lintTools(parsed.tools);

    res.json({
      name: parsed.name,
      format,
      baseUrl: parsed.baseUrl,
      tools: lintedTools,
      rawContent,
      endpointCount: lintedTools.length,
      warningCount: lintedTools.filter(t => t.linter_warnings?.length > 0).length,
    });
  } catch (err) {
    console.error('Parse error:', err);
    res.status(400).json({ error: err.message });
  }
});

// POST /api/connectors — Save collection
router.post('/', authenticate, requireRole('super_admin', 'admin'), async (req, res) => {
  const db = getDb();
  const { name, description, format, rawContent, baseUrl, authType, authConfig, tools } = req.body;

  const result = db.prepare(`
    INSERT INTO api_collections (name, description, format, raw_content, base_url, auth_type, auth_config)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name, description, format, rawContent, baseUrl, authType || 'none', authConfig ? JSON.stringify(authConfig) : null);

  const collectionId = result.lastInsertRowid;

  // Save generated tools
  if (tools && tools.length > 0) {
    const insertTool = db.prepare(`
      INSERT INTO generated_tools (collection_id, name, display_name, description, tool_definition, endpoint, method, headers, body_template, is_active, risk_level, linter_warnings)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const tool of tools) {
      insertTool.run(
        collectionId,
        tool.name,
        tool.display_name || tool.name,
        tool.description,
        JSON.stringify(tool.tool_definition || {}),
        tool.endpoint,
        tool.method || 'GET',
        JSON.stringify(tool.headers || {}),
        tool.body_template ? JSON.stringify(tool.body_template) : null,
        tool.is_active !== false ? 1 : 0,
        tool.risk_level || 'low',
        JSON.stringify(tool.linter_warnings || [])
      );
    }

    db.prepare('UPDATE api_collections SET tool_count = ? WHERE id = ?').run(tools.length, collectionId);
  }

  res.status(201).json({ id: collectionId, message: 'Collection saved successfully' });
});

// PATCH /api/connectors/:id/activate
router.patch('/:id/activate', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { is_active } = req.body;
  db.prepare('UPDATE api_collections SET is_active = ? WHERE id = ?').run(is_active ? 1 : 0, req.params.id);
  res.json({ success: true });
});

// PATCH /api/connectors/tools/:id
router.patch('/tools/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { description, is_active } = req.body;
  
  let query = 'UPDATE generated_tools SET ';
  const updates = [];
  const params = [];
  
  if (description !== undefined) { updates.push('description = ?'); params.push(description); }
  if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }
  
  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update' });
  
  query += updates.join(', ') + ' WHERE id = ?';
  params.push(req.params.id);
  
  db.prepare(query).run(...params);
  res.json({ success: true });
});

// DELETE /api/connectors/:id
router.delete('/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM generated_tools WHERE collection_id = ?').run(req.params.id);
  db.prepare('DELETE FROM api_collections WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// POST /api/connectors/:id/test-drive — Simulasi chat
router.post('/:id/test-drive', authenticate, async (req, res) => {
  const db = getDb();
  const { message, history = [] } = req.body;
  const collectionId = req.params.id;

  try {
    // Get tools for this specific collection only
    const tools = db.prepare(`
      SELECT * FROM generated_tools WHERE collection_id = ? AND is_active = 1
    `).all(collectionId);

    const llmService = new LLMService();
    const result = await llmService.testDrive(message, history, tools);
    
    res.json(result);
  } catch (err) {
    console.error('Test drive error:', err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
