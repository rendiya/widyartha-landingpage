import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// GET /api/dashboard/stats
router.get('/stats', authenticate, (req, res) => {
  const db = getDb();
  const today = new Date().toISOString().split('T')[0];

  const totalSessions = db.prepare(`
    SELECT COUNT(*) as count FROM sessions
    WHERE DATE(started_at) = ?
  `).get(today);

  const aiHandled = db.prepare(`
    SELECT COUNT(*) as count FROM sessions
    WHERE DATE(started_at) = ? AND mode = 'ai' AND status = 'done'
  `).get(today);

  const escalated = db.prepare(`
    SELECT COUNT(*) as count FROM sessions
    WHERE DATE(started_at) = ? AND escalated_at IS NOT NULL
  `).get(today);

  const activeSessions = db.prepare(`
    SELECT COUNT(*) as count FROM sessions WHERE status = 'active'
  `).get();

  const avgResponseTime = db.prepare(`
    SELECT AVG(
      (julianday(m2.sent_at) - julianday(m1.sent_at)) * 24 * 60
    ) as avg_minutes
    FROM messages m1
    JOIN messages m2 ON m2.session_id = m1.session_id
    WHERE m1.sender_type = 'customer'
    AND m2.sender_type IN ('ai', 'cs')
    AND DATE(m1.sent_at) = ?
  `).get(today);

  const channelBreakdown = db.prepare(`
    SELECT c.type, COUNT(s.id) as count
    FROM sessions s
    JOIN channels c ON c.id = s.channel_id
    WHERE DATE(s.started_at) = ?
    GROUP BY c.type
  `).all(today);

  const activeConnectors = db.prepare(`
    SELECT COUNT(*) as count FROM api_collections WHERE is_active = 1
  `).get();

  const totalTools = db.prepare(`
    SELECT COUNT(*) as count FROM generated_tools WHERE is_active = 1
  `).get();

  // Weekly trend (last 7 days)
  const weeklyTrend = db.prepare(`
    SELECT DATE(started_at) as date, COUNT(*) as sessions
    FROM sessions
    WHERE started_at >= datetime('now', '-7 days')
    GROUP BY DATE(started_at)
    ORDER BY date ASC
  `).all();

  res.json({
    today: {
      totalSessions: totalSessions.count,
      aiHandled: aiHandled.count,
      escalated: escalated.count,
      activeSessions: activeSessions.count,
      avgResponseTime: Math.round(avgResponseTime.avg_minutes || 0),
    },
    connectors: {
      active: activeConnectors.count,
      totalTools: totalTools.count,
    },
    channelBreakdown,
    weeklyTrend,
  });
});

// GET /api/dashboard/recent-activity
router.get('/recent-activity', authenticate, (req, res) => {
  const db = getDb();
  
  const recentMessages = db.prepare(`
    SELECT m.*, c.name as customer_name, c.channel_type, s.mode
    FROM messages m
    JOIN sessions s ON s.id = m.session_id
    JOIN customers c ON c.id = s.customer_id
    ORDER BY m.sent_at DESC
    LIMIT 20
  `).all();

  res.json(recentMessages);
});

// GET /api/dashboard/active-sessions
router.get('/active-sessions', authenticate, (req, res) => {
  const db = getDb();
  
  const sessions = db.prepare(`
    SELECT s.*, c.name as customer_name, c.channel_type, c.phone,
           ch.type as channel_name, u.name as cs_name
    FROM sessions s
    JOIN customers c ON c.id = s.customer_id
    JOIN channels ch ON ch.id = s.channel_id
    LEFT JOIN users u ON u.id = s.assigned_cs
    WHERE s.status = 'active'
    ORDER BY s.last_message_at DESC
    LIMIT 10
  `).all();

  res.json(sessions);
});

export default router;
