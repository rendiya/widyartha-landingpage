import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// Get all orders (with items summary)
router.get('/', authenticate, (req, res) => {
  try {
    const db = getDb();
    const orders = db.prepare(`
      SELECT o.*, c.name as customer_name, c.phone as customer_phone,
             i.invoice_number, i.status as invoice_status
      FROM orders o
      LEFT JOIN customers c ON o.customer_id = c.id
      LEFT JOIN invoices i ON i.order_id = o.id
      ORDER BY o.created_at DESC
    `).all();

    // Attach order items to each order
    const getItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
    const result = orders.map(order => ({
      ...order,
      items: getItems.all(order.id),
    }));

    res.json(result);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Get order by id (with items)
router.get('/:id', authenticate, (req, res) => {
  try {
    const db = getDb();
    const order = db.prepare(`
      SELECT o.*, c.name as customer_name, c.phone as customer_phone,
             i.invoice_number, i.status as invoice_status
      FROM orders o
      LEFT JOIN customers c ON o.customer_id = c.id
      LEFT JOIN invoices i ON i.order_id = o.id
      WHERE o.id = ?
    `).get(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    
    order.items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
    res.json(order);
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ error: 'Failed to fetch order' });
  }
});

// Cancel/Void an order (Hybrid model: no Accept needed, only Cancel)
router.put('/:id/cancel', authenticate, (req, res) => {
  const { reason } = req.body;
  try {
    const db = getDb();
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.status === 'paid' || order.status === 'shipped') {
      return res.status(400).json({ error: 'Cannot cancel a paid or shipped order' });
    }

    db.transaction(() => {
      // Cancel order
      db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
        .run('cancelled', req.params.id);
      
      // Void associated invoice
      db.prepare('UPDATE invoices SET status = ? WHERE order_id = ?')
        .run('void', req.params.id);

      // Restore stock from order items
      const items = db.prepare('SELECT product_id, quantity FROM order_items WHERE order_id = ?').all(req.params.id);
      for (const item of items) {
        db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(item.quantity, item.product_id);
      }
    })();
    
    res.json({ success: true, message: `Order cancelled${reason ? ': ' + reason : ''}` });
  } catch (error) {
    console.error('Error cancelling order:', error);
    res.status(500).json({ error: 'Failed to cancel order' });
  }
});

// Mark order as shipped (only after paid)
router.put('/:id/ship', authenticate, (req, res) => {
  try {
    const db = getDb();
    const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.status !== 'paid') {
      return res.status(400).json({ error: 'Only paid orders can be marked as shipped' });
    }

    db.prepare('UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run('shipped', req.params.id);
    
    res.json({ success: true, message: 'Order marked as shipped' });
  } catch (error) {
    console.error('Error shipping order:', error);
    res.status(500).json({ error: 'Failed to update order' });
  }
});

export default router;
