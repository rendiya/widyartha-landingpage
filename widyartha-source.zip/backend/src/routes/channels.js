import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { startTelegramBot, stopTelegramBot } from '../channels/telegram.js';
import { startWhatsAppBot, stopWhatsAppBot } from '../channels/whatsapp.js';

const router = express.Router();

// GET /api/channels
router.get('/', authenticate, (req, res) => {
  const db = getDb();
  const channels = db.prepare('SELECT id, type, name, is_active, config, created_at, credentials FROM channels').all();
  res.json(channels.map(c => ({
    id: c.id,
    type: c.type,
    name: c.name,
    is_active: c.is_active,
    config: safeParseJSON(c.config, {}),
    created_at: c.created_at,
    has_credentials: !!c.credentials && c.credentials !== '{}' && c.credentials !== 'null'
  })));
});

// POST /api/channels
router.post('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { type, name, credentials, config } = req.body;
  const result = db.prepare(`
    INSERT INTO channels (type, name, credentials, config)
    VALUES (?, ?, ?, ?)
  `).run(type, name, credentials ? JSON.stringify(credentials) : null, JSON.stringify(config || {}));
  res.status(201).json({ id: result.lastInsertRowid });
});

// PATCH /api/channels/:id
router.patch('/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { name, credentials, config, is_active } = req.body;
  
  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(req.params.id);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  db.prepare(`
    UPDATE channels SET name=?, credentials=?, config=?, is_active=? WHERE id=?
  `).run(
    name || channel.name,
    credentials ? JSON.stringify(credentials) : channel.credentials,
    config ? JSON.stringify(config) : channel.config,
    is_active !== undefined ? (is_active ? 1 : 0) : channel.is_active,
    req.params.id
  );

  const updatedChannel = db.prepare('SELECT * FROM channels WHERE id = ?').get(req.params.id);
  if (updatedChannel.is_active) {
    if (updatedChannel.type === 'telegram') {
      try {
        const creds = JSON.parse(updatedChannel.credentials);
        if (creds.token) startTelegramBot(updatedChannel.id, creds.token);
      } catch {}
    } else if (updatedChannel.type === 'whatsapp') {
      try {
        startWhatsAppBot(updatedChannel.id);
      } catch {}
    }
  }

  res.json({ success: true });
});

// PATCH /api/channels/:id/toggle
router.patch('/:id/toggle', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(req.params.id);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  const newStatus = channel.is_active ? 0 : 1;
  db.prepare('UPDATE channels SET is_active = ? WHERE id = ?').run(newStatus, req.params.id);
  
  if (channel.type === 'telegram') {
    if (newStatus) {
      try {
        const creds = JSON.parse(channel.credentials);
        if (creds.token) startTelegramBot(channel.id, creds.token);
      } catch {}
    } else {
      stopTelegramBot(channel.id);
    }
  } else if (channel.type === 'whatsapp') {
    if (newStatus) {
      try {
        startWhatsAppBot(channel.id);
      } catch {}
    } else {
      stopWhatsAppBot(channel.id, true); // true = hapus folder sesi untuk reset
    }
  }

  res.json({ is_active: Boolean(newStatus) });
});

function safeParseJSON(str, fallback = {}) {
  try { return JSON.parse(str || '{}'); } catch { return fallback; }
}

export default router;
