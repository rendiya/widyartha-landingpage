import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// GET /api/settings
router.get('/', authenticate, (req, res) => {
  const db = getDb();
  const settings = db.prepare('SELECT key, value FROM app_settings').all();
  const obj = {};
  settings.forEach(s => { obj[s.key] = s.value; });
  res.json(obj);
});

// PATCH /api/settings
router.patch('/', authenticate, (req, res) => {
  const db = getDb();
  const settings = req.body;

  const upsert = db.prepare(`
    INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
  `);

  for (const [key, value] of Object.entries(settings)) {
    upsert.run(key, typeof value === 'object' ? JSON.stringify(value) : String(value));
  }

  res.json({ success: true });
});

// GET /api/settings/quick-replies
router.get('/quick-replies', authenticate, (req, res) => {
  const db = getDb();
  const replies = db.prepare('SELECT * FROM quick_replies ORDER BY category, title').all();
  res.json(replies);
});

// POST /api/settings/quick-replies
router.post('/quick-replies', authenticate, (req, res) => {
  const db = getDb();
  const { title, content, category } = req.body;
  const result = db.prepare('INSERT INTO quick_replies (title, content, category) VALUES (?, ?, ?)').run(title, content, category);
  res.status(201).json({ id: result.lastInsertRowid });
});

// DELETE /api/settings/quick-replies/:id
router.delete('/quick-replies/:id', authenticate, (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM quick_replies WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

export default router;
