import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

// GET /api/db-connector
router.get('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const connectors = db.prepare(`
    SELECT id, name, db_type, host, port, database_name, is_active, created_at
    FROM db_connectors ORDER BY created_at DESC
  `).all();
  res.json(connectors);
});

// POST /api/db-connector — Create new DB connector
router.post('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { name, db_type, host, port, database_name, credentials } = req.body;

  const result = db.prepare(`
    INSERT INTO db_connectors (name, db_type, host, port, database_name, credentials)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(name, db_type, host, port || 3306, database_name, credentials ? JSON.stringify(credentials) : null);

  res.status(201).json({ id: result.lastInsertRowid });
});

// POST /api/db-connector/:id/read-schema — Read schema from external DB
router.post('/:id/read-schema', authenticate, requireRole('super_admin', 'admin'), async (req, res) => {
  const db = getDb();
  const connector = db.prepare('SELECT * FROM db_connectors WHERE id = ?').get(req.params.id);
  if (!connector) return res.status(404).json({ error: 'Connector not found' });

  // For demo purposes, return a mock schema
  // In production, this would connect to MySQL/PostgreSQL and read INFORMATION_SCHEMA
  const mockSchema = {
    tables: [
      {
        name: 'tbl_barang',
        columns: [
          { name: 'id', type: 'int', primary_key: true },
          { name: 'nama_barang', type: 'varchar(255)', nullable: false },
          { name: 'kode_sku', type: 'varchar(50)', nullable: true },
          { name: 'kategori', type: 'varchar(100)', nullable: true },
          { name: 'harga_jual', type: 'decimal(10,2)', nullable: false },
          { name: 'stok', type: 'int', nullable: false, default: 0 },
          { name: 'deskripsi', type: 'text', nullable: true },
        ],
        ai_suggestion: 'Kemungkinan tabel katalog produk (similarity: 94%)',
        suggested_mapping: 'product_catalog',
      },
      {
        name: 'tbl_transaksi',
        columns: [
          { name: 'id_transaksi', type: 'int', primary_key: true },
          { name: 'id_customer', type: 'int', nullable: false },
          { name: 'tanggal', type: 'datetime', nullable: false },
          { name: 'total', type: 'decimal(10,2)', nullable: false },
          { name: 'status', type: 'varchar(50)', nullable: false },
        ],
        ai_suggestion: 'Kemungkinan tabel pesanan/transaksi (similarity: 91%)',
        suggested_mapping: 'order_table',
      },
      {
        name: 'tbl_pelanggan',
        columns: [
          { name: 'id_pelanggan', type: 'int', primary_key: true },
          { name: 'nama', type: 'varchar(255)', nullable: false },
          { name: 'no_hp', type: 'varchar(20)', nullable: true },
          { name: 'email', type: 'varchar(255)', nullable: true },
          { name: 'alamat', type: 'text', nullable: true },
        ],
        ai_suggestion: 'Kemungkinan tabel data pelanggan (similarity: 97%)',
        suggested_mapping: 'customer_table',
      },
    ],
    read_at: new Date().toISOString(),
  };

  // Save schema cache
  db.prepare('UPDATE db_connectors SET schema_cache = ? WHERE id = ?')
    .run(JSON.stringify(mockSchema), req.params.id);

  res.json(mockSchema);
});

// POST /api/db-connector/:id/save-mapping — Save schema mapping confirmed by admin
router.post('/:id/save-mapping', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { mapping_config } = req.body;

  db.prepare('UPDATE db_connectors SET mapping_config = ?, is_active = 1 WHERE id = ?')
    .run(JSON.stringify(mapping_config), req.params.id);

  res.json({ success: true });
});

// POST /api/db-connector/:id/query — Execute parameterized query (READ only)
router.post('/:id/query', authenticate, requireRole('super_admin', 'admin'), async (req, res) => {
  const db = getDb();
  const connector = db.prepare('SELECT * FROM db_connectors WHERE id = ?').get(req.params.id);
  if (!connector) return res.status(404).json({ error: 'Connector not found' });

  const { table_mapping, filters = {} } = req.body;
  const mappingConfig = safeParseJSON(connector.mapping_config, {});
  
  // Find the mapped table
  const tableConfig = mappingConfig[table_mapping];
  if (!tableConfig) return res.status(400).json({ error: 'Mapping not found' });

  // Build parameterized query (safe, no raw SQL from AI)
  const tableName = tableConfig.table_name;
  const columnMap = tableConfig.columns || {};

  const conditions = [];
  const values = [];
  
  for (const [key, value] of Object.entries(filters)) {
    const dbColumn = columnMap[key] || key;
    conditions.push(`${dbColumn} = ?`);
    values.push(value);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
  
  // In production: connect to external DB and execute
  // For demo: return mock data
  res.json({
    query_executed: `SELECT * FROM ${tableName} ${whereClause} LIMIT 50`,
    parameters: values,
    note: 'Parameterized query — safe from SQL Injection. Connect external DB to get real data.',
    mock_result: [],
  });
});

// DELETE /api/db-connector/:id
router.delete('/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM db_connectors WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

function safeParseJSON(str, fallback) {
  try { return JSON.parse(str || '{}'); } catch { return fallback; }
}

export default router;
