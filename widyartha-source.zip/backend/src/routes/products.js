import express from 'express';
import multer from 'multer';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

// GET /api/products
router.get('/', authenticate, (req, res) => {
  const db = getDb();
  const { search, category, page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;

  let query = 'SELECT * FROM products WHERE 1=1';
  const params = [];

  if (search) { query += ' AND name LIKE ?'; params.push(`%${search}%`); }
  if (category) { query += ' AND category = ?'; params.push(category); }

  const total = db.prepare(query.replace('SELECT *', 'SELECT COUNT(*) as count')).get(...params);
  query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
  params.push(parseInt(limit), parseInt(offset));

  const products = db.prepare(query).all(...params);
  res.json({ products, total: total.count, page: parseInt(page), limit: parseInt(limit) });
});

// POST /api/products
router.post('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { name, sku, category, price, stock, description } = req.body;
  const result = db.prepare(`
    INSERT INTO products (name, sku, category, price, stock, description)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(name, sku, category, price, stock || 0, description);
  res.status(201).json({ id: result.lastInsertRowid });
});

// PATCH /api/products/:id
router.patch('/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { name, sku, category, price, stock, description } = req.body;
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });

  db.prepare(`
    UPDATE products SET name=?, sku=?, category=?, price=?, stock=?, description=? WHERE id=?
  `).run(name || p.name, sku || p.sku, category || p.category, price ?? p.price, stock ?? p.stock, description || p.description, req.params.id);

  res.json({ success: true });
});

// DELETE /api/products/:id
router.delete('/:id', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// POST /api/products/import — CSV/Excel import
router.post('/import', authenticate, requireRole('super_admin', 'admin'), upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file provided' });

  const content = req.file.buffer.toString('utf-8');
  const lines = content.split('\n').filter(l => l.trim());
  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  
  const db = getDb();
  const insertProduct = db.prepare(`INSERT INTO products (name, sku, category, price, stock, description) VALUES (?, ?, ?, ?, ?, ?)`);
  let imported = 0;

  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim().replace(/^["']|["']$/g, ''));
    const row = {};
    headers.forEach((h, idx) => { row[h] = values[idx]; });

    try {
      insertProduct.run(
        row.name || row.nama || '',
        row.sku || '',
        row.category || row.kategori || '',
        parseFloat(row.price || row.harga || 0),
        parseInt(row.stock || row.stok || 0),
        row.description || row.deskripsi || ''
      );
      imported++;
    } catch { /* skip invalid rows */ }
  }

  res.json({ imported, total: lines.length - 1 });
});

// GET /api/products/categories
router.get('/categories', authenticate, (req, res) => {
  const db = getDb();
  const cats = db.prepare('SELECT DISTINCT category FROM products WHERE category IS NOT NULL ORDER BY category').all();
  res.json(cats.map(c => c.category));
});

export default router;
