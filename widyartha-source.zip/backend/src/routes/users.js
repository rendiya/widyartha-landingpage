import express from 'express';
import bcrypt from 'bcryptjs';
import { getDb } from '../db/database.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = express.Router();

// GET /api/users
router.get('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const users = db.prepare('SELECT id, name, username, role, status, avatar, max_sessions, created_at FROM users ORDER BY created_at DESC').all();
  res.json(users);
});

// POST /api/users
router.post('/', authenticate, requireRole('super_admin', 'admin'), (req, res) => {
  const db = getDb();
  const { name, username, password, role, max_sessions } = req.body;

  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) return res.status(400).json({ error: 'Email sudah digunakan' });

  const hashed = bcrypt.hashSync(password, 10);
  const result = db.prepare(`
    INSERT INTO users (name, username, password, role, max_sessions)
    VALUES (?, ?, ?, ?, ?)
  `).run(name, username, hashed, role || 'cs', max_sessions || 5);

  res.status(201).json({ id: result.lastInsertRowid });
});

// PATCH /api/users/:id
router.patch('/:id', authenticate, (req, res) => {
  const db = getDb();
  // CS can only update themselves
  if (req.user.role === 'cs' && req.user.id !== parseInt(req.params.id)) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  res.json({ success: true });
});

// DELETE /api/users/:id
router.delete('/:id', authenticate, requireRole('super_admin'), (req, res) => {
  const db = getDb();
  if (parseInt(req.params.id) === req.user.id) {
    return res.status(400).json({ error: 'Cannot delete yourself' });
  }
  db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// GET /api/users/online
router.get('/online', authenticate, (req, res) => {
  const db = getDb();
  const users = db.prepare(`
    SELECT id, name, role, status, avatar,
    (SELECT COUNT(*) FROM sessions WHERE assigned_cs = users.id AND status = 'active') as active_sessions
    FROM users WHERE status = 'online'
  `).all();
  res.json(users);
});

export default router;
