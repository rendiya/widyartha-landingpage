import express from 'express';
import { getDb } from '../db/database.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// Get manual payment methods
router.get('/manual', authenticate, (req, res) => {
  try {
    const db = getDb();
    const methods = db.prepare('SELECT * FROM manual_payment_methods ORDER BY created_at DESC').all();
    res.json(methods);
  } catch (error) {
    console.error('Error fetching payment methods:', error);
    res.status(500).json({ error: 'Failed to fetch payment methods' });
  }
});

// Create manual payment method
router.post('/manual', authenticate, (req, res) => {
  const { bank_name, account_no, account_name, instructions } = req.body;
  try {
    const db = getDb();
    const result = db.prepare(`
      INSERT INTO manual_payment_methods (bank_name, account_no, account_name, instructions)
      VALUES (?, ?, ?, ?)
    `).run(bank_name, account_no, account_name, instructions || '');
    res.json({ success: true, id: result.lastInsertRowid });
  } catch (error) {
    console.error('Error creating payment method:', error);
    res.status(500).json({ error: 'Failed to create payment method' });
  }
});

// Update manual payment method status
router.put('/manual/:id', authenticate, (req, res) => {
  const { is_active } = req.body;
  try {
    const db = getDb();
    db.prepare('UPDATE manual_payment_methods SET is_active = ? WHERE id = ?').run(is_active ? 1 : 0, req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update payment method' });
  }
});

// Verify payment
router.post('/verify', authenticate, (req, res) => {
  const { order_id, amount } = req.body;
  try {
    const db = getDb();
    
    db.transaction(() => {
      // Update order
      db.prepare('UPDATE orders SET status = ? WHERE id = ?').run('paid', order_id);
      
      // Update invoice
      db.prepare('UPDATE invoices SET status = ?, paid_at = CURRENT_TIMESTAMP WHERE order_id = ?').run('paid', order_id);
      
      // Add to local ledger
      const invoice = db.prepare('SELECT invoice_number FROM invoices WHERE order_id = ?').get(order_id);
      db.prepare('INSERT INTO local_ledger (type, amount, description, reference_id) VALUES (?, ?, ?, ?)')
        .run('debit', amount, 'Pembayaran Manual', invoice?.invoice_number || `ORD-${order_id}`);
    })();
    
    res.json({ success: true, message: 'Payment verified and recorded in ledger' });
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ error: 'Failed to verify payment' });
  }
});

export default router;
