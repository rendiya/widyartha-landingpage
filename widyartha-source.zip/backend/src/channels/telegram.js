import TelegramBot from 'node-telegram-bot-api';
import { getDb } from '../db/database.js';
import { LLMService } from '../services/llm.service.js';

const activeBots = new Map();
let ioInstance = null;

export function setIoInstance(io) {
  ioInstance = io;
}

export function startTelegramBot(channelId, token) {
  if (activeBots.has(channelId)) {
    stopTelegramBot(channelId);
  }

  console.log(`Starting Telegram Bot for channel ${channelId}`);
  const bot = new TelegramBot(token, { polling: true });

  bot.on('message', async (msg) => {
    const chatId = msg.chat.id.toString();
    const text = msg.text;
    if (!text) return; // Only handle text messages for now

    const name = msg.chat.first_name + (msg.chat.last_name ? ' ' + msg.chat.last_name : '');

    await processIncomingMessage(channelId, chatId, name, text, bot);
  });

  bot.on('polling_error', (err) => {
    console.error(`Telegram Bot ${channelId} polling error:`, err.message);
  });

  activeBots.set(channelId, bot);
}

export function stopTelegramBot(channelId) {
  const bot = activeBots.get(channelId);
  if (bot) {
    console.log(`Stopping Telegram Bot for channel ${channelId}`);
    bot.stopPolling();
    activeBots.delete(channelId);
  }
}

export async function sendTelegramMessage(channelId, chatId, text) {
  const bot = activeBots.get(channelId);
  if (bot) {
    try {
      await bot.sendMessage(chatId, text);
    } catch (err) {
      console.error(`Failed to send Telegram message to ${chatId}:`, err.message);
    }
  } else {
    console.error(`Telegram bot for channel ${channelId} is not active.`);
  }
}

async function processIncomingMessage(channelId, chatId, name, content, bot) {
  try {
    const db = getDb();

    // Find or create customer
    let customer = db.prepare('SELECT * FROM customers WHERE channel_ref = ? AND channel_type = ?').get(chatId, 'telegram');
    if (!customer) {
      const result = db.prepare(`INSERT INTO customers (name, channel_ref, channel_type) VALUES (?, ?, ?)`).run(name, chatId, 'telegram');
      customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(result.lastInsertRowid);
    }

    // Find active session
    let session = db.prepare(`SELECT * FROM sessions WHERE customer_id = ? AND status = 'active'`).get(customer.id);
    if (!session) {
      const result = db.prepare(`INSERT INTO sessions (channel_id, customer_id, mode, status, last_message, last_message_at) VALUES (?, ?, 'ai', 'active', ?, CURRENT_TIMESTAMP)`).run(channelId, customer.id, content);
      session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(result.lastInsertRowid);
    } else {
      db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?').run(content, session.id);
    }

    // Save customer message
    db.prepare(`INSERT INTO messages (session_id, sender_type, content) VALUES (?, 'customer', ?)`).run(session.id, content);

    if (ioInstance) {
      ioInstance.to(`session:${session.id}`).emit('new_message', {
        session_id: session.id,
        sender_type: 'customer',
        content,
        sent_at: new Date().toISOString(),
      });
      ioInstance.emit('session_updated', { sessionId: session.id, lastMessage: content });
    }

    // AI Mode response
    if (session.mode === 'ai') {
      if (ioInstance) ioInstance.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: true });
      bot.sendChatAction(chatId, 'typing').catch(() => { });

      try {
        const llmService = new LLMService();
        const aiResponse = await llmService.chat(session.id, content, { ...session, customer_name: customer.name, channel_type: 'telegram' });

        // Check for escalation
        if (aiResponse.toolCalls?.some(tc => tc.tool === 'escalate_to_cs')) {
          const availableCS = db.prepare(`
            SELECT u.id FROM users u 
            WHERE u.role = 'cs' AND u.status = 'online'
            ORDER BY (SELECT COUNT(*) FROM sessions WHERE assigned_cs = u.id AND status = 'active') ASC
            LIMIT 1
          `).get();

          db.prepare(`UPDATE sessions SET mode = 'human', assigned_cs = ?, escalated_at = CURRENT_TIMESTAMP WHERE id = ?`)
            .run(availableCS?.id || null, session.id);

          if (ioInstance) {
            ioInstance.emit('escalation_alert', {
              sessionId: session.id,
              customerId: session.customer_id,
              assignedCs: availableCS?.id,
              reason: aiResponse.toolCalls.find(tc => tc.tool === 'escalate_to_cs')?.args?.reason,
            });
          }
        }

        // Save AI message
        const result = db.prepare(`INSERT INTO messages (session_id, sender_type, content, tool_calls) VALUES (?, 'ai', ?, ?)`).run(
          session.id,
          aiResponse.content,
          JSON.stringify(aiResponse.toolCalls || [])
        );

        db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run(aiResponse.content, session.id);

        let finalContent = aiResponse.content;
        let imageUrl = null;

        // Parse [IMAGE: url] tag (case-insensitive)
        const imageMatch = finalContent.match(/\[IMAGE:?\s*(.+?)\]/i);
        if (imageMatch) {
          imageUrl = imageMatch[1];
          finalContent = finalContent.replace(imageMatch[0], '').trim();
        }

        if (imageUrl) {
          try {
            await bot.sendPhoto(chatId, imageUrl, { caption: finalContent });
          } catch (e) {
            console.error('Failed to send photo to Telegram:', e);
            await bot.sendMessage(chatId, aiResponse.content);
          }
        } else {
          await bot.sendMessage(chatId, finalContent);
        }

        // Tandai pesan customer sebagai terbaca jika AI berhasil membalas SEBELUM emit
        db.prepare("UPDATE messages SET is_read = 1 WHERE session_id = ? AND sender_type = 'customer'").run(session.id);

        if (ioInstance) {
          ioInstance.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: false });
          ioInstance.to(`session:${session.id}`).emit('new_message', {
            id: result.lastInsertRowid,
            session_id: session.id,
            sender_type: 'ai',
            content: aiResponse.content,
            tool_calls: aiResponse.toolCalls,
            sent_at: new Date().toISOString(),
          });
          ioInstance.emit('session_updated', { sessionId: session.id, lastMessage: aiResponse.content });
        }
      } catch (err) {
        console.error('AI error processing telegram message:', err);
        if (ioInstance) ioInstance.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: false });

        // Eskalasi otomatis jika AI error / offline
        db.prepare(`UPDATE sessions SET mode = 'human', escalated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(session.id);
        const errMsg = `Sistem AI sedang sibuk atau mengalami gangguan (${err.message}). Percakapan ini telah diteruskan ke Customer Service.`;
        db.prepare(`INSERT INTO messages (session_id, sender_type, content) VALUES (?, 'system', ?)`).run(session.id, errMsg);

        await bot.sendMessage(chatId, errMsg).catch(() => { });

        if (ioInstance) {
          ioInstance.emit('session_updated', { sessionId: session.id, lastMessage: errMsg });
        }
      }
    }
  } catch (err) {
    console.error('Telegram process message error:', err);
  }
}
