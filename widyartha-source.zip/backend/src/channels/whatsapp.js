import { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, Browsers } from '@whiskeysockets/baileys';
import pino from 'pino';
import { getDb } from '../db/database.js';
import { LLMService } from '../services/llm.service.js';
import fs from 'fs';
import path from 'path';

const activeBots = new Map();
let ioInstance = null;

export function setIoInstance(io) {
  ioInstance = io;
}

export async function startWhatsAppBot(channelId) {
  if (activeBots.has(channelId)) {
    stopWhatsAppBot(channelId);
  }

  console.log(`Starting WhatsApp Bot for channel ${channelId}`);
  const sessionDir = path.join(process.cwd(), 'data', `wa-session-${channelId}`);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  // Mengambil versi WA Web terbaru untuk mencegah timeout dari server WA
  const { version, isLatest } = await fetchLatestBaileysVersion();
  console.log(`Using WA v${version.join('.')}, isLatest: ${isLatest}`);

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'info' }),
    browser: Browsers.macOS('Desktop'),
    syncFullHistory: false,
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      if (ioInstance) {
        ioInstance.emit('wa_qr_code', { channelId, qr });
      }
    }
    if (connection === 'close') {
      const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
      console.log(`WhatsApp connection closed for channel ${channelId}. Reconnecting: ${shouldReconnect}`);
      if (shouldReconnect) {
        startWhatsAppBot(channelId);
      } else {
        console.log(`WhatsApp logged out for channel ${channelId}. Session deleted.`);
        fs.rmSync(sessionDir, { recursive: true, force: true });
        activeBots.delete(channelId);
      }
    } else if (connection === 'open') {
      console.log(`WhatsApp opened successfully for channel ${channelId}`);
      if (ioInstance) {
        ioInstance.emit('wa_connected', { channelId });
      }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type === 'notify') {
      for (const msg of messages) {
        if (!msg.message || msg.key.fromMe) continue;

        const text = msg.message.conversation ||
          msg.message.extendedTextMessage?.text ||
          msg.message.imageMessage?.caption;
        if (!text) continue;

        const chatId = msg.key.remoteJid;
        const name = msg.pushName || chatId.split('@')[0];

        await processIncomingMessage(channelId, chatId, name, text, sock);
      }
    }
  });

  activeBots.set(channelId, sock);
}

export function stopWhatsAppBot(channelId, clearSession = false) {
  const sock = activeBots.get(channelId);
  if (sock) {
    console.log(`Stopping WhatsApp Bot for channel ${channelId}`);
    try {
      sock.logout().catch(() => { });
    } catch (e) { }

    // Force close websocket and listeners so it doesn't hang
    sock.ev.removeAllListeners();
    if (sock.ws) sock.ws.close();

    activeBots.delete(channelId);
  }

  // Hanya hapus sesi jika user menekan tombol Matikan/Reset (clearSession = true)
  // Jangan hapus jika ini cuma auto-reconnect karena internet putus sementara.
  if (clearSession) {
    const sessionDir = path.join(process.cwd(), 'data', `wa-session-${channelId}`);
    try {
      if (fs.existsSync(sessionDir)) {
        fs.rmSync(sessionDir, { recursive: true, force: true });
        console.log(`Session deleted for channel ${channelId}`);
      }
    } catch (e) {
      console.error(`Failed to delete session dir for ${channelId}:`, e);
    }
  }
}

export async function sendWhatsAppMessage(channelId, chatId, text) {
  const sock = activeBots.get(channelId);
  if (sock) {
    try {
      await sock.sendMessage(chatId, { text });
    } catch (err) {
      console.error(`Failed to send WhatsApp message to ${chatId}:`, err.message);
    }
  } else {
    console.error(`WhatsApp bot for channel ${channelId} is not active.`);
  }
}

async function processIncomingMessage(channelId, chatId, name, content, bot) {
  try {
    const db = getDb();

    // Find or create customer
    let customer = db.prepare('SELECT * FROM customers WHERE channel_ref = ? AND channel_type = ?').get(chatId, 'whatsapp');
    if (!customer) {
      const result = db.prepare(`INSERT INTO customers (name, channel_ref, channel_type) VALUES (?, ?, ?)`).run(name, chatId, 'whatsapp');
      customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(result.lastInsertRowid);
    }

    // Find active session
    let session = db.prepare(`SELECT * FROM sessions WHERE customer_id = ? AND status = 'active'`).get(customer.id);
    if (!session) {
      const result = db.prepare(`INSERT INTO sessions (channel_id, customer_id, mode, status, last_message, last_message_at) VALUES (?, ?, 'ai', 'active', ?, CURRENT_TIMESTAMP)`).run(channelId, customer.id, content);
      session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(result.lastInsertRowid);
    } else {
      db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?').run(content, session.id);
    }

    // Save customer message
    db.prepare(`INSERT INTO messages (session_id, sender_type, content) VALUES (?, 'customer', ?)`).run(session.id, content);

    if (ioInstance) {
      ioInstance.to(`session:${session.id}`).emit('new_message', {
        session_id: session.id,
        sender_type: 'customer',
        content,
        sent_at: new Date().toISOString(),
      });
      ioInstance.emit('session_updated', { sessionId: session.id, lastMessage: content });
    }

    // AI Mode response
    if (session.mode === 'ai') {
      if (ioInstance) ioInstance.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: true });
      await bot.sendPresenceUpdate('composing', chatId).catch(() => { });

      try {
        const llmService = new LLMService();
        const aiResponse = await llmService.chat(session.id, content, { ...session, customer_name: customer.name, channel_type: 'whatsapp' });

        // Check for escalation
        if (aiResponse.toolCalls?.some(tc => tc.tool === 'escalate_to_cs')) {
          const availableCS = db.prepare(`
            SELECT u.id FROM users u 
            WHERE u.role = 'cs' AND u.status = 'online'
            ORDER BY (SELECT COUNT(*) FROM sessions WHERE assigned_cs = u.id AND status = 'active') ASC
            LIMIT 1
          `).get();

          db.prepare(`UPDATE sessions SET mode = 'human', assigned_cs = ?, escalated_at = CURRENT_TIMESTAMP WHERE id = ?`)
            .run(availableCS?.id || null, session.id);

          if (ioInstance) {
            ioInstance.emit('escalation_alert', {
              sessionId: session.id,
              customerId: session.customer_id,
              assignedCs: availableCS?.id,
              reason: aiResponse.toolCalls.find(tc => tc.tool === 'escalate_to_cs')?.args?.reason,
            });
          }
        }

        // Save AI message
        const result = db.prepare(`INSERT INTO messages (session_id, sender_type, content, tool_calls) VALUES (?, 'ai', ?, ?)`).run(
          session.id,
          aiResponse.content,
          JSON.stringify(aiResponse.toolCalls || [])
        );

        db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?')
          .run(aiResponse.content, session.id);

        let finalContent = aiResponse.content;
        let imageUrl = null;

        // Parse [IMAGE: url] tag (case-insensitive)
        const imageMatch = finalContent.match(/\[IMAGE:?\s*(.+?)\]/i);
        if (imageMatch) {
          imageUrl = imageMatch[1];
          finalContent = finalContent.replace(imageMatch[0], '').trim();
        }

        if (imageUrl) {
          try {
            const isLocal = !imageUrl.startsWith('http');
            const imagePayload = isLocal ? fs.readFileSync(imageUrl) : { url: imageUrl };
            await bot.sendMessage(chatId, { image: imagePayload, caption: finalContent });
          } catch (e) {
            console.error('Failed to send image:', e.message);
            await bot.sendMessage(chatId, { text: finalContent + '\n\n(Gagal memuat gambar invoice)' });
          }
        } else {
          await bot.sendMessage(chatId, { text: finalContent });
        }

        // Tandai pesan customer sebagai terbaca jika AI berhasil membalas SEBELUM emit
        db.prepare("UPDATE messages SET is_read = 1 WHERE session_id = ? AND sender_type = 'customer'").run(session.id);

        if (ioInstance) {
          ioInstance.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: false });
          ioInstance.to(`session:${session.id}`).emit('new_message', {
            id: result.lastInsertRowid,
            session_id: session.id,
            sender_type: 'ai',
            content: aiResponse.content,
            tool_calls: aiResponse.toolCalls,
            sent_at: new Date().toISOString(),
          });
          ioInstance.emit('session_updated', { sessionId: session.id, lastMessage: aiResponse.content });
        }
      } catch (err) {
        console.error('AI error processing whatsapp message:', err);
        if (ioInstance) ioInstance.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: false });

        // Eskalasi otomatis jika AI error / offline
        db.prepare(`UPDATE sessions SET mode = 'human', escalated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(session.id);
        const errMsg = `Sistem AI sedang sibuk atau mengalami gangguan (${err.message}). Percakapan ini telah diteruskan ke Customer Service.`;
        db.prepare(`INSERT INTO messages (session_id, sender_type, content) VALUES (?, 'system', ?)`).run(session.id, errMsg);

        await bot.sendMessage(chatId, { text: errMsg }).catch(() => { });

        if (ioInstance) {
          ioInstance.emit('session_updated', { sessionId: session.id, lastMessage: errMsg });
        }
      }
    }
  } catch (err) {
    console.error('WhatsApp process message error:', err);
  }
}
