import axios from 'axios';
import { OpenAI } from 'openai';
import { getDb } from '../db/database.js';
import fs from 'fs';
import path from 'path';
import puppeteer from 'puppeteer';

const OLLAMA_URL = process.env.OLLAMA_URL || 'http://127.0.0.1:11434';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen2.5:3b';

export class LLMService {
  constructor() {
    this.db = getDb();
  }

  // Get active LLM config
  getSetting(key, defaultValue) {
    try {
      const row = this.db.prepare("SELECT value FROM app_settings WHERE key = ?").get(key);
      return row ? row.value : defaultValue;
    } catch (e) { return defaultValue; }
  }

  // Get active LLM config
  getActiveLLM() {
    const config = this.db.prepare(`
      SELECT * FROM llm_configs WHERE is_active = 1 ORDER BY priority DESC LIMIT 1
    `).get();
    return config || { provider: 'ollama', model: OLLAMA_MODEL, base_url: OLLAMA_URL };
  }

  // Get all active tools (built-in + dynamic)
  getActiveTools() {
    const dynamicTools = this.db.prepare(`
      SELECT gt.*, ac.base_url, ac.auth_type, ac.auth_config
      FROM generated_tools gt
      JOIN api_collections ac ON ac.id = gt.collection_id
      WHERE gt.is_active = 1 AND ac.is_active = 1
    `).all();

    const builtinTools = this.getBuiltinTools();

    return [...builtinTools, ...dynamicTools.map(t => ({
      ...t,
      tool_definition: this.safeParseJSON(t.tool_definition, {}),
    }))];
  }

  // Built-in tools always available
  getBuiltinTools() {
    return [
      {
        id: 'builtin_products',
        name: 'get_products_local',
        description: 'Ambil daftar produk dari katalog lokal Widyartha',
        is_builtin: true,
        tool_definition: {
          type: 'function',
          function: {
            name: 'get_products_local',
            description: 'Ambil daftar produk yang tersedia dari katalog lokal. WAJIB dipanggil jika pelanggan ingin memesan spesifik untuk mendapatkan product_id',
            parameters: {
              type: 'object',
              properties: {
                search: { type: 'string', description: 'Kata kunci pencarian produk' },
                category: { type: 'string', description: 'Kategori produk' },
              },
            },
          },
        },
      },
      {
        id: 'builtin_hours',
        name: 'get_operating_hours',
        description: 'Cek jam operasional bisnis',
        is_builtin: true,
        tool_definition: {
          type: 'function',
          function: {
            name: 'get_operating_hours',
            description: 'Cek jam operasional dan apakah sekarang sedang buka',
            parameters: { type: 'object', properties: {} },
          },
        },
      },
      {
        id: 'builtin_escalate',
        name: 'escalate_to_cs',
        description: 'Eskalasi percakapan ke CS manusia',
        is_builtin: true,
        tool_definition: {
          type: 'function',
          function: {
            name: 'escalate_to_cs',
            description: 'Eskalasikan percakapan ke customer service manusia jika pertanyaan tidak bisa dijawab AI',
            parameters: {
              type: 'object',
              properties: {
                reason: { type: 'string', description: 'Alasan eskalasi' },
              },
            },
          },
        },
      },
      {
        id: 'builtin_create_order',
        name: 'create_order',
        description: 'Buat pesanan baru dan invoice secara otomatis untuk pelanggan',
        is_builtin: true,
        tool_definition: {
          type: 'function',
          function: {
            name: 'create_order',
            description: 'Buat pesanan dan tagihan otomatis. WAJIB tahu product_id. JIKA PELANGGAN LANGSUNG PESAN, cari dulu dengan get_products_local!',
            parameters: {
              type: 'object',
              properties: {
                product_id: { type: 'number', description: 'ID produk yang dipesan' },
                quantity: { type: 'number', description: 'Jumlah produk yang dipesan' },
                shipping_address: { type: 'string', description: 'Alamat pengiriman (opsional)' },
                customer_id: { type: 'number', description: 'ID pelanggan (jika ada, biarkan kosong)' }
              },
              required: ['product_id', 'quantity']
            }
          }
        }
      }
    ];
  }

  // Execute built-in tool
  async executeBuiltinTool(toolName, args, sessionId) {
    switch (toolName) {
      case 'get_products_local': {
        let query = 'SELECT * FROM products WHERE 1=1';
        const params = [];
        if (args.search) {
          query += ' AND (name LIKE ? OR category LIKE ? OR description LIKE ?)';
          params.push(`%${args.search}%`, `%${args.search}%`, `%${args.search}%`);
        }
        if (args.category) {
          query += ' AND category LIKE ?';
          params.push(`%${args.category}%`);
        }
        query += ' LIMIT 10';
        const products = this.db.prepare(query).all(...params);
        return { products, total: products.length };
      }
      case 'get_operating_hours': {
        const start = this.db.prepare("SELECT value FROM app_settings WHERE key = 'operating_hours_start'").get();
        const end = this.db.prepare("SELECT value FROM app_settings WHERE key = 'operating_hours_end'").get();
        const now = new Date();
        const nowTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const isOpen = nowTime >= (start?.value || '08:00') && nowTime <= (end?.value || '17:00');
        return { is_open: isOpen, hours: `${start?.value} - ${end?.value}`, current_time: nowTime };
      }
      case 'escalate_to_cs':
        return { escalated: true, reason: args.reason || 'Permintaan pelanggan' };
      case 'create_order': {
        const productId = args.product_id;
        const quantity = args.quantity || 1;
        const address = args.shipping_address || '-';
        let customerId = args.customer_id;

        const product = this.db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
        if (!product) return { error: 'Product not found' };

        // Check stock availability
        if (product.stock < quantity) {
          return { error: `Stok tidak cukup. Stok tersedia: ${product.stock}, diminta: ${quantity}` };
        }

        const totalAmount = product.price * quantity;

        if (!customerId && sessionId) {
          const session = this.db.prepare('SELECT customer_id FROM sessions WHERE id = ?').get(sessionId);
          if (session) customerId = session.customer_id;
        }
        if (!customerId) return { error: 'Customer ID not found in session' };

        const customer = this.db.prepare('SELECT name FROM customers WHERE id = ?').get(customerId);

        // Use transaction for atomicity
        const invoiceNumber = 'INV-' + Date.now().toString().slice(-6) + Math.floor(Math.random() * 100);
        let invoiceId;

        this.db.transaction(() => {
          // Insert order
          const resultOrder = this.db.prepare(`
             INSERT INTO orders (session_id, customer_id, total_amount, status, shipping_address)
             VALUES (?, ?, ?, 'pending', ?)
          `).run(sessionId, customerId, totalAmount, address);
          const orderId = resultOrder.lastInsertRowid;

          // Insert order items
          this.db.prepare(`
             INSERT INTO order_items (order_id, product_id, product_name, product_sku, quantity, unit_price, subtotal)
             VALUES (?, ?, ?, ?, ?, ?, ?)
          `).run(orderId, product.id, product.name, product.sku || '-', quantity, product.price, totalAmount);

          // Decrement stock
          this.db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(quantity, product.id);

          // Insert invoice
          const invoiceResult = this.db.prepare(`
             INSERT INTO invoices (order_id, invoice_number, amount_due, status)
             VALUES (?, ?, ?, 'unpaid')
          `).run(orderId, invoiceNumber, totalAmount);
          invoiceId = invoiceResult.lastInsertRowid;
        })();

        const paymentMethods = this.db.prepare('SELECT * FROM manual_payment_methods WHERE is_active = 1').all();
        const paymentInfo = paymentMethods.map(pm => `${pm.bank_name}: ${pm.account_no} a/n ${pm.account_name}`).join(' | ');

        // Generate Invoice Image URL via QuickChart
        const appName = this.db.prepare("SELECT value FROM app_settings WHERE key = 'app_name'").get()?.value || 'Widyartha';
        const html = `
          <div style="font-family: Arial, sans-serif; padding: 30px; background: #ffffff; width: 600px; height: auto; border: 1px solid #ddd; box-sizing: border-box;">
            <div style="text-align: center; border-bottom: 2px dashed #ddd; padding-bottom: 20px; margin-bottom: 20px;">
              <h1 style="margin: 0; color: #333; font-size: 28px;">${appName}</h1>
              <p style="margin: 5px 0 0 0; color: #777; font-size: 14px;">INVOICE PEMBAYARAN</p>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 14px;">
              <div>
                <strong>Kepada:</strong><br/>
                ${customer ? customer.name : 'Pelanggan'}<br/>
                ${address}
              </div>
              <div style="text-align: right;">
                <strong>No. Invoice:</strong> ${invoiceNumber}<br/>
                <strong>Status:</strong> <span style="color: red;">BELUM DIBAYAR</span>
              </div>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px;">
              <tr style="background: #f8f9fa;">
                <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Produk</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: center;">Qty</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Harga</th>
                <th style="padding: 10px; border: 1px solid #ddd; text-align: right;">Subtotal</th>
              </tr>
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">${product.name} (${product.sku || '-'})</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: center;">${quantity}</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">Rp ${product.price.toLocaleString()}</td>
                <td style="padding: 10px; border: 1px solid #ddd; text-align: right;">Rp ${totalAmount.toLocaleString()}</td>
              </tr>
            </table>
            <div style="text-align: right; font-size: 18px; margin-bottom: 30px;">
              <strong>Total Tagihan: Rp ${totalAmount.toLocaleString()}</strong>
            </div>
            <div style="font-size: 12px; color: #555; background: #f1f5f9; padding: 15px; border-radius: 6px;">
              <strong>Instruksi Pembayaran:</strong><br/>
              ${paymentInfo}
            </div>
          </div>
        `;
        const invoiceFilename = `invoice_${invoiceNumber}.png`;
        const invoicePath = path.join(process.cwd(), 'data', invoiceFilename);

        let imageUrl = '';
        try {
          const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox'] });
          const page = await browser.newPage();
          await page.setViewport({ width: 600, height: 500 });
          await page.setContent(html);
          const element = await page.$('div');
          await element.screenshot({ path: invoicePath });
          await browser.close();
          imageUrl = invoicePath; // Use absolute local path
        } catch (err) {
          console.error('Failed to generate image via Puppeteer:', err.message);
          // Fallback to viewing via browser
          const appUrl = process.env.APP_URL || 'http://localhost:3000';
          imageUrl = `${appUrl}/api/invoices/${invoiceId}/html`;
        }

        return {
          success: true,
          message: this.getSetting("msg_order_success", "Berhasil membuat pesanan. Beri tahu pelanggan bahwa pesanan sukses dan rincian tagihan beserta cara bayar telah dikirimkan otomatis oleh sistem."),
          _system_data: {
            invoice_number: invoiceNumber,
            amount_due: totalAmount,
            payment_instructions: paymentInfo,
            invoice_image_url: imageUrl.endsWith('/html') ? null : imageUrl,
            invoice_url: imageUrl.endsWith('/html') ? imageUrl : null
          }
        };
      }
      default:
        return { error: 'Unknown built-in tool' };
    }
  }

  // Execute dynamic tool (API call)
  async executeDynamicTool(tool, args) {
    const toolDef = this.safeParseJSON(tool.tool_definition, {});
    let endpoint = tool.endpoint || '';

    // Replace path parameters
    for (const [key, value] of Object.entries(args)) {
      endpoint = endpoint.replace(`{${key}}`, encodeURIComponent(value));
      endpoint = endpoint.replace(`:${key}`, encodeURIComponent(value));
    }

    const authConfig = this.safeParseJSON(tool.auth_config, {});
    const headers = this.safeParseJSON(tool.headers, {});

    // Apply auth
    if (tool.auth_type === 'bearer' && authConfig.token) {
      headers['Authorization'] = `Bearer ${authConfig.token}`;
    } else if (tool.auth_type === 'api_key' && authConfig.key) {
      headers[authConfig.header || 'X-API-Key'] = authConfig.key;
    }

    const baseUrl = tool.base_url || '';
    const fullUrl = endpoint.startsWith('http') ? endpoint : `${baseUrl}${endpoint}`;

    const requestConfig = {
      method: tool.method || 'GET',
      url: fullUrl,
      headers,
      timeout: 10000,
    };

    // For GET: query params, for POST/PUT/PATCH: body
    if (['GET', 'DELETE'].includes(tool.method?.toUpperCase() || 'GET')) {
      // Remove path params already substituted
      const queryArgs = {};
      for (const [k, v] of Object.entries(args)) {
        if (!endpoint.includes(encodeURIComponent(v))) {
          queryArgs[k] = v;
        }
      }
      if (Object.keys(queryArgs).length > 0) requestConfig.params = queryArgs;
    } else {
      requestConfig.data = args;
    }

    const response = await axios(requestConfig);
    return response.data;
  }

  // Process tool calls from AI response
  async processToolCalls(toolCalls, sessionId) {
    const allTools = this.getActiveTools();
    const results = [];

    for (const call of toolCalls) {
      const toolName = call.function?.name || call.name;
      const args = this.safeParseJSON(
        typeof call.function?.arguments === 'string' ? call.function.arguments : JSON.stringify(call.function?.arguments || {}),
        {}
      );

      const startTime = Date.now();
      let result = null;
      let status = 'success';

      try {
        const tool = allTools.find(t => t.name === toolName);
        if (!tool) throw new Error(`Tool '${toolName}' not found`);

        if (tool.is_builtin) {
          result = await this.executeBuiltinTool(toolName, args, sessionId);
        } else {
          result = await this.executeDynamicTool(tool, args);
        }
      } catch (err) {
        result = { error: err.message };
        status = 'error';
      }

      const duration = Date.now() - startTime;

      // Log tool call
      if (sessionId) {
        try {
          this.db.prepare(`
            INSERT INTO tool_call_logs (session_id, tool_name, arguments, result, status, duration_ms)
            VALUES (?, ?, ?, ?, ?, ?)
          `).run(sessionId, toolName, JSON.stringify(args), JSON.stringify(result), status, duration);
        } catch (_) { }
      }

      results.push({ tool: toolName, args, result, status });
    }

    return results;
  }

  // Build tool definitions for LLM
  buildToolDefinitions(tools) {
    return tools.map(t => {
      if (t.is_builtin && t.tool_definition?.function) {
        return t.tool_definition;
      }
      const td = this.safeParseJSON(t.tool_definition, {});
      if (td.function) return td;

      // Build from scratch
      return {
        type: 'function',
        function: {
          name: t.name,
          description: t.description,
          parameters: td.parameters || { type: 'object', properties: {} },
        },
      };
    });
  }

  // Main chat method
  async chat(sessionId, userMessage, session) {
    const config = this.getActiveLLM();
    const activeTools = this.getActiveTools();
    const toolDefs = this.buildToolDefinitions(activeTools);

    // Get conversation history
    const history = this.db.prepare(`
      SELECT sender_type, content FROM messages
      WHERE session_id = ? ORDER BY sent_at DESC LIMIT 20
    `).all(sessionId).reverse();

    // Get AI memory for customer
    const memory = this.db.prepare(`
      SELECT summary FROM ai_memory WHERE customer_id = ?
    `).get(session.customer_id);

    const systemPrompt = this.getSystemPrompt(memory?.summary);

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(m => ({
        role: m.sender_type === 'customer' ? 'user' : 'assistant',
        content: m.content.replace(/\[IMAGE:?[\s\S]*/gi, '[Gambar Invoice Terlampir]'),
      })),
      { role: 'user', content: userMessage },
    ];

    try {
      let currentMessages = [...messages];
      let response = await this.callLLM(config, currentMessages, toolDefs);
      let allToolResults = [];
      let finalContent = response.content?.trim() || '';
      let loopCount = 0;
      const MAX_LOOPS = 5;

      // Handle tool calls in a loop to support sequential calls (e.g. search -> create order)
      while (response.tool_calls && response.tool_calls.length > 0 && loopCount < MAX_LOOPS) {
        loopCount++;
        const toolResults = await this.processToolCalls(response.tool_calls, sessionId);
        allToolResults.push(...toolResults);

        // Filter out _system_data so AI doesn't get overwhelmed with huge text
        const cleanToolResults = toolResults.map(tr => {
          const { _system_data, ...rest } = tr.result || {};
          return { tool: tr.tool, result: rest, original_result: tr.result };
        });

        // Send tool results back to LLM
        currentMessages = [
          ...currentMessages,
          { role: 'assistant', content: response.content || '', tool_calls: response.tool_calls },
          ...cleanToolResults.map(tr => ({
            role: 'tool',
            tool_call_id: tr.tool || 'tool',
            content: JSON.stringify(tr.result),
          })),
        ];

        response = await this.callLLM(config, currentMessages, toolDefs);
        finalContent = response.content?.trim() || '';
      }

      if (allToolResults.length > 0) {
        // Coba retry 1x jika AI membalas kosong
        if (!finalContent) {
          currentMessages.push({ role: 'assistant', content: '' });
          currentMessages.push({ role: 'user', content: 'Anda belum merangkum hasil eksekusi alat kepada pelanggan. Silakan berikan balasan Anda sekarang.' });

          let retryResponse = await this.callLLM(config, currentMessages, toolDefs);
          finalContent = retryResponse.content?.trim() || '';
        }

        if (!finalContent) {
          // Jika masih kosong setelah di-retry, gunakan pesan sukses bawaan dari alat terakhir
          finalContent = allToolResults[allToolResults.length - 1]?.result?.message || this.getSetting('msg_system_error', 'Maaf, terjadi kesalahan saat memproses.');
        }

        // Append system data directly to user output
        const sysResult = allToolResults.find(tr => tr.result?._system_data);
        if (sysResult) {
          const data = sysResult.result._system_data;
          if (data.payment_instructions) {
            finalContent += `\n\n${this.getSetting('msg_invoice_header', '*-- PESAN SISTEM OTOMATIS --*\nBerikut adalah rincian tagihan Anda:')}\n- ${this.getSetting('msg_invoice_number', 'Nomor Invoice')}: ${data.invoice_number}\n- ${this.getSetting('msg_invoice_total', 'Total Tagihan')}: Rp ${data.amount_due.toLocaleString('id-ID')}\n\n*${this.getSetting('msg_payment_instructions', 'Instruksi Pembayaran')}*:\n${data.payment_instructions}`;
          }
          if (data.invoice_image_url) {
            finalContent += `\n\n[IMAGE: ${data.invoice_image_url}]`;
          }
          if (data.invoice_url) {
            finalContent += `\n\nAtau lihat tagihan Anda melalui link berikut:\n${data.invoice_url}`;
          }
        }

        return {
          content: finalContent,
          toolCalls: allToolResults,
        };
      }

      return {
        content: finalContent || 'Maaf, saya tidak dapat menjawab saat ini.',
        toolCalls: [],
      };
    } catch (err) {
      console.error('LLM error:', err.message);
      // Try fallback
      const fallback = this.db.prepare("SELECT * FROM llm_configs WHERE is_fallback = 1 AND provider = 'ollama'").get();
      if (fallback && config.provider !== 'ollama') {
        try {
          return await this.callOllama({ ...fallback, base_url: OLLAMA_URL }, messages, toolDefs);
        } catch (fallbackErr) {
          throw new Error(fallbackErr.message || err.message);
        }
      }
      throw err;
    }
  }

  // Test drive — only for specific collection tools
  async testDrive(message, history, tools) {
    const config = this.getActiveLLM();
    const toolDefs = this.buildToolDefinitions(tools.map(t => ({
      ...t,
      tool_definition: this.safeParseJSON(t.tool_definition, {}),
    })));

    const systemPrompt = this.getSetting('prompt_test_drive', 'Kamu adalah agen customer service yang helpful. Gunakan tools yang tersedia untuk menjawab pertanyaan.');
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: message },
    ];

    const response = await this.callLLM(config, messages, toolDefs);

    if (response.tool_calls && response.tool_calls.length > 0) {
      const toolResults = await this.processToolCalls(response.tool_calls, null);
      const followupMessages = [
        ...messages,
        { role: 'assistant', content: response.content || '', tool_calls: response.tool_calls },
        ...toolResults.map(tr => ({
          role: 'tool',
          tool_call_id: tr.tool || 'tool',
          content: JSON.stringify(tr.result),
        })),
      ];
      const final = await this.callLLM(config, followupMessages, toolDefs);
      return { content: final.content, toolCalls: toolResults };
    }

    return { content: response.content, toolCalls: [] };
  }

  // Dashboard AI assistant
  async assistantChat(message, history) {
    const config = this.getActiveLLM();
    const baseAssistant = this.getSetting('prompt_assistant', 'Kamu adalah asisten admin Widyartha. Kamu membantu admin dalam mengonfigurasi sistem, menganalisis data, dan troubleshooting.');
    const systemPrompt = `${baseAssistant} Sistem memiliki ${this.db.prepare("SELECT COUNT(*) as c FROM api_collections WHERE is_active=1").get().c} connector aktif dan ${this.db.prepare("SELECT COUNT(*) as c FROM sessions WHERE status='active'").get().c} sesi aktif.`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: message },
    ];

    const response = await this.callLLM(config, messages, []);
    return { content: response.content };
  }

  async callLLM(config, messages, tools) {
    switch (config.provider) {
      case 'ollama': return this.callOllama(config, messages, tools);
      case 'openai': return this.callOpenAI(config, messages, tools);
      case 'anthropic': return this.callAnthropic(config, messages, tools);
      case 'gemini': return this.callGemini(config, messages, tools);
      case 'sumopod': return this.callOpenAI(config, messages, tools);
      default: return this.callOllama(config, messages, tools);
    }
  }

  async callOllama(config, messages, tools) {
    const baseUrl = config.base_url || OLLAMA_URL;
    const model = config.model || OLLAMA_MODEL;

    const payload = {
      model,
      messages,
      stream: false,
      options: { temperature: 0.7 },
    };

    if (tools && tools.length > 0) {
      payload.tools = tools;
    }

    let response;
    try {
      response = await axios.post(`${baseUrl}/api/chat`, payload, { timeout: 180000 });
    } catch (err) {
      if (err.response?.status === 404) {
        throw new Error(`Model '${model}' tidak ditemukan di server Ollama. Silakan unduh model ini terlebih dahulu.`);
      }
      const errorMsg = err.response?.data?.error || err.message;

      // Handle Ollama internal JSON error due to bad model tool generation or EOF model crashes
      if (errorMsg && (errorMsg.includes("looks like object") || errorMsg.includes("closing '}' symbol") || errorMsg.includes("JSON") || errorMsg.includes("EOF"))) {
        console.warn(`[Ollama] Model generated invalid tool call JSON: ${errorMsg}.`);
        if (tools && tools.length > 0) {
          console.warn(`[Ollama] Retrying without tools...`);
          return await this.callOllama(config, messages, []);
        } else {
          console.warn(`[Ollama] Error still persists without tools. Returning fallback message.`);
          return {
            content: "Mohon maaf, AI kami sedang mengalami sedikit gangguan format saat mencoba menjawab. Bisakah Anda mengulangi atau mengubah sedikit pertanyaannya?",
            tool_calls: []
          };
        }
      }

      throw new Error(errorMsg);
    }
    const msg = response.data?.message;

    let content = msg?.content || '';
    let tool_calls = msg?.tool_calls || [];

    // Fallback parser for raw XML/text tool calls if the model failed to use native tool calling
    if (tool_calls.length === 0 && content.includes('<tool_name>')) {
      const toolNameMatch = content.match(/<tool_name>(.*?)<\/tool_name>/);
      const toolArgsMatch = content.match(/<parameters>(.*?)<\/parameters>/s);

      if (toolNameMatch) {
        tool_calls.push({
          function: {
            name: toolNameMatch[1].trim(),
            arguments: toolArgsMatch ? toolArgsMatch[1].trim() : "{}"
          }
        });
        content = content.replace(/<tool_name>.*?<\/tool_name>/g, '').replace(/<parameters>.*?<\/parameters>/gs, '').trim();
      }
    }

    // Fallback for <tool_call> JSON </tool_call> format
    if (tool_calls.length === 0 && content.includes('<tool_call>')) {
      const match = content.match(/<tool_call>(.*?)<\/tool_call>/s);
      if (match) {
        try {
          const parsed = JSON.parse(match[1]);
          tool_calls.push({
            function: {
              name: parsed.name,
              arguments: typeof parsed.arguments === 'string' ? parsed.arguments : JSON.stringify(parsed.arguments || {})
            }
          });
          content = content.replace(/<tool_call>.*?<\/tool_call>/gs, '').trim();
        } catch (e) { }
      }
    }

    return {
      content: content,
      tool_calls: tool_calls,
    };
  }

  async callOpenAI(config, messages, tools) {
    const isSumopod = config.provider === 'sumopod';
    const apiKey = config.api_key;
    const baseURL = config.base_url || (isSumopod ? 'https://ai.sumopod.com/v1' : undefined);

    const openai = new OpenAI({
      apiKey,
      baseURL,
    });

    const payload = {
      model: config.model || 'gpt-4o',
      messages,
    };
    if (tools && tools.length > 0) payload.tools = tools;

    try {
      const response = await openai.chat.completions.create(payload);
      const choice = response.choices?.[0]?.message;
      if (!choice) return { content: '', toolCalls: [] };
      
      let toolCalls = [];
      if (choice.tool_calls && choice.tool_calls.length > 0) {
        toolCalls = choice.tool_calls.map(t => ({
          tool: t.id,
          name: t.function.name,
          args: JSON.parse(t.function.arguments || '{}'),
        }));
      }

      return {
        content: choice.content || '',
        toolCalls,
      };
    } catch (err) {
      console.error(`[${isSumopod ? 'Sumopod' : 'OpenAI'}] Error:`, err.message);
      throw err;
    }
  }

  async callAnthropic(config, messages, tools) {
    const apiKey = config.api_key;
    const systemMsg = messages.find(m => m.role === 'system');
    const chatMessages = messages.filter(m => m.role !== 'system');

    const payload = {
      model: config.model || 'claude-sonnet-4-6',
      max_tokens: 4096,
      system: systemMsg?.content || '',
      messages: chatMessages,
    };
    if (tools && tools.length > 0) {
      payload.tools = tools.map(t => ({
        name: t.function?.name || t.name,
        description: t.function?.description || t.description,
        input_schema: t.function?.parameters || { type: 'object', properties: {} },
      }));
    }

    let response;
    try {
      response = await axios.post('https://api.anthropic.com/v1/messages', payload, {
        headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json' },
        timeout: 60000,
      });
    } catch (err) {
      throw new Error(err.response?.data?.error?.message || err.message);
    }

    const content = response.data?.content || [];
    const textContent = content.find(c => c.type === 'text')?.text || '';
    const toolUses = content.filter(c => c.type === 'tool_use').map(c => ({
      function: { name: c.name, arguments: JSON.stringify(c.input) },
    }));

    return { content: textContent, tool_calls: toolUses };
  }

  async callGemini(config, messages, tools) {
    const apiKey = config.api_key;
    const model = config.model || 'gemini-1.5-flash';
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

    const systemMsg = messages.find(m => m.role === 'system');

    const rawContents = messages
      .filter(m => m.role !== 'system')
      .map(m => {
        if (m.role === 'tool') {
          return {
            role: 'function',
            parts: [{
              functionResponse: {
                name: m.tool_call_id,
                response: { result: this.safeParseJSON(m.content) }
              }
            }]
          };
        }

        const role = m.role === 'user' ? 'user' : 'model';
        const parts = [];

        if (m.content) {
          parts.push({ text: m.content });
        }

        if (m.tool_calls && m.tool_calls.length > 0) {
          m.tool_calls.forEach(tc => {
            parts.push({
              functionCall: {
                name: tc.function?.name || tc.name,
                args: typeof tc.function?.arguments === 'string' ? this.safeParseJSON(tc.function.arguments) : (tc.function?.arguments || {})
              }
            });
          });
        }

        return { role, parts };
      });

    // Collapse consecutive messages with the same role
    const contents = [];
    for (const msg of rawContents) {
      if (msg.parts.length === 0) continue; // Skip empty messages
      const last = contents[contents.length - 1];
      if (last && last.role === msg.role) {
        last.parts.push(...msg.parts);
      } else {
        contents.push({ role: msg.role, parts: [...msg.parts] });
      }
    }

    // Ensure the conversation starts with a 'user' role
    if (contents.length > 0 && contents[0].role !== 'user') {
      contents.unshift({ role: 'user', parts: [{ text: "(User conversation started)" }] });
    }

    const payload = { contents };

    if (systemMsg && systemMsg.content) {
      payload.systemInstruction = {
        parts: [{ text: systemMsg.content }]
      };
    }

    if (tools && tools.length > 0) {
      payload.tools = [{
        functionDeclarations: tools.map(t => ({
          name: t.function?.name || t.name,
          description: t.function?.description || t.description,
          parameters: t.function?.parameters || { type: 'object', properties: {} }
        }))
      }];
    }

    let response;
    try {
      response = await axios.post(url, payload, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 60000,
      });
    } catch (err) {
      throw new Error(err.response?.data?.error?.message || err.message);
    }

    const candidate = response.data?.candidates?.[0];
    const parts = candidate?.content?.parts || [];

    let textContent = '';
    const tool_calls = [];

    parts.forEach(part => {
      if (part.text) textContent += part.text;
      if (part.functionCall) {
        tool_calls.push({
          function: {
            name: part.functionCall.name,
            arguments: JSON.stringify(part.functionCall.args || {})
          }
        });
      }
    });

    return { content: textContent, tool_calls };
  }

  getSystemPrompt(memoryContext) {
    const basePromptRow = this.db.prepare("SELECT system_prompt FROM llm_configs WHERE is_active = 1 LIMIT 1").get();
    const basePrompt = basePromptRow?.system_prompt;
    const appName = this.db.prepare("SELECT value FROM app_settings WHERE key = 'app_name'").get()?.value || 'Widyartha';

    let prompt = basePrompt ? (basePrompt + '\n\n') : `Kamu adalah agen customer service AI dari ${appName}. Kamu ramah, profesional, dan sangat membantu. Gunakan bahasa Indonesia yang natural dan sopan.\n\n`;

    const rules = this.db.prepare("SELECT rule_text FROM system_rules WHERE is_active = 1 ORDER BY id ASC").all();
    if (rules.length > 0) {
      prompt += this.getSetting('prompt_rules_header', 'ATURAN SANGAT PENTING (WAJIB DIIKUTI):') + '\n';
      rules.forEach((r, index) => {
        prompt += `${index + 1}. ${r.rule_text}\n`;
      });
      prompt += '\n';
    }

    if (memoryContext) {
      prompt += `${this.getSetting('prompt_context_header', 'Konteks pelanggan ini: ')} ${memoryContext}\n\n`;
    }

    return prompt;
  }

  safeParseJSON(str, fallback = {}) {
    if (typeof str === 'object') return str;
    try {
      return JSON.parse(str || '{}');
    } catch {
      return fallback;
    }
  }
}
