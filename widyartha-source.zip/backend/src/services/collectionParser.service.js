import yaml from 'js-yaml';

/**
 * Parse API collection dari berbagai format (Postman, OpenAPI, cURL, manual)
 */
export function parseCollection(rawContent, format = 'postman') {
  switch (format.toLowerCase()) {
    case 'postman': return parsePostman(rawContent);
    case 'openapi':
    case 'swagger': return parseOpenAPI(rawContent);
    case 'curl': return parseCurl(rawContent);
    default: return parsePostman(rawContent);
  }
}

function parsePostman(rawContent) {
  const data = JSON.parse(rawContent);
  const tools = [];
  
  const name = data.info?.name || 'Unnamed Collection';
  const baseUrl = extractPostmanBaseUrl(data);

  function processItems(items, prefix = '') {
    for (const item of items || []) {
      if (item.item) {
        // Folder
        processItems(item.item, `${prefix}${item.name}/`);
      } else if (item.request) {
        const tool = extractPostmanEndpoint(item, baseUrl);
        if (tool) tools.push(tool);
      }
    }
  }

  processItems(data.item || []);
  return { name, baseUrl, tools };
}

function extractPostmanBaseUrl(data) {
  // Try to get base URL from variables or first request
  const vars = data.variable || [];
  const baseUrlVar = vars.find(v => v.key === 'baseUrl' || v.key === 'base_url' || v.key === 'url');
  if (baseUrlVar) return baseUrlVar.value;

  // From first request
  const firstItem = data.item?.[0];
  if (firstItem?.request?.url) {
    const url = typeof firstItem.request.url === 'string'
      ? firstItem.request.url
      : firstItem.request.url.raw || '';
    const match = url.match(/^(https?:\/\/[^/]+)/);
    return match ? match[1] : '';
  }
  return '';
}

function extractPostmanEndpoint(item, baseUrl) {
  const req = item.request;
  if (!req) return null;

  const method = req.method?.toUpperCase() || 'GET';
  const urlObj = req.url;
  
  let rawUrl = typeof urlObj === 'string' ? urlObj : urlObj?.raw || '';
  let endpoint = rawUrl;

  // Remove base URL to get path
  if (baseUrl && endpoint.startsWith(baseUrl)) {
    endpoint = endpoint.slice(baseUrl.length);
  } else {
    // Try to extract path
    try {
      const u = new URL(rawUrl.replace(/{{.*?}}/g, 'placeholder'));
      endpoint = u.pathname + u.search;
    } catch {
      endpoint = rawUrl;
    }
  }

  // Build name from item name or path
  const nameParts = item.name
    ? item.name.toLowerCase().replace(/[^a-z0-9\s]/g, '').trim().split(/\s+/)
    : endpoint.replace(/[^a-z0-9/]/gi, '_').split('/').filter(Boolean);
  
  const toolName = `${method.toLowerCase()}_${nameParts.join('_')}`.slice(0, 50);

  // Extract parameters
  const parameters = extractPostmanParameters(req, urlObj);

  // Generate description from name and method
  const description = generateDescription(item.name || endpoint, method, req.description);

  return {
    name: toolName.replace(/[^a-z0-9_]/g, '_'),
    display_name: item.name || `${method} ${endpoint}`,
    description,
    endpoint,
    method,
    headers: extractPostmanHeaders(req.header),
    body_template: extractPostmanBody(req.body),
    tool_definition: {
      type: 'function',
      function: {
        name: toolName.replace(/[^a-z0-9_]/g, '_'),
        description,
        parameters: {
          type: 'object',
          properties: parameters,
          required: extractRequired(parameters),
        },
      },
    },
  };
}

function extractPostmanParameters(req, urlObj) {
  const params = {};
  
  // Query params
  const queryParams = typeof urlObj === 'object' ? urlObj.query || [] : [];
  for (const p of queryParams) {
    if (p.key && !p.disabled) {
      params[p.key] = {
        type: 'string',
        description: p.description || p.key,
      };
    }
  }

  // Path params (variables in URL)
  const pathVars = typeof urlObj === 'object' ? urlObj.variable || [] : [];
  for (const v of pathVars) {
    if (v.key) {
      params[v.key] = {
        type: 'string',
        description: v.description || `Path parameter: ${v.key}`,
      };
    }
  }

  // Body params for POST/PUT/PATCH
  if (req.body?.mode === 'raw' && req.body.raw) {
    try {
      const body = JSON.parse(req.body.raw);
      for (const [key, val] of Object.entries(body)) {
        if (!params[key]) {
          params[key] = {
            type: inferType(val),
            description: `Body field: ${key}`,
          };
        }
      }
    } catch { /* not JSON */ }
  } else if (req.body?.mode === 'formdata') {
    for (const f of req.body.formdata || []) {
      if (f.key && !f.disabled) {
        params[f.key] = { type: 'string', description: f.description || f.key };
      }
    }
  }

  return params;
}

function extractPostmanHeaders(headers = []) {
  const result = {};
  for (const h of headers) {
    if (h.key && !h.disabled && !['Authorization', 'Content-Type'].includes(h.key)) {
      result[h.key] = h.value;
    }
  }
  return result;
}

function extractPostmanBody(body) {
  if (!body || body.mode !== 'raw') return null;
  try { return JSON.parse(body.raw); } catch { return body.raw; }
}

function parseOpenAPI(rawContent) {
  let data;
  try {
    data = JSON.parse(rawContent);
  } catch {
    try {
      data = yaml.load(rawContent);
    } catch {
      throw new Error('Invalid OpenAPI/YAML format');
    }
  }

  const name = data.info?.title || 'OpenAPI Collection';
  const servers = data.servers || [];
  const baseUrl = servers[0]?.url || '';
  const tools = [];

  for (const [path, pathItem] of Object.entries(data.paths || {})) {
    for (const [method, operation] of Object.entries(pathItem)) {
      if (['get', 'post', 'put', 'patch', 'delete'].includes(method)) {
        const tool = extractOpenAPIEndpoint(path, method, operation, baseUrl);
        if (tool) tools.push(tool);
      }
    }
  }

  return { name, baseUrl, tools };
}

function extractOpenAPIEndpoint(path, method, operation, baseUrl) {
  const operationId = operation.operationId || `${method}_${path.replace(/[^a-z0-9]/gi, '_')}`;
  const toolName = operationId.toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 50);
  const description = operation.summary || operation.description || `${method.toUpperCase()} ${path}`;

  const parameters = {};

  // Path and query parameters
  for (const param of operation.parameters || []) {
    const schema = param.schema || {};
    parameters[param.name] = {
      type: schema.type || 'string',
      description: param.description || param.name,
      enum: schema.enum,
    };
    if (!schema.enum) delete parameters[param.name].enum;
  }

  // Request body
  const requestBody = operation.requestBody;
  if (requestBody) {
    const content = requestBody.content || {};
    const jsonSchema = content['application/json']?.schema;
    if (jsonSchema?.properties) {
      for (const [key, prop] of Object.entries(jsonSchema.properties)) {
        parameters[key] = {
          type: prop.type || 'string',
          description: prop.description || key,
        };
      }
    }
  }

  return {
    name: toolName,
    display_name: operation.summary || `${method.toUpperCase()} ${path}`,
    description: description + (operation.description ? ` — ${operation.description}` : ''),
    endpoint: path,
    method: method.toUpperCase(),
    headers: {},
    body_template: null,
    tool_definition: {
      type: 'function',
      function: {
        name: toolName,
        description,
        parameters: {
          type: 'object',
          properties: parameters,
          required: extractRequired(parameters),
        },
      },
    },
  };
}

function parseCurl(curlCommand) {
  // Parse single or multiple curl commands
  const commands = curlCommand.split(/(?=curl\s)/i).filter(c => c.trim());
  const tools = [];

  for (const cmd of commands) {
    const tool = parseSingleCurl(cmd.trim());
    if (tool) tools.push(tool);
  }

  const baseUrl = tools.length > 0 ? extractBaseFromUrl(tools[0].endpoint) : '';
  return { name: 'cURL Import', baseUrl, tools };
}

function parseSingleCurl(cmd) {
  const urlMatch = cmd.match(/curl\s+(?:-[^\s]+\s+)*['"]?(https?:\/\/[^\s'"]+)['"]?/i);
  if (!urlMatch) return null;

  const fullUrl = urlMatch[1];
  const methodMatch = cmd.match(/-X\s+(\w+)/i);
  const method = methodMatch ? methodMatch[1].toUpperCase() : 'GET';

  let endpoint = fullUrl;
  try {
    const u = new URL(fullUrl);
    endpoint = u.pathname + u.search;
  } catch { /* ignore */ }

  const toolName = `${method.toLowerCase()}_${endpoint.replace(/[^a-z0-9]/gi, '_').slice(0, 40)}`;

  return {
    name: toolName,
    display_name: `${method} ${endpoint}`,
    description: `${method} request to ${endpoint}`,
    endpoint,
    method,
    headers: {},
    body_template: null,
    tool_definition: {
      type: 'function',
      function: {
        name: toolName,
        description: `${method} request to ${endpoint}`,
        parameters: { type: 'object', properties: {}, required: [] },
      },
    },
  };
}

/**
 * Linter — Validasi tools dan berikan warnings
 */
export function lintTools(tools) {
  return tools.map(tool => {
    const warnings = [];
    
    // Check 1: Description too short
    if (!tool.description || tool.description.length < 20) {
      warnings.push({ type: 'warning', code: 'DESC_TOO_SHORT', message: 'Deskripsi terlalu singkat. AI mungkin tidak memahami fungsi tool ini dengan baik.' });
    }

    // Check 2: High-risk methods (POST/PUT/DELETE)
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(tool.method?.toUpperCase())) {
      warnings.push({ type: 'info', code: 'WRITE_OPERATION', message: `Metode ${tool.method} dapat memodifikasi data. Pastikan deskripsi jelas kapan tool ini boleh dipanggil.` });
    }

    // Check 3: No parameters for GET
    const props = tool.tool_definition?.function?.parameters?.properties || {};
    if (tool.method === 'GET' && Object.keys(props).length === 0) {
      warnings.push({ type: 'info', code: 'NO_PARAMS', message: 'Tidak ada parameter. Tool ini akan selalu mengembalikan data yang sama.' });
    }

    // Check 4: Ambiguous parameter types
    for (const [key, val] of Object.entries(props)) {
      if (!val.type || val.type === 'object') {
        warnings.push({ type: 'warning', code: 'AMBIGUOUS_TYPE', message: `Parameter '${key}' memiliki tipe data ambigu. Pertimbangkan untuk memperjelas tipe datanya.` });
      }
    }

    // Determine risk level
    let riskLevel = 'low';
    if (['POST', 'PUT', 'PATCH'].includes(tool.method?.toUpperCase())) riskLevel = 'medium';
    if (tool.method?.toUpperCase() === 'DELETE') riskLevel = 'high';
    if (warnings.some(w => w.type === 'warning')) riskLevel = riskLevel === 'low' ? 'medium' : riskLevel;

    return {
      ...tool,
      linter_warnings: warnings,
      risk_level: riskLevel,
    };
  });
}

// Helper functions
function generateDescription(name, method, existingDesc) {
  if (existingDesc && existingDesc.length > 20) return existingDesc;
  
  const methodMap = {
    GET: 'Ambil', POST: 'Buat', PUT: 'Perbarui', PATCH: 'Update sebagian', DELETE: 'Hapus',
  };
  return `${methodMap[method] || method} ${name}`;
}

function inferType(val) {
  if (typeof val === 'number') return Number.isInteger(val) ? 'integer' : 'number';
  if (typeof val === 'boolean') return 'boolean';
  if (Array.isArray(val)) return 'array';
  if (typeof val === 'object') return 'object';
  return 'string';
}

function extractRequired(parameters) {
  // Heuristic: params without ? in description might be required
  return Object.entries(parameters)
    .filter(([k, v]) => v.description && !v.description.includes('?') && !v.description.toLowerCase().includes('optional'))
    .slice(0, 3)
    .map(([k]) => k);
}

function extractBaseFromUrl(url) {
  try {
    const u = new URL(url.startsWith('http') ? url : `http://example.com${url}`);
    return url.startsWith('http') ? `${u.protocol}//${u.host}` : '';
  } catch { return ''; }
}
