import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { Server as SocketServer } from 'socket.io';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

import { initDb } from './db/database.js';
import authRoutes from './routes/auth.js';
import dashboardRoutes from './routes/dashboard.js';
import inboxRoutes from './routes/inbox.js';
import connectorsRoutes from './routes/connectors.js';
import channelsRoutes from './routes/channels.js';
import llmRoutes from './routes/llm.js';
import productsRoutes from './routes/products.js';
import analyticsRoutes from './routes/analytics.js';
import usersRoutes from './routes/users.js';
import settingsRoutes from './routes/settings.js';
import ledgerRoutes from './routes/ledger.js';
import dbConnectorRoutes from './routes/dbConnector.js';
import ordersRoutes from './routes/orders.js';
import invoicesRoutes from './routes/invoices.js';
import paymentsRoutes from './routes/payments.js';
import { setupSocketHandlers } from './socket/socketHandlers.js';
import { authenticateSocket } from './middleware/auth.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);

// Socket.io setup
const io = new SocketServer(httpServer, {
  cors: {
    origin: ['http://localhost:5173', 'http://localhost:3000'],
    methods: ['GET', 'POST'],
    credentials: true,
  },
});

// Store io globally for use in other modules
app.set('io', io);

// Middleware
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Initialize database
initDb();

import { setIoInstance as setIoTelegram, startTelegramBot } from './channels/telegram.js';
import { setIoInstance as setIoWhatsApp, startWhatsAppBot } from './channels/whatsapp.js';
import { getDb } from './db/database.js';

// Setup Bots
setIoTelegram(io);
setIoWhatsApp(io);
try {
  const db = getDb();

  // Telegram
  const telegramChannels = db.prepare(`SELECT id, credentials FROM channels WHERE type = 'telegram' AND is_active = 1`).all();
  for (const ch of telegramChannels) {
    if (ch.credentials) {
      try {
        const creds = JSON.parse(ch.credentials);
        if (creds.token) startTelegramBot(ch.id, creds.token);
      } catch (err) {
        console.error('Failed to start telegram bot on init:', err);
      }
    }
  }

  // WhatsApp
  const whatsappChannels = db.prepare(`SELECT id FROM channels WHERE type = 'whatsapp' AND is_active = 1`).all();
  for (const ch of whatsappChannels) {
    try {
      startWhatsAppBot(ch.id);
    } catch (err) {
      console.error('Failed to start whatsapp bot on init:', err);
    }
  }
} catch (err) {
  console.error('Database query for channels failed:', err);
}

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/inbox', inboxRoutes);
app.use('/api/connectors', connectorsRoutes);
app.use('/api/channels', channelsRoutes);
app.use('/api/llm', llmRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/ledger', ledgerRoutes);
app.use('/api/db-connector', dbConnectorRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/invoices', invoicesRoutes);
app.use('/api/payments', paymentsRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0', timestamp: new Date().toISOString() });
});

// Serve frontend in production
if (process.env.NODE_ENV === 'production') {
  const frontendDist = path.join(__dirname, '../../frontend/dist');
  app.use(express.static(frontendDist));
  app.get('*', (req, res) => {
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

// Socket authentication middleware
io.use(authenticateSocket);

// Socket handlers
setupSocketHandlers(io);

const PORT = process.env.PORT || 3001;
const HOST = process.env.HOST || '127.0.0.1';
httpServer.listen(PORT, HOST, () => {
  console.log(`🚀 Widyartha Backend running on http://${HOST}:${PORT}`);
});

export { io };
