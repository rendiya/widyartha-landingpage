import { getDb } from '../db/database.js';
import { LLMService } from '../services/llm.service.js';

export function setupSocketHandlers(io) {
  io.on('connection', (socket) => {
    const userId = socket.user?.id;
    const role = socket.user?.role;

    if (userId) {
      // Update user status to online
      try {
        const db = getDb();
        db.prepare('UPDATE users SET status = ? WHERE id = ?').run('online', userId);
      } catch {}
      
      socket.join(`user:${userId}`);
      console.log(`✅ Socket connected: user ${userId} (${role})`);
    }

    // Join session room
    socket.on('join_session', (sessionId) => {
      socket.join(`session:${sessionId}`);
    });

    socket.on('leave_session', (sessionId) => {
      socket.leave(`session:${sessionId}`);
    });

    // Customer sends message (from web widget)
    socket.on('customer_message', async (data) => {
      const { sessionId, customerId, content, channelType = 'web' } = data;
      
      try {
        const db = getDb();

        // Get or create session
        let session = sessionId
          ? db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId)
          : null;

        if (!session) {
          // Find or create customer
          let customer = customerId
            ? db.prepare('SELECT * FROM customers WHERE id = ?').get(customerId)
            : null;

          if (!customer) {
            const channelId = db.prepare('SELECT id FROM channels WHERE type = ?').get(channelType)?.id || 1;
            const result = db.prepare(`INSERT INTO customers (name, channel_ref, channel_type) VALUES (?, ?, ?)`).run(
              data.name || 'Anonymous',
              socket.id,
              channelType
            );
            customer = db.prepare('SELECT * FROM customers WHERE id = ?').get(result.lastInsertRowid);

            const channelResult = db.prepare(`INSERT INTO sessions (channel_id, customer_id, mode, status, last_message, last_message_at) VALUES (?, ?, 'ai', 'active', ?, CURRENT_TIMESTAMP)`).run(channelId, customer.id, content);
            session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(channelResult.lastInsertRowid);
          }
        }

        if (!session) return;

        // Save customer message
        db.prepare(`INSERT INTO messages (session_id, sender_type, content) VALUES (?, 'customer', ?)`).run(session.id, content);
        db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?').run(content, session.id);

        // Broadcast message to session room
        io.to(`session:${session.id}`).emit('new_message', {
          session_id: session.id,
          sender_type: 'customer',
          content,
          sent_at: new Date().toISOString(),
        });

        // Notify dashboard
        io.emit('session_updated', { sessionId: session.id, lastMessage: content });

        // Send back session info to customer
        socket.emit('session_info', { sessionId: session.id, customerId: session.customer_id });

        // If session mode is AI, generate AI response
        if (session.mode === 'ai') {
          // Emit typing indicator
          io.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: true });

          try {
            const llmService = new LLMService();
            const customerData = db.prepare('SELECT * FROM customers WHERE id = ?').get(session.customer_id);
            const aiResponse = await llmService.chat(session.id, content, { ...session, customer_name: customerData?.name, channel_type: channelType });

            // Check for escalation
            if (aiResponse.toolCalls?.some(tc => tc.tool === 'escalate_to_cs')) {
              // Find available CS
              const availableCS = db.prepare(`
                SELECT u.id FROM users u 
                WHERE u.role = 'cs' AND u.status = 'online'
                ORDER BY (SELECT COUNT(*) FROM sessions WHERE assigned_cs = u.id AND status = 'active') ASC
                LIMIT 1
              `).get();

              db.prepare(`UPDATE sessions SET mode = 'human', assigned_cs = ?, escalated_at = CURRENT_TIMESTAMP WHERE id = ?`)
                .run(availableCS?.id || null, session.id);

              io.emit('escalation_alert', {
                sessionId: session.id,
                customerId: session.customer_id,
                assignedCs: availableCS?.id,
                reason: aiResponse.toolCalls.find(tc => tc.tool === 'escalate_to_cs')?.args?.reason,
              });
            }

            // Convert [IMAGE: url] tag to markdown so frontend can render it
            let finalContent = aiResponse.content;
            const imageMatch = finalContent.match(/\[IMAGE:?\s*(.+?)\]/i);
            if (imageMatch) {
              const imageUrl = imageMatch[1];
              finalContent = finalContent.replace(imageMatch[0], `\n\n![Invoice](${imageUrl})`).trim();
            }

            // Save AI message
            const result = db.prepare(`INSERT INTO messages (session_id, sender_type, content, tool_calls) VALUES (?, 'ai', ?, ?)`).run(
              session.id,
              finalContent,
              JSON.stringify(aiResponse.toolCalls || [])
            );

            db.prepare('UPDATE sessions SET last_message = ?, last_message_at = CURRENT_TIMESTAMP WHERE id = ?')
              .run(finalContent, session.id);

            // Tandai pesan customer sebagai terbaca jika AI berhasil membalas SEBELUM emit
            db.prepare("UPDATE messages SET is_read = 1 WHERE session_id = ? AND sender_type = 'customer'").run(session.id);

            io.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: false });
            io.to(`session:${session.id}`).emit('new_message', {
              id: result.lastInsertRowid,
              session_id: session.id,
              sender_type: 'ai',
              content: finalContent,
              tool_calls: aiResponse.toolCalls,
              sent_at: new Date().toISOString(),
            });

            io.emit('session_updated', { sessionId: session.id, lastMessage: finalContent });
          } catch (err) {
            console.error('AI error in socket:', err);
            io.to(`session:${session.id}`).emit('ai_typing', { sessionId: session.id, typing: false });
            
            // Eskalasi otomatis jika AI error / offline
            db.prepare(`UPDATE sessions SET mode = 'human', escalated_at = CURRENT_TIMESTAMP WHERE id = ?`).run(session.id);
            const errMsg = `⚠️ Sistem AI Error/Offline: ${err.message}. Membutuhkan bantuan CS.`;
            db.prepare(`INSERT INTO messages (session_id, sender_type, content) VALUES (?, 'system', ?)`).run(session.id, errMsg);
            io.emit('session_updated', { sessionId: session.id, lastMessage: errMsg });
          }
        }
      } catch (err) {
        console.error('Socket error:', err);
        socket.emit('error', { message: err.message });
      }
    });

    // CS sends typing indicator
    socket.on('typing', ({ sessionId, typing }) => {
      socket.to(`session:${sessionId}`).emit('cs_typing', { sessionId, typing });
    });

    // Disconnect
    socket.on('disconnect', () => {
      if (userId) {
        try {
          const db = getDb();
          db.prepare('UPDATE users SET status = ? WHERE id = ?').run('offline', userId);
        } catch {}
        console.log(`❌ Socket disconnected: user ${userId}`);
      }
    });
  });
}
