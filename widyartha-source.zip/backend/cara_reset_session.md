# Panduan Reset Sesi Widyartha

Saat melakukan pengujian atau simulasi order (seperti yang ada di folder `simulasi_order`), Anda mungkin perlu membersihkan daftar sesi dan riwayat percakapan secara berkala agar pengujian dapat dilakukan dengan data yang bersih.

Terdapat script khusus yang telah disediakan untuk mempermudah proses ini.

## Cara Melakukan Reset Sesi

### 1. Buka Terminal
Pastikan Anda berada di dalam folder `backend`:
```bash
cd e:\code\ai-bot-cs\backend
```

### 2. Jalankan Script Reset
Gunakan Node.js untuk mengeksekusi script `reset_sessions.js`:
```bash
node reset_sessions.js
```

### 3. Output Berhasil
Jika berhasil, terminal akan menampilkan output sebagai berikut:
```text
✅ SQLite database initialized at E:\code\ai-bot-cs\backend\data\widyartha.db
Resetting sessions and messages...
Sessions reset successfully.
```

## Apa yang Dilakukan Script Ini?

Script `reset_sessions.js` melakukan beberapa hal di dalam database SQLite lokal (`widyartha.db`):
- **Menghapus Pesan:** Menjalankan perintah `DELETE FROM messages;` untuk menghapus semua riwayat chat.
- **Menghapus Sesi:** Menjalankan perintah `DELETE FROM sessions;` untuk menghapus semua status dan histori sesi customer.
- **Mereset ID (Auto Increment):** Membersihkan penomoran ID dari tabel `sqlite_sequence`, sehingga jika ada percakapan baru, ID akan kembali dimulai dari 1.

> **Catatan:** Melakukan hal ini tidak akan menghapus data *Products*, *Channels*, maupun *API Collections*. Hanya interaksi / pesan saja yang dihapus.
