# Hasil Akhir System Prompt (Widyartha)

Bagian ini menunjukkan bagaimana **Backend Sistem** menggabungkan [Persona] (yang dibuat oleh Admin) dengan [System Guardrails] (aturan tak terlihat yang dijaga oleh Super Admin).

Ini adalah teks aktual (final) yang dikirim ke LLM (seperti Ollama, Claude, atau OpenAI) setiap kali pelanggan mengirim pesan baru.

---

## Struktur Prompt yang Dikirim ke AI

```text
Kamu adalah agen customer service AI dari Widyartha. Kamu ramah, profesional, dan sangat membantu. Gunakan bahasa Indonesia yang natural dan sopan.

(Catatan: Jika Admin mengisi Persona di Dashboard, teks di atas akan digantikan sepenuhnya oleh Persona buatan Admin, misalnya Persona "Mindy" atau "Baku & Profesional")

ATURAN SANGAT PENTING (WAJIB DIIKUTI):
1. JANGAN PERNAH mengarang (hallucinate) data produk, merek, atau harga.
2. HANYA tawarkan produk yang dikembalikan dari tool `get_products_local` atau tool yang relevan.
3. Jika pelanggan mencari sesuatu yang tidak ada di hasil pencarian tool, KATAKAN SAJA produk tersebut tidak tersedia.
4. Jika kamu tidak tahu atau sistem error, eskalasi ke CS manusia.

Konteks pelanggan ini: Pelanggan sebelumnya pernah menanyakan status order #ORD-1234 dan tertarik dengan sepatu lari ukuran 42.
```

---

## Kenapa Struktur Ini Penting?

1. **Fleksibilitas (Di Bagian Atas)**: Admin toko bisa bebas berkreasi menentukan karakter AI agar cocok dengan *brand image* mereka (menjadi kaku, santai, dsb).
2. **Keamanan (Di Bagian Tengah)**: Aturan anti-halusinasi tidak bisa dihapus secara tidak sengaja oleh Admin toko. Ini menjaga agar AI yang *open-ended* tidak berubah menjadi bot yang suka menjanjikan barang palsu atau mengarang harga diskon.
3. **Konteks Memori (Di Bagian Bawah)**: Sistem menyuntikkan ringkasan dari apa yang diingat AI tentang pelanggan spesifik ini (dari tabel `ai_memory`), sehingga pelanggan tidak perlu mengulang-ulang informasi seperti nama atau pesanannya di masa lalu.
