import re

with open('frontend/src/assets/logo.svg', 'r') as f:
    svg = f.read()

# Replace viewBox and remove width/height
svg = re.sub(r'width="\d+"', '', svg)
svg = re.sub(r'height="\d+"', '', svg)
svg = re.sub(r'viewBox="0 0 1500 1499\.999933"', 'viewBox="124.5 631.3 1253.9 247.5"', svg)

with open('frontend/src/assets/logo.svg', 'w') as f:
    f.write(svg)
print("Updated logo.svg")
