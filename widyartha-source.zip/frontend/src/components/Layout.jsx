import { NavLink, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import api from '../lib/api';
import { useAuthStore } from '../store/authStore';
import {
  LayoutDashboard, Inbox, Plug, Radio, Brain, Package,
  BarChart3, Users, Settings, LogOut, Database, BookText, Server, ShoppingCart, Receipt
} from 'lucide-react';
import logoSvg from '../assets/logo.svg';

const navItems = [
  { section: 'Main', items: [
    { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/inbox', icon: Inbox, label: 'Unified Inbox' },
    { to: '/orders', icon: ShoppingCart, label: 'Orders' },
    { to: '/invoices', icon: Receipt, label: 'Invoices' },
  ]},
  { section: 'Connectors', items: [
    { to: '/connectors', icon: Plug, label: 'API Collections' },
    { to: '/db-connector', icon: Database, label: 'DB Connector' },
    { to: '/ledger', icon: BookText, label: 'Local Ledger' },
  ]},
  { section: 'Configuration', items: [
    { to: '/channels', icon: Radio, label: 'Channels' },
    { to: '/llm', icon: Brain, label: 'AI & LLM' },
    { to: '/products', icon: Package, label: 'Products' },
  ]},
  { section: 'Admin', items: [
    { to: '/analytics', icon: BarChart3, label: 'Analytics' },
    { to: '/users', icon: Users, label: 'Users & Team' },
    { to: '/settings', icon: Settings, label: 'Settings' },
  ]},
];

export default function Layout({ children }) {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  const { data: unreadData } = useQuery({
    queryKey: ['unreadCount'],
    queryFn: () => api.get('/inbox/unread-count').then(r => r.data),
    refetchInterval: 5000,
  });

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const initials = user?.name?.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || 'U';

  return (
    <div className="app-layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <img src={logoSvg} alt="Widyartha" style={{ height: 24, width: 'auto', maxWidth: '100%', objectFit: 'contain' }} />
        </div>

        <nav className="sidebar-nav">
          {navItems.map(({ section, items }) => (
            <div key={section} className="nav-section">
              <div className="nav-section-label">{section}</div>
              {items.map(({ to, icon: Icon, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/'}
                  className={({ isActive }) => `nav-item${isActive ? ' active' : ''}`}
                >
                  <Icon size={16} />
                  <span>{label}</span>
                  {to === '/inbox' && unreadData?.count > 0 && (
                    <span className="nav-badge red">{unreadData.count}</span>
                  )}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="user-info" onClick={handleLogout}>
            <div className="avatar">{initials}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="truncate" style={{ fontSize: 13, fontWeight: 600 }}>{user?.name}</div>
              <div className="truncate text-muted" style={{ fontSize: 11 }}>{user?.role}</div>
            </div>
            <LogOut size={14} className="text-muted" />
          </div>
        </div>
      </aside>

      <main className="main-content">
        {children}
      </main>
    </div>
  );
}
