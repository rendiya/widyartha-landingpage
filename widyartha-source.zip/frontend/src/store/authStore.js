import { create } from 'zustand';
import api from '../lib/api';

export const useAuthStore = create((set) => ({
  user: JSON.parse(localStorage.getItem('widyartha_user') || 'null'),
  token: localStorage.getItem('widyartha_token') || null,
  isLoading: false,
  error: null,

  login: async (username, password) => {
    set({ isLoading: true, error: null });
    try {
      const res = await api.post('/auth/login', { username, password });
      const { token, user } = res.data;
      localStorage.setItem('widyartha_token', token);
      localStorage.setItem('widyartha_user', JSON.stringify(user));
      set({ token, user, isLoading: false });
      return true;
    } catch (err) {
      set({ error: err.response?.data?.error || 'Login gagal', isLoading: false });
      return false;
    }
  },

  logout: async () => {
    try { await api.post('/auth/logout'); } catch {}
    localStorage.removeItem('widyartha_token');
    localStorage.removeItem('widyartha_user');
    set({ user: null, token: null });
  },

  setUser: (user) => set({ user }),
}));
