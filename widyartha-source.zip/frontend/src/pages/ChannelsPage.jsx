import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { Globe } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { io } from 'socket.io-client';
import { useAuthStore } from '../store/authStore';

let socket;
function getSocket(token) {
  if (!socket) {
    socket = io('/', { auth: { token }, transports: ['websocket', 'polling'] });
  }
  return socket;
}

const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.888-.788-1.489-1.761-1.663-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" />
  </svg>
);

const TelegramIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
    <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.64-.203-.658-.64.135-.954l11.566-4.458c.538-.196 1.006.128.832.94z"/>
  </svg>
);

const MessengerIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
    <path d="M12 0C5.373 0 0 5.018 0 11.55c0 3.708 1.83 7.022 4.672 9.26.14.11.23.275.244.45l.186 2.128c.026.31.332.51.62.428l2.368-.692c.164-.048.34-.038.497.026A12.708 12.708 0 0 0 12 23.1c6.627 0 12-5.018 12-11.55S18.627 0 12 0zm1.18 15.65l-2.617-2.822a1.05 1.05 0 0 0-1.5-.027l-3.328 3.2c-.446.429-1.127-.08-1.026-.684l.024-.13 3.633-5.753a1.045 1.045 0 0 1 1.543-.228l2.673 2.502a1.05 1.05 0 0 0 1.458-.04l3.298-3.39c.453-.466 1.182.025 1.066.66l-.014.076-3.69 5.894a1.045 1.045 0 0 1-1.52.742z"/>
  </svg>
);

export default function ChannelsPage() {
  const [editingChannel, setEditingChannel] = useState(null);
  const [tokenInput, setTokenInput] = useState('');
  const [saveStatus, setSaveStatus] = useState(null); // { type: 'success' | 'error', message: string }
  const [waQrCode, setWaQrCode] = useState(null);
  const { token } = useAuthStore();
  const qc = useQueryClient();

  useEffect(() => {
    const sock = getSocket(token);
    sock.on('wa_qr_code', (data) => {
      setWaQrCode(data.qr);
    });
    sock.on('wa_connected', () => {
      setWaQrCode(null);
      setEditingChannel(null);
      qc.invalidateQueries(['channels']);
    });
    return () => { sock.off('wa_qr_code'); sock.off('wa_connected'); };
  }, [token, qc]);

  const { data: channels = [] } = useQuery({ queryKey: ['channels'], queryFn: () => api.get('/channels').then(r => r.data) });

  const toggle = async (id, isActive) => {
    await api.patch(`/channels/${id}/toggle`);
    qc.invalidateQueries(['channels']);
  };

  const openEditModal = (ch) => {
    setEditingChannel(ch);
    setTokenInput(''); 
    setSaveStatus(null);
  };

  const saveConnection = async () => {
    if (!tokenInput) {
      setSaveStatus({ type: 'error', message: 'Token cannot be empty!' });
      return;
    }
    
    setSaveStatus({ type: 'loading', message: 'Saving...' });
    try {
      await api.patch(`/channels/${editingChannel.id}`, { credentials: { token: tokenInput } });
      setSaveStatus({ type: 'success', message: 'Connection saved successfully!' });
      qc.invalidateQueries(['channels']);
      setTimeout(() => {
        setEditingChannel(null);
      }, 1500);
    } catch (e) {
      setSaveStatus({ type: 'error', message: 'Failed to save connection' });
    }
  };

  const channelInfo = {
    whatsapp: { icon: <WhatsAppIcon />, name: 'WhatsApp', desc: 'via Baileys (unofficial)', risk: 'Ban risk', color: '#25d366' },
    telegram: { icon: <TelegramIcon />, name: 'Telegram', desc: 'Official API — ban free', risk: 'Safe', color: '#0088cc' },
    web: { icon: <Globe size={24} />, name: 'Web Widget', desc: 'Embeddable chatbot widget', risk: 'Safe', color: '#6366f1' },
    messenger: { icon: <MessengerIcon />, name: 'FB Messenger', desc: 'Official Meta API', risk: 'Safe', color: '#0084ff' },
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div><div className="page-title">Channel Store</div><div className="page-subtitle">Activate and configure messaging channels</div></div>
      </div>

      <div className="page-content">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {channels.map(ch => {
            const info = channelInfo[ch.type] || { icon: '💬', name: ch.name, desc: '', risk: '', color: '#6366f1' };
            return (
              <div key={ch.id} className={`card${ch.is_active ? ' active' : ''}`} style={{ border: ch.is_active ? `1px solid ${info.color}40` : '' }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ fontSize: 32, width: 52, height: 52, borderRadius: 14, background: `${info.color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{info.icon}</div>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 15 }}>{ch.name}</div>
                      <div className="text-muted text-sm">{info.desc}</div>
                    </div>
                  </div>
                  <div className={`toggle ${ch.is_active ? 'on' : ''}`} onClick={() => toggle(ch.id, ch.is_active)}/>
                </div>

                <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                  <span className={`badge ${ch.is_active ? 'badge-green' : 'badge-gray'}`}>{ch.is_active ? 'Active' : 'Inactive'}</span>
                  <span className={`badge ${info.risk === 'Safe' ? 'badge-green' : 'badge-yellow'}`}>{info.risk}</span>
                </div>

                {ch.type === 'whatsapp' && (
                  <div style={{ padding: 12, background: 'rgba(245,158,11,0.1)', borderRadius: 8, fontSize: 12, color: 'var(--warning)', marginBottom: 12 }}>
                    ⚠️ Using Baileys (unofficial). WA numbers risk being banned. Use a separate number for bots.
                  </div>
                )}

                {!ch.is_active ? (
                  <div style={{ padding: 10, background: 'var(--bg-primary)', borderRadius: 8, fontSize: 12, color: 'var(--text-muted)' }}>
                    Toggle active above for further configuration
                  </div>
                ) : (
                  <div>
                    {ch.type === 'whatsapp' && (
                      <div style={{ background: 'var(--bg-primary)', padding: 12, borderRadius: 8, marginTop: 10 }}>
                        <button 
                          className="btn btn-outline" 
                          style={{ width: '100%', justifyContent: 'center', fontSize: 13, padding: '6px 12px' }}
                          onClick={() => { setEditingChannel(ch); setWaQrCode(null); }}
                        >
                          Show QR / Connect
                        </button>
                      </div>
                    )}
                    {ch.type === 'telegram' && (
                      <div style={{ background: 'var(--bg-primary)', padding: 12, borderRadius: 8, marginTop: 10 }}>
                        <div style={{ fontSize: 13, marginBottom: 8, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ color: 'var(--text-muted)' }}>Status Bot Token:</span>
                          <span style={{ fontWeight: 600, color: ch.has_credentials ? '#25d366' : 'var(--text-muted)' }}>
                            {ch.has_credentials ? 'Inputted' : 'Empty / Unavailable'}
                          </span>
                        </div>
                        <button 
                          className="btn btn-outline" 
                          style={{ width: '100%', justifyContent: 'center', fontSize: 13, padding: '6px 12px' }}
                          onClick={() => openEditModal(ch)}
                        >
                          Edit Connection
                        </button>
                      </div>
                    )}
                    {ch.type === 'web' && (
                      <div>
                        <label className="form-label">Embed Code</label>
                        <code style={{ display: 'block', background: 'var(--bg-primary)', padding: 10, borderRadius: 8, fontSize: 11, color: 'var(--accent)', wordBreak: 'break-all' }}>
                          {`<script src="/widget.js" data-channel="${ch.id}"></script>`}
                        </code>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="card" style={{ marginTop: 20, background: 'rgba(99,102,241,0.05)', border: '1px dashed var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ fontSize: 24 }}>🔜</div>
            <div>
              <div style={{ fontWeight: 600 }}>Channel Roadmap v2.0</div>
              <div className="text-muted text-sm">Instagram DM · Line · Discord — Coming Q1 2027</div>
            </div>
          </div>
        </div>
      </div>

      {editingChannel && (
        <div style={{ 
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, 
          background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999 
        }}>
          <div className="card" style={{ width: 400, maxWidth: '90%', padding: 24 }}>
            <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 8 }}>Configuration for {editingChannel.name}</div>
            
            {editingChannel.type === 'whatsapp' ? (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20, textAlign: 'center' }}>
                  Open WhatsApp on your phone &gt; Linked Devices &gt; Scan QR Code below.
                </div>
                {waQrCode ? (
                  <div style={{ background: 'white', padding: 16, borderRadius: 8, display: 'inline-block' }}>
                    <QRCodeSVG value={waQrCode} size={200} />
                  </div>
                ) : (
                  <div style={{ padding: 40, color: 'var(--text-muted)' }}>
                    Waiting for QR Code from server...
                  </div>
                )}
                
                <button 
                  className="btn btn-outline" 
                  style={{ width: '100%', justifyContent: 'center', marginTop: 24 }}
                  onClick={() => { setEditingChannel(null); setWaQrCode(null); }}
                >
                  Cancel / Close
                </button>
              </div>
            ) : (
              <>
                <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 20 }}>
                  Enter Bot Token obtained from @BotFather on Telegram.
                </div>
                
                <div className="form-group">
                  <label className="form-label">New Bot Token</label>
                  <input 
                    className="form-input" 
                    placeholder="1234567890:ABCdef..." 
                    type="password" 
                    value={tokenInput}
                    onChange={(e) => { setTokenInput(e.target.value); setSaveStatus(null); }}
                  />
                </div>

                {saveStatus && (
                  <div style={{ 
                    marginTop: 12, padding: '8px 12px', borderRadius: 6, fontSize: 13,
                    background: saveStatus.type === 'error' ? 'rgba(239,68,68,0.1)' : saveStatus.type === 'success' ? 'rgba(34,197,94,0.1)' : 'var(--bg-primary)',
                    color: saveStatus.type === 'error' ? '#ef4444' : saveStatus.type === 'success' ? '#22c55e' : 'var(--text-muted)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 500
                  }}>
                    {saveStatus.message}
                  </div>
                )}
                
                <div style={{ display: 'flex', gap: 10, marginTop: 24 }}>
                  <button 
                    className="btn btn-outline" 
                    style={{ flex: 1, justifyContent: 'center' }}
                    onClick={() => setEditingChannel(null)}
                  >
                    Cancel
                  </button>
                  <button 
                    className="btn btn-primary" 
                    style={{ flex: 1, justifyContent: 'center' }}
                    onClick={saveConnection}
                    disabled={saveStatus?.type === 'loading' || saveStatus?.type === 'success'}
                  >
                    {saveStatus?.type === 'loading' ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
