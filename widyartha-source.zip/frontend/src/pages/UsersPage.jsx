import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { Plus, Trash2, Edit2 } from 'lucide-react';

export default function UsersPage() {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', username: '', password: '', role: 'cs', max_sessions: 5 });
  const qc = useQueryClient();

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => api.get('/users').then(r => r.data),
  });

  const addUser = async (e) => {
    e.preventDefault();
    try {
      await api.post('/users', form);
      qc.invalidateQueries(['users']);
      setShowAdd(false);
      setForm({ name: '', username: '', password: '', role: 'cs', max_sessions: 5 });
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };

  const deleteUser = async (id) => {
    if (!confirm('Delete this user?')) return;
    await api.delete(`/users/${id}`);
    qc.invalidateQueries(['users']);
  };

  const roleColor = { super_admin: 'badge-purple', admin: 'badge-blue', cs: 'badge-gray' };
  const statusColor = { online: 'badge-green', offline: 'badge-gray', away: 'badge-yellow' };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div><div className="page-title">Users & Team</div><div className="page-subtitle">Manage customer service team access</div></div>
        <button className="btn btn-primary" onClick={() => setShowAdd(true)}><Plus size={14}/>Add User</button>
      </div>

      <div className="page-content">
        {showAdd && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 500, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="modal-header"><div className="modal-title">Add New User</div><button className="btn btn-ghost btn-sm" onClick={() => setShowAdd(false)}>✕</button></div>
              <form onSubmit={addUser}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div className="form-group"><label className="form-label">Name</label><input className="form-input" required value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Username</label><input type="text" className="form-input" required value={form.username} onChange={e => setForm(p => ({...p, username: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Password</label><input type="password" className="form-input" required value={form.password} onChange={e => setForm(p => ({...p, password: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Role</label>
                  <select className="form-input form-select" value={form.role} onChange={e => setForm(p => ({...p, role: e.target.value}))}>
                    <option value="cs">CS Agent</option><option value="admin">Admin</option><option value="super_admin">Super Admin</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Max Sessions</label><input type="number" className="form-input" value={form.max_sessions} onChange={e => setForm(p => ({...p, max_sessions: parseInt(e.target.value)}))} min={1} max={20}/></div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                <button type="submit" className="btn btn-primary">Save</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAdd(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
        )}

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%' }}>
            <thead><tr><th>User</th><th>Username</th><th>Role</th><th>Status</th><th>Max Sessions</th><th>Joined</th><th>Action</th></tr></thead>
            <tbody>
              {isLoading ? <tr><td colSpan="7" style={{ textAlign: 'center', padding: 32 }}>Loading...</td></tr> :
              users.map(u => (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <div className="avatar sm">{u.name?.[0]}</div>
                      <span style={{ fontWeight: 600 }}>{u.name}</span>
                    </div>
                  </td>
                  <td className="text-muted text-sm">{u.username}</td>
                  <td><span className={`badge ${roleColor[u.role] || 'badge-gray'}`}>{u.role}</span></td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className={`status-dot ${u.status}`}/>
                      <span className={`badge ${statusColor[u.status] || 'badge-gray'}`} style={{ fontSize: 10 }}>{u.status}</span>
                    </div>
                  </td>
                  <td className="text-muted">{u.max_sessions}</td>
                  <td className="text-muted text-sm">{new Date(u.created_at).toLocaleDateString('id-ID')}</td>
                  <td>
                    <button className="btn btn-danger btn-sm btn-icon" onClick={() => deleteUser(u.id)} title="Delete"><Trash2 size={13}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
