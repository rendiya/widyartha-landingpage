import { useState } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';

const STATUS_STYLES = {
  pending:   { bg: 'rgba(234,179,8,0.1)',  color: '#eab308', label: 'Pending' },
  paid:      { bg: 'rgba(34,197,94,0.1)',   color: '#22c55e', label: 'Paid' },
  shipped:   { bg: 'rgba(59,130,246,0.1)',  color: '#3b82f6', label: 'Shipped' },
  cancelled: { bg: 'rgba(239,68,68,0.1)',   color: '#ef4444', label: 'Cancelled' },
};

export default function OrdersPage() {
  const queryClient = useQueryClient();
  const [verifyingOrder, setVerifyingOrder] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [cancelConfirm, setCancelConfirm] = useState(null);

  const { data: orders, isLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => api.get('/orders').then(res => res.data),
  });

  const verifyPaymentMutation = useMutation({
    mutationFn: ({ id, amount }) => api.post('/payments/verify', { order_id: id, amount }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
      setVerifyingOrder(null);
    },
  });

  const cancelMutation = useMutation({
    mutationFn: ({ id, reason }) => api.put(`/orders/${id}/cancel`, { reason }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
      setCancelConfirm(null);
    },
  });

  const shipMutation = useMutation({
    mutationFn: (id) => api.put(`/orders/${id}/ship`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['orders'] }),
  });

  if (isLoading) return <div className="p-8">Loading orders...</div>;

  const getStatusStyle = (status) => STATUS_STYLES[status] || STATUS_STYLES.pending;

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Orders Management</h1>
          <p className="text-muted">Review incoming orders, verify payments, and track shipments.</p>
        </div>
        <div className="flex gap-3 text-sm">
          <div className="px-3 py-1 rounded" style={{ background: 'rgba(234,179,8,0.1)', color: '#eab308' }}>
            ⏳ {orders?.filter(o => o.status === 'pending').length || 0} Pending
          </div>
          <div className="px-3 py-1 rounded" style={{ background: 'rgba(34,197,94,0.1)', color: '#22c55e' }}>
            ✅ {orders?.filter(o => o.status === 'paid').length || 0} Paid
          </div>
        </div>
      </div>

      <div className="bg-card border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted">
            <tr className="border-b">
              <th className="px-4 py-3 text-left" style={{ width: 40 }}></th>
              <th className="px-4 py-3 text-left">Order</th>
              <th className="px-4 py-3 text-left">Customer</th>
              <th className="px-4 py-3 text-left">Items</th>
              <th className="px-4 py-3 text-left">Amount</th>
              <th className="px-4 py-3 text-left">Invoice</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders?.length === 0 ? (
              <tr><td colSpan={8} className="px-4 py-8 text-center text-muted">No orders found.</td></tr>
            ) : (
              orders?.map(order => {
                const style = getStatusStyle(order.status);
                const isExpanded = expandedId === order.id;
                return (
                  <>
                    <tr key={order.id} className="border-b hover:bg-muted/30" style={{ cursor: 'pointer' }} onClick={() => setExpandedId(isExpanded ? null : order.id)}>
                      <td className="px-4 py-3 text-muted">{isExpanded ? '▾' : '▸'}</td>
                      <td className="px-4 py-3 font-medium">#{order.id}</td>
                      <td className="px-4 py-3">
                        <div>{order.customer_name || '-'}</div>
                        {order.customer_phone && <div className="text-xs text-muted">{order.customer_phone}</div>}
                      </td>
                      <td className="px-4 py-3 text-muted">{order.items?.length || 0} item(s)</td>
                      <td className="px-4 py-3 font-medium">Rp {order.total_amount?.toLocaleString() || 0}</td>
                      <td className="px-4 py-3">
                        {order.invoice_number ? (
                          <span className="text-xs font-mono" style={{ opacity: 0.7 }}>{order.invoice_number}</span>
                        ) : '-'}
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-1 rounded text-xs font-medium" style={{ background: style.bg, color: style.color }}>
                          {style.label}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right" onClick={e => e.stopPropagation()}>
                        <div className="flex gap-2 justify-end">
                          {order.status === 'pending' && (
                            <>
                              <button onClick={() => setVerifyingOrder(order)} className="btn btn-primary btn-sm">Verify Payment</button>
                              <button onClick={() => setCancelConfirm(order.id)} className="btn btn-danger btn-sm">Cancel</button>
                            </>
                          )}
                          {order.status === 'paid' && (
                            <button onClick={() => shipMutation.mutate(order.id)} className="btn btn-sm" style={{ background: 'rgba(59,130,246,0.1)', color: '#3b82f6', borderColor: 'transparent' }}>
                              Mark Shipped
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr key={`${order.id}-detail`} className="border-b">
                        <td colSpan={8} className="px-6 py-4" style={{ background: 'var(--bg-secondary)' }}>
                          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
                            <div>
                              <div className="font-bold text-sm mb-2">📦 Order Items</div>
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="text-muted">
                                    <th className="py-1 text-left">Product</th>
                                    <th className="py-1 text-center">Qty</th>
                                    <th className="py-1 text-right">Price</th>
                                    <th className="py-1 text-right">Subtotal</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {order.items?.map((item, idx) => (
                                    <tr key={idx} className="border-b border-dashed">
                                      <td className="py-2">{item.product_name} <span className="text-muted">({item.product_sku})</span></td>
                                      <td className="py-2 text-center">{item.quantity}</td>
                                      <td className="py-2 text-right">Rp {item.unit_price?.toLocaleString()}</td>
                                      <td className="py-2 text-right font-medium">Rp {item.subtotal?.toLocaleString()}</td>
                                    </tr>
                                  ))}
                                  {(!order.items || order.items.length === 0) && (
                                    <tr><td colSpan={4} className="py-2 text-muted text-center">No items (legacy order)</td></tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                            <div>
                              <div className="font-bold text-sm mb-2">📋 Details</div>
                              <div className="text-xs space-y-1">
                                <div><span className="text-muted">Shipping:</span> {order.shipping_address || '-'}</div>
                                <div><span className="text-muted">Created:</span> {new Date(order.created_at).toLocaleString()}</div>
                                <div><span className="text-muted">Invoice Status:</span> {order.invoice_status || '-'}</div>
                                {order.payment_proof_url && (
                                  <div>
                                    <span className="text-muted">Payment Proof:</span>{' '}
                                    <a href={order.payment_proof_url} target="_blank" rel="noreferrer" className="text-blue-500 hover:underline">View</a>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Verify Payment Modal */}
      {verifyingOrder && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999, backdropFilter: 'blur(4px)' }}>
          <div className="card w-full" style={{ maxWidth: '450px', margin: '20px' }}>
            <div style={{ fontWeight: 700, fontSize: '1.25rem', marginBottom: 8 }}>Verify Payment</div>
            <p className="text-muted" style={{ marginBottom: 16, fontSize: '0.875rem' }}>
              Confirm payment for Order <strong>#{verifyingOrder.id}</strong> — {verifyingOrder.customer_name}.
              This will mark the order as <strong>paid</strong> and record the transaction in the ledger.
            </p>
            {verifyingOrder.items?.length > 0 && (
              <div style={{ background: 'var(--bg-secondary)', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: '0.8rem' }}>
                {verifyingOrder.items.map((item, i) => (
                  <div key={i}>{item.quantity}x {item.product_name} — Rp {item.subtotal?.toLocaleString()}</div>
                ))}
                <div style={{ borderTop: '1px solid var(--border)', marginTop: 8, paddingTop: 8, fontWeight: 700 }}>
                  Total: Rp {verifyingOrder.total_amount?.toLocaleString()}
                </div>
              </div>
            )}
            <form onSubmit={(e) => {
              e.preventDefault();
              verifyPaymentMutation.mutate({ id: verifyingOrder.id, amount: parseFloat(e.target.amount.value) });
            }}>
              <div className="form-group">
                <label className="form-label">Amount Received (Rp)</label>
                <input name="amount" type="number" required defaultValue={verifyingOrder.total_amount || ''} placeholder="Amount (Rp)" className="form-input" />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12, marginTop: 24 }}>
                <button type="button" onClick={() => setVerifyingOrder(null)} className="btn">Cancel</button>
                <button type="submit" className="btn btn-primary">Verify & Record</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Cancel Confirmation Modal */}
      {cancelConfirm && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999, backdropFilter: 'blur(4px)' }}>
          <div className="card w-full" style={{ maxWidth: '400px', margin: '20px' }}>
            <div style={{ fontWeight: 700, fontSize: '1.25rem', marginBottom: 8, color: 'var(--danger)' }}>Cancel Order</div>
            <p className="text-muted" style={{ marginBottom: 16, fontSize: '0.875rem' }}>
              Are you sure you want to cancel Order <strong>#{cancelConfirm}</strong>? This will void the invoice and restore product stock.
            </p>
            <form onSubmit={(e) => {
              e.preventDefault();
              cancelMutation.mutate({ id: cancelConfirm, reason: e.target.reason?.value || '' });
            }}>
              <div className="form-group">
                <label className="form-label">Reason (optional)</label>
                <input name="reason" placeholder="e.g. Customer requested cancellation" className="form-input" />
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12, marginTop: 24 }}>
                <button type="button" onClick={() => setCancelConfirm(null)} className="btn">Keep Order</button>
                <button type="submit" className="btn btn-danger">Cancel Order</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
