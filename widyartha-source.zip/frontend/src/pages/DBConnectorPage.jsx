import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { Plus, Trash2, Search, Eye, GitMerge } from 'lucide-react';

export default function DBConnectorPage() {
  const [showAdd, setShowAdd] = useState(false);
  const [schema, setSchema] = useState(null);
  const [loadingSchema, setLoadingSchema] = useState(null);
  const [form, setForm] = useState({ name: '', db_type: 'mysql', host: 'localhost', port: 3306, database_name: '', credentials: { user: '', password: '' } });
  const qc = useQueryClient();

  const { data: connectors = [] } = useQuery({ queryKey: ['db-connectors'], queryFn: () => api.get('/db-connector').then(r => r.data) });

  const addConnector = async (e) => {
    e.preventDefault();
    await api.post('/db-connector', form);
    qc.invalidateQueries(['db-connectors']);
    setShowAdd(false);
  };

  const readSchema = async (id) => {
    setLoadingSchema(id);
    try {
      const res = await api.post(`/db-connector/${id}/read-schema`);
      setSchema({ id, data: res.data });
    } catch (err) { alert(err.response?.data?.error || err.message); }
    setLoadingSchema(null);
  };

  const saveMapping = async (connectorId, mappingConfig) => {
    await api.post(`/db-connector/${connectorId}/save-mapping`, { mapping_config: mappingConfig });
    qc.invalidateQueries(['db-connectors']);
    alert('Mapping saved! Connector is ready to use.');
  };

  const deleteConnector = async (id) => {
    if (!confirm('Delete this DB connector?')) return;
    await api.delete(`/db-connector/${id}`);
    qc.invalidateQueries(['db-connectors']);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div>
          <div className="page-title">Database Connector</div>
          <div className="page-subtitle">Schema-Only Mapping — zero data duplication, parameterized queries safe from SQL Injection</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowAdd(true)}><Plus size={14}/>Add DB Connection</button>
      </div>

      <div className="page-content">
        {/* Concept card */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 20 }}>
          {[
            { icon: '🚫', title: 'Zero Data Copy', desc: 'Product data stays in customer DB. SQLite only stores mapping rules.' },
            { icon: '🤖', title: 'AI Schema Mapping', desc: 'AI reads table structure and recommends mapping automatically.' },
            { icon: '🔒', title: 'Parameterized Query', desc: "Backend builds safe queries, AI doesn't write raw SQL. Anti SQL Injection." },
          ].map(({ icon, title, desc }) => (
            <div key={title} className="card" style={{ background: 'rgba(99,102,241,0.05)', borderColor: 'rgba(99,102,241,0.2)' }}>
              <div style={{ fontSize: 24, marginBottom: 8 }}>{icon}</div>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>{title}</div>
              <div className="text-muted text-sm">{desc}</div>
            </div>
          ))}
        </div>

        {showAdd && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 600, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="modal-header"><div className="modal-title">Add Database Connection</div><button className="btn btn-ghost btn-sm" onClick={() => setShowAdd(false)}>✕</button></div>
              <form onSubmit={addConnector}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div className="form-group"><label className="form-label">Connection Name</label><input className="form-input" required value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))}/></div>
                <div className="form-group">
                  <label className="form-label">Database Type</label>
                  <select className="form-input form-select" value={form.db_type} onChange={e => setForm(p => ({...p, db_type: e.target.value}))}>
                    <option value="mysql">MySQL / MariaDB</option><option value="postgres">PostgreSQL</option><option value="mssql">SQL Server</option>
                  </select>
                </div>
                <div className="form-group"><label className="form-label">Host</label><input className="form-input" value={form.host} onChange={e => setForm(p => ({...p, host: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Port</label><input type="number" className="form-input" value={form.port} onChange={e => setForm(p => ({...p, port: parseInt(e.target.value)}))}/></div>
                <div className="form-group"><label className="form-label">Database Name</label><input className="form-input" required value={form.database_name} onChange={e => setForm(p => ({...p, database_name: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Username</label><input className="form-input" value={form.credentials.user} onChange={e => setForm(p => ({...p, credentials: {...p.credentials, user: e.target.value}}))}/></div>
                <div className="form-group"><label className="form-label">Password</label><input type="password" className="form-input" value={form.credentials.password} onChange={e => setForm(p => ({...p, credentials: {...p.credentials, password: e.target.value}}))}/></div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                <button type="submit" className="btn btn-primary">Save</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAdd(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
        )}

        <div style={{ display: 'grid', gap: 14 }}>
          {connectors.length === 0 && (
            <div className="empty-state"><div className="empty-icon">🗄️</div><div className="empty-title">No DB connections yet</div><div className="empty-desc">Add connection to customer MySQL/PostgreSQL database</div></div>
          )}
          {connectors.map(c => (
            <div key={c.id} className={`connector-card${c.is_active ? ' active' : ''}`}>
              <div className="connector-header">
                <div>
                  <div className="connector-name">🗄️ {c.name}</div>
                  <div className="connector-meta">{c.db_type?.toUpperCase()} · {c.host}:{c.port} · {c.database_name}</div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <span className={`badge ${c.is_active ? 'badge-green' : 'badge-gray'}`}>{c.is_active ? 'Active' : 'Not configured'}</span>
                  <button className={`btn btn-secondary btn-sm${loadingSchema === c.id ? ' btn-loading' : ''}`} onClick={() => readSchema(c.id)} disabled={loadingSchema === c.id}>
                    {loadingSchema !== c.id && <><Eye size={12}/>Read AI Schema</>}
                  </button>
                  <button className="btn btn-danger btn-sm btn-icon" onClick={() => deleteConnector(c.id)}><Trash2 size={13}/></button>
                </div>
              </div>

              {/* Schema result */}
              {schema?.id === c.id && (
                <div style={{ marginTop: 14, borderTop: '1px solid var(--border)', paddingTop: 14 }}>
                  <div style={{ fontWeight: 600, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}><GitMerge size={14} style={{ color: 'var(--accent)' }}/>AI Schema Analysis</div>
                  <div style={{ display: 'grid', gap: 10 }}>
                    {schema.data.tables?.map(table => (
                      <div key={table.name} style={{ background: 'var(--bg-primary)', borderRadius: 10, padding: 14, border: '1px solid var(--border)' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
                          <div>
                            <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--accent)' }}>{table.name}</span>
                            <div style={{ fontSize: 12, color: 'var(--success)', marginTop: 2 }}>🤖 {table.ai_suggestion}</div>
                          </div>
                          <button className="btn btn-success btn-sm" onClick={() => saveMapping(c.id, { [table.suggested_mapping]: { table_name: table.name, columns: Object.fromEntries(table.columns.map(col => [col.name, col.name])) } })}>
                            Confirm Mapping
                          </button>
                        </div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                          {table.columns?.map(col => (
                            <span key={col.name} style={{ fontSize: 11, padding: '3px 8px', background: 'var(--bg-card)', borderRadius: 6, border: '1px solid var(--border)', fontFamily: 'monospace', color: col.primary_key ? 'var(--accent)' : 'var(--text-secondary)' }}>
                              {col.primary_key ? '🔑 ' : ''}{col.name}: <span style={{ color: 'var(--text-muted)' }}>{col.type}</span>
                            </span>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
