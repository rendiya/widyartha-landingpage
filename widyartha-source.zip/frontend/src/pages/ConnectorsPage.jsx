import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useDropzone } from 'react-dropzone';
import api from '../lib/api';
import { Upload, Plug, Trash2, ToggleLeft, ToggleRight, Eye, AlertTriangle, CheckCircle, Info, Send, Bot, ChevronDown, ChevronUp } from 'lucide-react';

export default function ConnectorsPage() {
  const [activeTab, setActiveTab] = useState('list');
  const [showImport, setShowImport] = useState(false);
  const [parseResult, setParseResult] = useState(null);
  const [isParsing, setIsParsing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [authType, setAuthType] = useState('none');
  const [authToken, setAuthToken] = useState('');
  const [baseUrl, setBaseUrl] = useState('');
  const [collectionName, setCollectionName] = useState('');
  const [testDriveOpen, setTestDriveOpen] = useState(null);
  const [testHistory, setTestHistory] = useState([]);
  const [testMsg, setTestMsg] = useState('');
  const [testLoading, setTestLoading] = useState(false);
  const qc = useQueryClient();

  const { data: collections = [], isLoading } = useQuery({
    queryKey: ['connectors'],
    queryFn: () => api.get('/connectors').then(r => r.data),
  });

  const onDrop = useCallback(async (files) => {
    const file = files[0];
    if (!file) return;
    setIsParsing(true);
    setParseResult(null);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('format', file.name.endsWith('.yaml') || file.name.endsWith('.yml') ? 'openapi' : 'postman');
      const res = await api.post('/connectors/parse', fd);
      setParseResult(res.data);
      setCollectionName(res.data.name || file.name);
      setBaseUrl(res.data.baseUrl || '');
      setActiveTab('preview');
      setShowImport(false);
    } catch (err) {
      alert('Parse error: ' + (err.response?.data?.error || err.message));
    }
    setIsParsing(false);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'application/json': ['.json'], 'application/x-yaml': ['.yaml', '.yml'] }, multiple: false });

  const pasteCurl = async (e) => {
    e.preventDefault();
    const curl = e.target.curl.value;
    if (!curl.trim()) return;
    setIsParsing(true);
    try {
      const res = await api.post('/connectors/parse', { curl, format: 'curl' }, { headers: { 'Content-Type': 'application/json' } });
      setParseResult(res.data);
      setCollectionName(res.data.name);
      setActiveTab('preview');
      setShowImport(false);
    } catch (err) { alert(err.response?.data?.error || err.message); }
    setIsParsing(false);
  };

  const saveCollection = async () => {
    if (!parseResult) return;
    setIsSaving(true);
    try {
      await api.post('/connectors', {
        name: collectionName,
        format: parseResult.format || 'postman',
        rawContent: parseResult.rawContent || JSON.stringify(parseResult),
        baseUrl,
        authType,
        authConfig: authType !== 'none' ? { token: authToken } : null,
        tools: parseResult.tools,
      });
      qc.invalidateQueries(['connectors']);
      setActiveTab('list');
      setParseResult(null);
      alert('Collection saved successfully!');
    } catch (err) { alert(err.response?.data?.error || err.message); }
    setIsSaving(false);
  };

  const toggleCollection = async (id, isActive) => {
    await api.patch(`/connectors/${id}/activate`, { is_active: !isActive });
    qc.invalidateQueries(['connectors']);
  };

  const deleteCollection = async (id) => {
    if (!confirm('Delete this collection and all its tools?')) return;
    await api.delete(`/connectors/${id}`);
    qc.invalidateQueries(['connectors']);
  };

  const toggleTool = async (toolId, isActive) => {
    await api.patch(`/connectors/tools/${toolId}`, { is_active: !isActive });
    setParseResult(prev => ({
      ...prev,
      tools: prev.tools.map(t => t.id === toolId ? { ...t, is_active: !isActive } : t)
    }));
  };

  const sendTestDrive = async (collectionId) => {
    if (!testMsg.trim()) return;
    const msg = testMsg;
    setTestMsg('');
    setTestHistory(p => [...p, { role: 'user', content: msg }]);
    setTestLoading(true);
    try {
      const res = await api.post(`/connectors/${collectionId}/test-drive`, { message: msg, history: testHistory });
      setTestHistory(p => [...p, { role: 'assistant', content: res.data.content, toolCalls: res.data.toolCalls }]);
    } catch { setTestHistory(p => [...p, { role: 'assistant', content: '⚠️ Test drive error' }]); }
    setTestLoading(false);
  };

  const riskColor = (r) => ({ low: 'risk-low', medium: 'risk-medium', high: 'risk-high' }[r] || 'risk-low');
  const warnIcon = (t) => t === 'warning' ? <AlertTriangle size={12}/> : t === 'error' ? <AlertTriangle size={12}/> : <Info size={12}/>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div>
          <div className="page-title">API Collections</div>
          <div className="page-subtitle">Upload and manage API connectors for AI tool calling</div>
        </div>
        <button className="btn btn-primary" onClick={() => setShowImport(true)}><Upload size={14}/>Import Collection</button>
      </div>

      <div className="page-content">
        <div className="tabs">
          {[['list','📦 Collections'], parseResult && ['preview','👁️ Preview & Linter']].filter(Boolean).map(([tab, label]) => (
            <div key={tab} className={`tab-item${activeTab === tab ? ' active' : ''}`} onClick={() => setActiveTab(tab)}>{label}</div>
          ))}
        </div>

        {activeTab === 'list' && (
          <div>
            {isLoading ? <div className="text-muted">Loading...</div> :
            collections.length === 0 ? (
              <div className="empty-state"><div className="empty-icon">🔌</div><div className="empty-title">No collections yet</div><div className="empty-desc">Import Postman Collection or OpenAPI spec to start connecting APIs to AI</div></div>
            ) : (
              <div style={{ display: 'grid', gap: 14 }}>
                {collections.map(c => (
                  <div key={c.id} className={`connector-card${c.is_active ? ' active' : ''}`}>
                    <div className="connector-header">
                      <div>
                        <div className="connector-name">{c.name}</div>
                        <div className="connector-meta">{c.format} · {c.active_tools || 0}/{c.tool_count_actual || 0} active tools · {c.base_url || 'no base URL'}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                        <div className={`toggle ${c.is_active ? 'on' : ''}`} onClick={() => toggleCollection(c.id, c.is_active)} title={c.is_active ? 'Deactivate' : 'Activate'}/>
                        <span className={`badge ${c.is_active ? 'badge-green' : 'badge-gray'}`}>{c.is_active ? 'Active' : 'Inactive'}</span>
                        <button className="btn btn-ghost btn-sm btn-icon" onClick={() => { setTestDriveOpen(testDriveOpen === c.id ? null : c.id); setTestHistory([]); }} title="Test Drive">
                          <Bot size={14}/>
                        </button>
                        <button className="btn btn-danger btn-sm btn-icon" onClick={() => deleteCollection(c.id)} title="Delete"><Trash2 size={14}/></button>
                      </div>
                    </div>

                    {/* Test Drive */}
                    {testDriveOpen === c.id && (
                      <div style={{ marginTop: 12, padding: 14, background: 'var(--bg-primary)', borderRadius: 8, border: '1px solid var(--border)' }}>
                        <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
                          <Bot size={12} style={{ color: 'var(--accent)' }}/>Test Drive — Conversation Simulation
                        </div>
                        <div style={{ minHeight: 80, maxHeight: 180, overflowY: 'auto', marginBottom: 8 }}>
                          {testHistory.length === 0 && <div className="text-muted text-sm" style={{ textAlign: 'center', paddingTop: 16 }}>Try asking something related to this collection...</div>}
                          {testHistory.map((m, i) => (
                            <div key={i} className={`chat-bubble ${m.role === 'user' ? 'customer' : 'ai'}`} style={{ marginBottom: 6, maxWidth: '85%', marginLeft: m.role === 'user' ? 0 : 'auto' }}>
                              {m.content}
                              {m.toolCalls?.length > 0 && m.toolCalls.map((tc, ti) => (
                                <div key={ti} className="tool-call" style={{ marginTop: 4 }}><span className="tool-call-name">⚡ {tc.tool}</span></div>
                              ))}
                            </div>
                          ))}
                          {testLoading && <div className="chat-bubble customer"><div className="typing-dots"><span/><span/><span/></div></div>}
                        </div>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <input className="form-input" value={testMsg} onChange={e => setTestMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendTestDrive(c.id)} placeholder="Type simulation message..."/>
                          <button className="btn btn-primary btn-sm" onClick={() => sendTestDrive(c.id)} disabled={testLoading}><Send size={12}/></button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {showImport && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 600, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="modal-header"><div className="modal-title">Import API Collection</div><button className="btn btn-ghost btn-sm" onClick={() => setShowImport(false)}>✕</button></div>
              <div className="card mb-4" style={{ background: 'var(--bg-primary)' }}>
                <div style={{ fontWeight: 600, marginBottom: 14 }}>Upload Collection File</div>
                <div {...getRootProps()} className={`drop-zone${isDragActive ? ' active' : ''}`}>
                  <input {...getInputProps()}/>
                  <div style={{ fontSize: 32, marginBottom: 10 }}>📁</div>
                  <div style={{ fontWeight: 600 }}>{isDragActive ? 'Drop file here...' : 'Drop file here or click to browse'}</div>
                  <div className="text-muted text-sm" style={{ marginTop: 4 }}>Postman Collection v2.1 (.json) · OpenAPI 3.0 (.json/.yaml)</div>
                  {isParsing && <div style={{ marginTop: 10, color: 'var(--accent)' }}>⏳ Analyzing collection...</div>}
                </div>
              </div>

              <div className="card" style={{ background: 'var(--bg-primary)' }}>
                <div style={{ fontWeight: 600, marginBottom: 14 }}>Paste cURL Command</div>
                <form onSubmit={pasteCurl}>
                  <textarea className="form-input form-textarea" name="curl" style={{ minHeight: 100, fontFamily: 'monospace', fontSize: 12 }} placeholder="curl -X GET 'https://api.example.com/products' -H 'Authorization: Bearer TOKEN'"/>
                  <button type="submit" className="btn btn-secondary" style={{ marginTop: 10 }} disabled={isParsing}>Parse cURL</button>
                </form>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'preview' && parseResult && (
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 16 }}>
              {/* Tools list */}
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 16 }}>{collectionName}</div>
                    <div className="text-muted text-sm">{parseResult.endpointCount} endpoints · {parseResult.warningCount} warnings</div>
                  </div>
                  <button className={`btn btn-primary${isSaving ? ' btn-loading' : ''}`} onClick={saveCollection} disabled={isSaving}>
                    {!isSaving && <><CheckCircle size={14}/>Save & Activate</>}
                  </button>
                </div>

                <div style={{ display: 'grid', gap: 10 }}>
                  {parseResult.tools?.map((tool, i) => (
                    <div key={i} style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 10, padding: 14 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                        <span style={{ fontFamily: 'monospace', fontSize: 11, padding: '2px 6px', borderRadius: 4, background: methodColor(tool.method), color: 'white', fontWeight: 700 }}>{tool.method}</span>
                        <span style={{ fontFamily: 'monospace', fontSize: 12, color: 'var(--text-secondary)' }}>{tool.endpoint}</span>
                        <span className={`risk-badge ${riskColor(tool.risk_level)}`} style={{ marginLeft: 'auto' }}>{tool.risk_level}</span>
                        <div className={`toggle ${tool.is_active !== false ? 'on' : ''}`} style={{ width: 28, height: 16 }} onClick={() => toggleTool(i, tool.is_active !== false)}/>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{tool.display_name}</div>
                      <textarea
                        className="form-input form-textarea" style={{ fontSize: 12, minHeight: 48 }}
                        value={tool.description}
                        onChange={e => setParseResult(prev => ({
                          ...prev,
                          tools: prev.tools.map((t, ti) => ti === i ? { ...t, description: e.target.value } : t)
                        }))}
                      />
                      {tool.linter_warnings?.map((w, wi) => (
                        <div key={wi} className={`linter-warning ${w.type}`}>{warnIcon(w.type)}<span>{w.message}</span></div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>

              {/* Config panel */}
              <div>
                <div className="card">
                  <div style={{ fontWeight: 600, marginBottom: 14 }}>Configuration</div>
                  <div className="form-group">
                    <label className="form-label">Collection Name</label>
                    <input className="form-input" value={collectionName} onChange={e => setCollectionName(e.target.value)}/>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Base URL</label>
                    <input className="form-input" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://api.example.com"/>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Authentication</label>
                    <select className="form-input form-select" value={authType} onChange={e => setAuthType(e.target.value)}>
                      <option value="none">None</option>
                      <option value="bearer">Bearer Token</option>
                      <option value="api_key">API Key</option>
                      <option value="basic">Basic Auth</option>
                    </select>
                  </div>
                  {authType !== 'none' && (
                    <div className="form-group">
                      <label className="form-label">Token / Key</label>
                      <input className="form-input" type="password" value={authToken} onChange={e => setAuthToken(e.target.value)} placeholder="sk-..."/>
                    </div>
                  )}
                </div>

                <div className="card" style={{ marginTop: 12 }}>
                  <div style={{ fontWeight: 600, marginBottom: 10 }}>Linter Summary</div>
                  {[
                    { color: 'danger', label: 'High Risk', count: parseResult.tools?.filter(t => t.risk_level === 'high').length || 0 },
                    { color: 'warning', label: 'Medium Risk', count: parseResult.tools?.filter(t => t.risk_level === 'medium').length || 0 },
                    { color: 'success', label: 'Low Risk', count: parseResult.tools?.filter(t => t.risk_level === 'low').length || 0 },
                    { color: 'text-muted', label: 'Total Warnings', count: parseResult.warningCount || 0 },
                  ].map(({ color, label, count }) => (
                    <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
                      <span>{label}</span><span className={`text-${color}`} style={{ fontWeight: 700 }}>{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function methodColor(m) {
  return { GET: '#22c55e', POST: '#6366f1', PUT: '#f59e0b', PATCH: '#f59e0b', DELETE: '#ef4444' }[m] || '#64748b';
}
