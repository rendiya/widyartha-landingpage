import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { Brain, Zap, Shield, Globe } from 'lucide-react';
import logoSvg from '../assets/logo.svg';

export default function LoginPage() {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const { login, isLoading, error } = useAuthStore();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const ok = await login(username, password);
    if (ok) navigate('/');
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg-primary)',
      backgroundImage: 'radial-gradient(ellipse at 20% 50%, rgba(13,148,136,0.08) 0%, transparent 50%), radial-gradient(ellipse at 80% 20%, rgba(45,212,191,0.06) 0%, transparent 50%)',
    }}>
      <div style={{ width: '100%', maxWidth: 420, padding: 24 }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <img src={logoSvg} alt="Widyartha" style={{ height: 40, width: 'auto', maxWidth: '100%', marginBottom: 16 }} />
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>AI-Powered Customer Service Platform</p>
        </div>

        {/* Features highlights */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 28 }}>
          {[
            { icon: <Brain size={14}/>, text: 'AI Tool Calling' },
            { icon: <Shield size={14}/>, text: 'Local-First' },
            { icon: <Zap size={14}/>, text: 'Zero Code Setup' },
            { icon: <Globe size={14}/>, text: 'Multi-Channel' },
          ].map(({ icon, text }) => (
            <div key={text} style={{
              background: 'var(--bg-card)', border: '1px solid var(--border)',
              borderRadius: 8, padding: '8px 12px',
              display: 'flex', alignItems: 'center', gap: 8,
              fontSize: 12, color: 'var(--text-secondary)',
            }}>
              <span style={{ color: 'var(--accent)' }}>{icon}</span>{text}
            </div>
          ))}
        </div>

        {/* Login form */}
        <div className="card">
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 20 }}>Log in to Dashboard</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Username</label>
              <input
                type="text" className="form-input"
                value={username} onChange={e => setUsername(e.target.value)}
                placeholder="admin" required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password" className="form-input"
                value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••" required
              />
            </div>

            {error && (
              <div style={{
                background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)',
                borderRadius: 8, padding: '10px 12px', marginBottom: 16,
                fontSize: 13, color: 'var(--danger)',
              }}>{error}</div>
            )}

            <button type="submit" className={`btn btn-primary btn-lg${isLoading ? ' btn-loading' : ''}`}
              style={{ width: '100%', justifyContent: 'center' }} disabled={isLoading}>
              {!isLoading && 'Log In'}
            </button>
          </form>
        </div>


      </div>
    </div>
  );
}
