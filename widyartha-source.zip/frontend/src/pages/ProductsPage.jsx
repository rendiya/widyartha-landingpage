import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { Plus, Trash2, Upload, Search } from 'lucide-react';

export default function ProductsPage() {
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', sku: '', category: '', price: '', stock: 0, description: '' });
  const [page, setPage] = useState(1);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['products', search, page],
    queryFn: () => api.get('/products', { params: { search, page, limit: 20 } }).then(r => r.data),
    keepPreviousData: true,
  });

  const { data: categories = [] } = useQuery({ queryKey: ['categories'], queryFn: () => api.get('/products/categories').then(r => r.data) });

  const addProduct = async (e) => {
    e.preventDefault();
    await api.post('/products', { ...form, price: parseFloat(form.price), stock: parseInt(form.stock) });
    qc.invalidateQueries(['products']);
    setShowAdd(false);
    setForm({ name: '', sku: '', category: '', price: '', stock: 0, description: '' });
  };

  const deleteProduct = async (id) => {
    if (!confirm('Delete this product?')) return;
    await api.delete(`/products/${id}`);
    qc.invalidateQueries(['products']);
  };

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('file', file);
    try {
      const res = await api.post('/products/import', fd);
      alert(`Import successful: ${res.data.imported} of ${res.data.total} products`);
      qc.invalidateQueries(['products']);
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };

  const products = data?.products || [];
  const total = data?.total || 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div><div className="page-title">Product Catalog</div><div className="page-subtitle">{total} total products (AI local fallback)</div></div>
        <div style={{ display: 'flex', gap: 8 }}>
          <label className="btn btn-secondary" style={{ cursor: 'pointer' }}><Upload size={14}/>Import CSV<input type="file" accept=".csv" style={{ display: 'none' }} onChange={handleImport}/></label>
          <button className="btn btn-primary" onClick={() => setShowAdd(true)}><Plus size={14}/>Add Product</button>
        </div>
      </div>

      <div className="page-content">
        {showAdd && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 600, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="modal-header"><div className="modal-title">Add Product</div><button className="btn btn-ghost btn-sm" onClick={() => setShowAdd(false)}>✕</button></div>
              <form onSubmit={addProduct}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                <div className="form-group"><label className="form-label">Product Name</label><input className="form-input" required value={form.name} onChange={e => setForm(p => ({...p, name: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">SKU</label><input className="form-input" value={form.sku} onChange={e => setForm(p => ({...p, sku: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Category</label><input className="form-input" list="cats" value={form.category} onChange={e => setForm(p => ({...p, category: e.target.value}))}/>
                  <datalist id="cats">{categories.map(c => <option key={c} value={c}/>)}</datalist>
                </div>
                <div className="form-group"><label className="form-label">Price (Rp)</label><input type="number" className="form-input" required value={form.price} onChange={e => setForm(p => ({...p, price: e.target.value}))}/></div>
                <div className="form-group"><label className="form-label">Stock</label><input type="number" className="form-input" value={form.stock} onChange={e => setForm(p => ({...p, stock: e.target.value}))}/></div>
              </div>
              <div className="form-group"><label className="form-label">Description</label><textarea className="form-input form-textarea" value={form.description} onChange={e => setForm(p => ({...p, description: e.target.value}))}/></div>
              <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                <button type="submit" className="btn btn-primary">Save</button>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAdd(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
        )}

        <div className="search-box mb-4"><Search size={14} style={{ color: 'var(--text-muted)' }}/><input placeholder="Search products..." value={search} onChange={e => setSearch(e.target.value)}/></div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%' }}>
            <thead><tr><th>Product</th><th>SKU</th><th>Category</th><th>Price</th><th>Stock</th><th>Action</th></tr></thead>
            <tbody>
              {isLoading ? <tr><td colSpan="6" style={{ textAlign: 'center', padding: 32 }}>Loading...</td></tr> :
              products.length === 0 ? <tr><td colSpan="6"><div className="empty-state" style={{ padding: 32 }}><div className="empty-icon">📦</div><div className="empty-desc">No products yet</div></div></td></tr> :
              products.map(p => (
                <tr key={p.id}>
                  <td><div style={{ fontWeight: 600 }}>{p.name}</div><div className="text-muted text-sm" style={{ fontSize: 11 }}>{p.description?.slice(0, 50)}{p.description?.length > 50 ? '...' : ''}</div></td>
                  <td><span style={{ fontFamily: 'monospace', fontSize: 12, color: 'var(--accent)' }}>{p.sku || '—'}</span></td>
                  <td><span className="badge badge-gray">{p.category || '—'}</span></td>
                  <td style={{ fontWeight: 600 }}>Rp {p.price?.toLocaleString('id-ID') || 0}</td>
                  <td><span className={`badge ${p.stock > 10 ? 'badge-green' : p.stock > 0 ? 'badge-yellow' : 'badge-red'}`}>{p.stock}</span></td>
                  <td><button className="btn btn-danger btn-sm btn-icon" onClick={() => deleteProduct(p.id)}><Trash2 size={13}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
