import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { CheckCircle, XCircle, RefreshCw, Eye } from 'lucide-react';

export default function LedgerPage() {
  const [activeTab, setActiveTab] = useState('pending_sync');
  const [selected, setSelected] = useState(null);
  const qc = useQueryClient();

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['ledger', activeTab],
    queryFn: () => api.get('/ledger', { params: { status: activeTab } }).then(r => r.data),
    refetchInterval: 15000,
  });

  const { data: stats } = useQuery({
    queryKey: ['ledger-stats'],
    queryFn: () => api.get('/ledger/stats/summary').then(r => r.data),
    refetchInterval: 30000,
  });

  const approve = async (id) => {
    try {
      await api.patch(`/ledger/${id}/approve`);
      qc.invalidateQueries(['ledger']);
      qc.invalidateQueries(['ledger-stats']);
      setSelected(null);
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };

  const reject = async (id) => {
    const reason = prompt('Reason for rejection:');
    if (!reason) return;
    await api.patch(`/ledger/${id}/reject`, { reason });
    qc.invalidateQueries(['ledger']);
    qc.invalidateQueries(['ledger-stats']);
    setSelected(null);
  };

  const items = data?.items || [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div>
          <div className="page-title">Local Ledger</div>
          <div className="page-subtitle">AI Order Buffer — review before syncing to customer database</div>
        </div>
        <button className="btn btn-secondary" onClick={() => refetch()}><RefreshCw size={14}/>Refresh</button>
      </div>

      <div className="page-content">
        {/* Stats */}
        <div className="stat-grid mb-6" style={{ gridTemplateColumns: 'repeat(5, 1fr)' }}>
          {[
            { label: 'Pending Sync', value: stats?.pending_sync || 0, color: 'warning', tab: 'pending_sync' },
            { label: 'Synced', value: stats?.synced || 0, color: 'success', tab: 'synced' },
            { label: 'Rejected', value: stats?.rejected || 0, color: 'danger', tab: 'rejected' },
            { label: 'Sync Failed', value: stats?.sync_failed || 0, color: 'danger', tab: 'sync_failed' },
            { label: 'Syncing', value: stats?.syncing || 0, color: 'blue', tab: 'syncing' },
          ].map(({ label, value, color, tab }) => (
            <div key={label} className="stat-card" style={{ cursor: 'pointer', border: activeTab === tab ? '1px solid var(--accent)' : '' }} onClick={() => setActiveTab(tab)}>
              <div className="stat-value" style={{ color: `var(--${color})`, fontSize: 24 }}>{value}</div>
              <div className="stat-label">{label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: selected ? '1fr 340px' : '1fr', gap: 16 }}>
          <div className="card" style={{ padding: 0 }}>
            <table style={{ width: '100%' }}>
              <thead><tr>
                <th>ID</th><th>Customer</th><th>Time</th><th>Status</th><th>Sync Target</th><th>Action</th>
              </tr></thead>
              <tbody>
                {isLoading ? <tr><td colSpan="6" style={{ textAlign: 'center', padding: 32 }}>Loading...</td></tr> :
                items.length === 0 ? <tr><td colSpan="6"><div className="empty-state"><div className="empty-icon">📋</div><div className="empty-desc">No data found with this status</div></div></td></tr> :
                items.map(item => (
                  <tr key={item.id} style={{ cursor: 'pointer' }} onClick={() => setSelected(item)}>
                    <td><span style={{ fontFamily: 'monospace', color: 'var(--accent)' }}>#{item.id}</span></td>
                    <td>{item.customer_name || 'Unknown'}</td>
                    <td className="text-muted text-sm">{new Date(item.created_at).toLocaleString('id-ID')}</td>
                    <td><StatusBadge status={item.sync_status}/></td>
                    <td className="text-muted text-sm">{item.sync_target || '—'}</td>
                    <td>
                      {item.sync_status === 'pending_sync' && (
                        <div style={{ display: 'flex', gap: 6 }} onClick={e => e.stopPropagation()}>
                          <button className="btn btn-success btn-sm" onClick={() => approve(item.id)}><CheckCircle size={12}/>Approve</button>
                          <button className="btn btn-danger btn-sm" onClick={() => reject(item.id)}><XCircle size={12}/>Reject</button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {selected && (
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <div style={{ fontWeight: 700 }}>Order Detail #{selected.id}</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setSelected(null)}>✕</button>
              </div>
              <div className="form-group">
                <label className="form-label">Customer</label>
                <div style={{ fontSize: 13 }}>{selected.customer_name} — {selected.phone}</div>
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <StatusBadge status={selected.sync_status}/>
              </div>
              <div className="form-group">
                <label className="form-label">Order Data</label>
                <pre style={{ background: 'var(--bg-primary)', padding: 12, borderRadius: 8, fontSize: 11, overflow: 'auto', maxHeight: 200, color: 'var(--text-secondary)' }}>
                  {JSON.stringify(selected.order_data, null, 2)}
                </pre>
              </div>
              {selected.notes && (
                <div className="form-group">
                  <label className="form-label">Notes</label>
                  <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{selected.notes}</div>
                </div>
              )}
              {selected.sync_status === 'pending_sync' && (
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-success" style={{ flex: 1 }} onClick={() => approve(selected.id)}><CheckCircle size={14}/>Approve & Sync</button>
                  <button className="btn btn-danger" style={{ flex: 1 }} onClick={() => reject(selected.id)}><XCircle size={14}/>Reject</button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    pending_sync: ['badge-yellow', '⏳ Pending Sync'],
    synced: ['badge-green', '✅ Synced'],
    rejected: ['badge-red', '❌ Rejected'],
    sync_failed: ['badge-red', '⚠️ Failed'],
    syncing: ['badge-blue', '🔄 Syncing'],
  };
  const [cls, label] = map[status] || ['badge-gray', status];
  return <span className={`badge ${cls}`}>{label}</span>;
}
