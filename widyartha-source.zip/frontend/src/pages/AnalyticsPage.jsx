import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';

export default function AnalyticsPage() {
  const [period, setPeriod] = useState('7d');

  const { data } = useQuery({
    queryKey: ['analytics', period],
    queryFn: () => api.get('/analytics/overview', { params: { period } }).then(r => r.data),
    refetchInterval: 60000,
  });

  const { data: health } = useQuery({
    queryKey: ['connector-health'],
    queryFn: () => api.get('/analytics/connector-health').then(r => r.data),
  });

  const t = data?.totals || {};

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div><div className="page-title">Analytics & Reporting</div><div className="page-subtitle">Metrik performa AI, CS, dan connector</div></div>
        <select className="form-input" style={{ width: 120 }} value={period} onChange={e => setPeriod(e.target.value)}>
          <option value="7d">7 Hari</option><option value="30d">30 Hari</option><option value="90d">90 Hari</option>
        </select>
      </div>

      <div className="page-content">
        <div className="stat-grid mb-6">
          {[
            { label: 'Total Sesi', value: t.total_sessions || 0, color: '#6366f1' },
            { label: 'AI Resolved', value: t.ai_resolved || 0, color: '#22c55e' },
            { label: 'Eskalasi', value: t.escalated || 0, color: '#f59e0b' },
            { label: 'AI Resolve Rate', value: `${t.ai_rate || 0}%`, color: '#6366f1' },
          ].map(({ label, value, color }) => (
            <div key={label} className="stat-card">
              <div className="stat-value" style={{ color }}>{value}</div>
              <div className="stat-label">{label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
          <div className="card">
            <div style={{ fontWeight: 600, marginBottom: 14 }}>📈 Tren Sesi Harian</div>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={data?.sessionsTrend || []}>
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}/>
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}/>
                <Tooltip contentStyle={{ background: '#1e2130', border: '1px solid #2a2d3e', borderRadius: 8, fontSize: 12 }}/>
                <Legend wrapperStyle={{ fontSize: 11 }}/>
                <Line type="monotone" dataKey="total" stroke="#6366f1" strokeWidth={2} dot={false} name="Total"/>
                <Line type="monotone" dataKey="ai_resolved" stroke="#22c55e" strokeWidth={2} dot={false} name="AI Resolved"/>
                <Line type="monotone" dataKey="escalated" stroke="#f59e0b" strokeWidth={2} dot={false} name="Eskalasi"/>
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="card">
            <div style={{ fontWeight: 600, marginBottom: 14 }}>⚡ Tool Usage Top 10</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={data?.toolUsage || []} layout="vertical">
                <XAxis type="number" tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}/>
                <YAxis type="category" dataKey="tool_name" tick={{ fontSize: 10, fill: '#94a3b8' }} tickLine={false} axisLine={false} width={100}/>
                <Tooltip contentStyle={{ background: '#1e2130', border: '1px solid #2a2d3e', borderRadius: 8, fontSize: 12 }}/>
                <Bar dataKey="calls" fill="#6366f1" radius={[0,4,4,0]} name="Panggilan"/>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', fontWeight: 600, borderBottom: '1px solid var(--border)' }}>👥 Performa CS Agent</div>
            <table style={{ width: '100%' }}>
              <thead><tr><th>CS Agent</th><th>Sesi</th><th>Avg Handle (menit)</th></tr></thead>
              <tbody>
                {data?.csPerformance?.length === 0 && <tr><td colSpan="3" style={{ textAlign: 'center', padding: 24, color: 'var(--text-muted)' }}>Belum ada data</td></tr>}
                {(data?.csPerformance || []).map(cs => (
                  <tr key={cs.id}>
                    <td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><div className="avatar sm">{cs.name?.[0]}</div>{cs.name}</div></td>
                    <td>{cs.sessions_handled}</td>
                    <td>{Math.round(cs.avg_handling_minutes || 0)}m</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="card" style={{ padding: 0 }}>
            <div style={{ padding: '14px 18px', fontWeight: 600, borderBottom: '1px solid var(--border)' }}>🔌 Connector Health</div>
            <table style={{ width: '100%' }}>
              <thead><tr><th>Connector</th><th>Calls</th><th>Success Rate</th><th>Avg (ms)</th></tr></thead>
              <tbody>
                {health?.length === 0 && <tr><td colSpan="4" style={{ textAlign: 'center', padding: 24, color: 'var(--text-muted)' }}>Belum ada data</td></tr>}
                {(health || []).map(h => (
                  <tr key={h.id}>
                    <td style={{ fontSize: 12, fontWeight: 600 }}>{h.name}</td>
                    <td>{h.total_calls || 0}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div className="progress-bar" style={{ width: 60 }}><div className="progress-fill" style={{ width: `${h.success_rate || 0}%`, background: h.success_rate >= 90 ? '#22c55e' : h.success_rate >= 70 ? '#f59e0b' : '#ef4444' }}/></div>
                        <span style={{ fontSize: 11 }}>{h.success_rate || 0}%</span>
                      </div>
                    </td>
                    <td className="text-muted text-sm">{Math.round(h.avg_duration || 0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
