import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { io } from 'socket.io-client';
import api from '../lib/api';
import { useAuthStore } from '../store/authStore';
import { Send, Bot, User, PhoneCall, Tag, Clock, Filter, Search } from 'lucide-react';

let socket;

function getSocket(token) {
  if (!socket) {
    socket = io('/', { auth: { token }, transports: ['websocket', 'polling'] });
  }
  return socket;
}

export default function InboxPage() {
  const { token, user } = useAuthStore();
  const [selectedSession, setSelectedSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);
  const [filter, setFilter] = useState({ status: 'active', mode: '', search: '' });
  const messagesEndRef = useRef(null);
  const qc = useQueryClient();

  const { data: sessionsData, refetch: refetchSessions } = useQuery({
    queryKey: ['sessions', filter],
    queryFn: () => api.get('/inbox/sessions', { params: filter }).then(r => r.data),
    refetchInterval: 10000,
  });

  const { data: sessionDetail } = useQuery({
    queryKey: ['session', selectedSession?.id],
    queryFn: () => api.get(`/inbox/sessions/${selectedSession.id}`).then(r => r.data),
    enabled: !!selectedSession?.id,
  });

  useEffect(() => {
    if (sessionDetail) {
      setMessages(sessionDetail.messages || []);
    }
  }, [sessionDetail]);

  useEffect(() => {
    const sock = getSocket(token);
    sock.on('new_message', (msg) => {
      setMessages(prev => {
        if (prev.find(m => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    });
    sock.on('ai_typing', ({ sessionId, typing }) => {
      if (selectedSession?.id === sessionId) setIsAiTyping(typing);
    });
    sock.on('session_updated', () => {
      qc.invalidateQueries({ queryKey: ['sessions'] });
    });
    return () => { sock.off('new_message'); sock.off('ai_typing'); sock.off('session_updated'); };
  }, [token, selectedSession, qc]);

  useEffect(() => {
    if (selectedSession?.id) {
      const sock = getSocket(token);
      sock.emit('join_session', selectedSession.id);
    }
  }, [selectedSession?.id, token]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!inputText.trim() || !selectedSession) return;
    const text = inputText;
    setInputText('');
    try {
      await api.post(`/inbox/sessions/${selectedSession.id}/send`, { content: text });
    } catch {}
  };

  const toggleMode = async (mode) => {
    if (!selectedSession) return;
    await api.patch(`/inbox/sessions/${selectedSession.id}/mode`, { mode });
    setSelectedSession(prev => ({ ...prev, mode }));
    qc.invalidateQueries(['sessions']);
  };

  const closeSession = async () => {
    if (!selectedSession) return;
    await api.patch(`/inbox/sessions/${selectedSession.id}/close`);
    setSelectedSession(null);
    refetchSessions();
  };

  const sessions = sessionsData?.sessions || [];

  const channelIcon = (type) => ({ whatsapp: '💬', telegram: '✈️', web: '🌐', messenger: '💙' }[type] || '💬');
  const modeColor = (mode) => mode === 'ai' ? 'badge-purple' : 'badge-blue';
  const statusColor = (status) => ({ active: 'badge-green', waiting: 'badge-yellow', done: 'badge-gray' }[status] || 'badge-gray');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div>
          <div className="page-title">Unified Inbox</div>
          <div className="page-subtitle">{sessions.length} percakapan {filter.status}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <select className="form-input" style={{ width: 120 }} value={filter.status} onChange={e => setFilter(p => ({ ...p, status: e.target.value }))}>
            <option value="active">Aktif</option>
            <option value="waiting">Menunggu</option>
            <option value="done">Selesai</option>
            <option value="">Semua</option>
          </select>
          <select className="form-input" style={{ width: 120 }} value={filter.mode} onChange={e => setFilter(p => ({ ...p, mode: e.target.value }))}>
            <option value="">Semua Mode</option>
            <option value="ai">🤖 AI</option>
            <option value="human">👤 Human</option>
          </select>
        </div>
      </div>

      <div className="inbox-layout">
        {/* Session list */}
        <div className="session-list">
          <div style={{ padding: '10px 12px', borderBottom: '1px solid var(--border)' }}>
            <div className="search-box">
              <Search size={14} style={{ color: 'var(--text-muted)' }}/>
              <input placeholder="Cari customer..." value={filter.search} onChange={e => setFilter(p => ({ ...p, search: e.target.value }))}/>
            </div>
          </div>
          {sessions.length === 0 ? (
            <div className="empty-state"><div className="empty-icon">📭</div><div className="empty-desc">Tidak ada percakapan</div></div>
          ) : sessions.map(s => (
            <div key={s.id} className={`session-item${selectedSession?.id === s.id ? ' active' : ''}`} onClick={() => setSelectedSession(s)}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                <span>{channelIcon(s.type || s.channel_type)}</span>
                <span className="session-name">{s.customer_name || 'Anonymous'}</span>
                <span className={`badge ${modeColor(s.mode)}`} style={{ marginLeft: 'auto', fontSize: 10 }}>
                  {s.mode === 'ai' ? '🤖' : '👤'}
                </span>
              </div>
              <div className="session-preview">{s.last_message || '...'}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                <span className={`badge ${statusColor(s.status)}`} style={{ fontSize: 10 }}>{s.status}</span>
                {s.unread_count > 0 && <span className="nav-badge red">{s.unread_count}</span>}
              </div>
            </div>
          ))}
        </div>

        {/* Chat area */}
        <div className="chat-area">
          {!selectedSession ? (
            <div className="empty-state" style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div className="empty-icon">💬</div>
              <div className="empty-title">Pilih percakapan</div>
              <div className="empty-desc">Klik sesi di sebelah kiri untuk mulai membalas</div>
            </div>
          ) : (
            <>
              {/* Chat header */}
              <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 10 }}>
                <div className="avatar">{sessionDetail?.session?.customer_name?.[0] || '?'}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{sessionDetail?.session?.customer_name}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{sessionDetail?.session?.channel_type} · {sessionDetail?.session?.phone}</div>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className={`btn btn-sm ${selectedSession.mode === 'ai' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => toggleMode('ai')}>
                    <Bot size={12}/>AI Mode
                  </button>
                  <button className={`btn btn-sm ${selectedSession.mode === 'human' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => toggleMode('human')}>
                    <User size={12}/>Human Mode
                  </button>
                  <button className="btn btn-sm btn-danger" onClick={closeSession}>Selesaikan</button>
                </div>
              </div>

              {/* Messages */}
              <div className="chat-messages">
                {messages.map((msg, i) => (
                  <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: msg.sender_type === 'customer' ? 'flex-start' : 'flex-end' }}>
                    {msg.sender_type === 'system' ? (
                      <div className="chat-bubble system">{msg.content}</div>
                    ) : (
                      <>
                        <div className={`chat-bubble ${msg.sender_type}`}>{msg.content}</div>
                        {msg.tool_calls && JSON.parse(msg.tool_calls || '[]').length > 0 && (
                          <div style={{ marginTop: 4 }}>
                            {JSON.parse(msg.tool_calls).map((tc, ti) => (
                              <div key={ti} className="tool-call">
                                <span className="tool-call-name">⚡ {tc.tool}</span>
                                {tc.status === 'error' && <span style={{ color: 'var(--danger)', marginLeft: 8 }}>Error</span>}
                              </div>
                            ))}
                          </div>
                        )}
                        <div className={`chat-time`} style={{ marginLeft: msg.sender_type !== 'customer' ? 'auto' : 0 }}>
                          {msg.sender_type === 'ai' ? '🤖 AI' : msg.sender_type === 'cs' ? `👤 ${msg.sender_name || 'CS'}` : ''}
                          {' '}{new Date(msg.sent_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </>
                    )}
                  </div>
                ))}
                {isAiTyping && (
                  <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                    <div className="chat-bubble customer"><div className="typing-dots"><span/><span/><span/></div></div>
                  </div>
                )}
                <div ref={messagesEndRef}/>
              </div>

              {/* Input */}
              {selectedSession.mode === 'human' && (
                <div className="chat-input-area">
                  <textarea
                    rows={1} value={inputText} onChange={e => setInputText(e.target.value)} placeholder="Ketik balasan..."
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
                  />
                  <button className="btn btn-primary btn-icon" onClick={sendMessage}><Send size={16}/></button>
                </div>
              )}
              {selectedSession.mode === 'ai' && (
                <div style={{ padding: '10px 16px', borderTop: '1px solid var(--border)', background: 'rgba(99,102,241,0.05)' }}>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', textAlign: 'center' }}>
                    🤖 AI sedang menangani percakapan ini. Klik <strong>Human Mode</strong> untuk ambil alih.
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Customer info panel */}
        {selectedSession && sessionDetail && (
          <div style={{ width: 240, borderLeft: '1px solid var(--border)', padding: 16, overflowY: 'auto' }}>
            <div style={{ fontWeight: 600, marginBottom: 14, fontSize: 13 }}>Info Customer</div>
            <div style={{ marginBottom: 12 }}>
              <div className="avatar lg" style={{ marginBottom: 8 }}>{sessionDetail.session?.customer_name?.[0] || '?'}</div>
              <div style={{ fontWeight: 600 }}>{sessionDetail.session?.customer_name}</div>
              <div className="text-muted text-sm">{sessionDetail.session?.phone}</div>
            </div>
            <div className="divider"/>
            {sessionDetail.memory && (
              <div>
                <div className="text-sm font-semibold" style={{ marginBottom: 6 }}>🧠 AI Memory</div>
                <div style={{ fontSize: 12, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{sessionDetail.memory.summary || 'Belum ada memory'}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
