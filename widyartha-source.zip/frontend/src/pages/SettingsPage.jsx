import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import api from '../lib/api';
import { useAuthStore } from '../store/authStore';

export default function SettingsPage() {
  const [saving, setSaving] = useState(false);
  const qc = useQueryClient();

  const { data: settings = {} } = useQuery({ queryKey: ['settings'], queryFn: () => api.get('/settings').then(r => r.data) });
  const { data: payments = [], refetch: refetchPayments } = useQuery({ queryKey: ['payments_manual'], queryFn: () => api.get('/payments/manual').then(r => r.data) });
  const [local, setLocal] = useState({});
  const [newPayment, setNewPayment] = useState({ bank_name: '', account_no: '', account_name: '', instructions: '' });
  const { user } = useAuthStore();

  const togglePayment = async (id, is_active) => {
    await api.put(`/payments/manual/${id}`, { is_active: !is_active });
    refetchPayments();
  };

  const addPayment = async (e) => {
    e.preventDefault();
    if (!newPayment.bank_name || !newPayment.account_no || !newPayment.account_name) return alert('Please fill required fields');
    await api.post('/payments/manual', newPayment);
    setNewPayment({ bank_name: '', account_no: '', account_name: '', instructions: '' });
    refetchPayments();
  };

  const merged = { ...settings, ...local };
  const set = (k, v) => setLocal(p => ({ ...p, [k]: v }));

  const save = async () => {
    setSaving(true);
    await api.patch('/settings', local);
    qc.invalidateQueries(['settings']);
    setLocal({});
    setSaving(false);
    alert('Settings saved!');
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div><div className="page-title">System Settings</div><div className="page-subtitle">Global configuration for Widyartha</div></div>
        <button className={`btn btn-primary${saving ? ' btn-loading' : ''}`} onClick={save} disabled={saving}>
          {!saving && 'Save Changes'}
        </button>
      </div>

      <div className="page-content" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', maxWidth: 1200 }}>
        <div>
          <div className="card mb-6">
            <div style={{ fontWeight: 700, marginBottom: 16 }}>🏢 Application Identity</div>
            <div className="form-group"><label className="form-label">Application Name</label><input className="form-input" value={merged.app_name || ''} onChange={e => set('app_name', e.target.value)}/></div>
          </div>

        <div className="card mb-6">
          <div style={{ fontWeight: 700, marginBottom: 16 }}>🕐 Operational Hours</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div className="form-group"><label className="form-label">Opening Time</label><input type="time" className="form-input" value={merged.operating_hours_start || '08:00'} onChange={e => set('operating_hours_start', e.target.value)}/></div>
            <div className="form-group"><label className="form-label">Closing Time</label><input type="time" className="form-input" value={merged.operating_hours_end || '17:00'} onChange={e => set('operating_hours_end', e.target.value)}/></div>
          </div>
          <div className="form-group">
            <label className="form-label">Outside Hours Mode</label>
            <select className="form-input form-select" value={merged.outside_hours_mode || 'auto_reply'} onChange={e => set('outside_hours_mode', e.target.value)}>
              <option value="auto_reply">Auto Reply</option><option value="ai_full">AI Full Handle</option><option value="disabled">Disabled</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Outside Hours Message</label>
            <textarea className="form-input form-textarea" value={merged.outside_hours_message || ''} onChange={e => set('outside_hours_message', e.target.value)}/>
          </div>
        </div>

        <div className="card mb-6">
          <div style={{ fontWeight: 700, marginBottom: 16 }}>🤖 AI Configuration</div>
          <div className="form-group">
            <label className="form-label">Confidence Threshold (%)</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <input type="range" min={0} max={100} value={merged.confidence_threshold || 75} onChange={e => set('confidence_threshold', e.target.value)} style={{ flex: 1 }}/>
              <span style={{ fontWeight: 700, color: 'var(--accent)', minWidth: 40 }}>{merged.confidence_threshold || 75}%</span>
            </div>
            <div className="text-muted text-sm" style={{ marginTop: 4 }}>Below this value, AI will auto-escalate to human CS</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div className="form-group"><label className="form-label">AI Memory Depth (sessions)</label><input type="number" className="form-input" value={merged.ai_memory_depth || 10} onChange={e => set('ai_memory_depth', e.target.value)} min={1} max={50}/></div>
            <div className="form-group"><label className="form-label">Memory Retention (days)</label><input type="number" className="form-input" value={merged.ai_memory_retention_days || 90} onChange={e => set('ai_memory_retention_days', e.target.value)} min={1} max={365}/></div>
          </div>
          <div className="form-group">
            <label className="form-label">CS Escalation Timeout (minutes)</label>
            <input type="number" className="form-input" value={merged.escalation_timeout_minutes || 30} onChange={e => set('escalation_timeout_minutes', e.target.value)} min={5} max={120}/>
          </div>
        </div>
        </div>
        
        <div>
          <div className="card mb-6">
          <div style={{ fontWeight: 700, marginBottom: 16 }}>💳 Manual Payment Methods</div>
          {payments.map(pm => (
            <div key={pm.id} className="p-3 border rounded mb-2 flex justify-between items-center bg-card">
              <div>
                <div className="font-bold">{pm.bank_name} - {pm.account_no}</div>
                <div className="text-sm text-muted">a.n {pm.account_name}</div>
                <div className="text-xs text-muted mt-1">{pm.instructions}</div>
              </div>
              <button 
                onClick={() => togglePayment(pm.id, pm.is_active)}
                className={`px-3 py-1 rounded text-xs font-medium ${pm.is_active ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}
              >
                {pm.is_active ? 'Active' : 'Inactive'}
              </button>
            </div>
          ))}
          {user?.role === 'super_admin' && (
            <form onSubmit={addPayment} className="mt-4 p-4 border border-dashed rounded bg-muted/20">
              <div className="font-bold mb-3 text-sm">Add New Payment Method</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <input required className="form-input text-sm" placeholder="Bank Name (e.g. BCA)" value={newPayment.bank_name} onChange={e => setNewPayment({...newPayment, bank_name: e.target.value})} style={{ padding: '8px' }} />
                <input required className="form-input text-sm" placeholder="Account Number" value={newPayment.account_no} onChange={e => setNewPayment({...newPayment, account_no: e.target.value})} style={{ padding: '8px' }} />
                <input required className="form-input text-sm" placeholder="Account Name (A.N)" value={newPayment.account_name} onChange={e => setNewPayment({...newPayment, account_name: e.target.value})} style={{ padding: '8px' }} />
                <input className="form-input text-sm" placeholder="Instructions (Optional)" value={newPayment.instructions} onChange={e => setNewPayment({...newPayment, instructions: e.target.value})} style={{ padding: '8px' }} />
              </div>
              <button type="submit" className="btn btn-primary btn-sm w-full">Add Payment Method</button>
            </form>
          )}
        </div>

          <div className="card" style={{ background: 'rgba(239,68,68,0.05)', borderColor: 'rgba(239,68,68,0.2)' }}>
            <div style={{ fontWeight: 700, marginBottom: 12, color: 'var(--danger)' }}>⚠️ Danger Zone</div>
            <button className="btn btn-danger" onClick={() => confirm('Reset all data? This cannot be undone!') && alert('Reset is disabled in demo.')}>Reset Database</button>
          </div>
        </div>
      </div>
    </div>
  );
}
