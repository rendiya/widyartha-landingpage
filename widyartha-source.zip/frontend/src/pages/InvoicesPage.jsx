import { useQuery } from '@tanstack/react-query';
import api from '../lib/api';

export default function InvoicesPage() {
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => api.get('/invoices').then(res => res.data),
  });

  if (isLoading) return <div className="p-8">Loading invoices...</div>;

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold">Invoices</h1>
          <p className="text-muted">Automatically generated invoices for accepted orders.</p>
        </div>
      </div>

      <div className="bg-card border rounded-lg overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted">
            <tr className="border-b">
              <th className="px-4 py-3 text-left">Invoice No</th>
              <th className="px-4 py-3 text-left">Customer</th>
              <th className="px-4 py-3 text-left">Amount Due</th>
              <th className="px-4 py-3 text-left">Status</th>
              <th className="px-4 py-3 text-left">Issued At</th>
              <th className="px-4 py-3 text-left">Paid At</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {invoices?.length === 0 ? (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-muted">No invoices found.</td></tr>
            ) : (
              invoices?.map(inv => (
                <tr key={inv.id} className="border-b hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{inv.invoice_number}</td>
                  <td className="px-4 py-3">{inv.customer_name} (Order #{inv.order_id})</td>
                  <td className="px-4 py-3">Rp {inv.amount_due?.toLocaleString() || 0}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      inv.status === 'paid' ? 'bg-green-500/10 text-green-500' : 
                      inv.status === 'void' ? 'bg-gray-500/10 text-gray-400' : 
                      'bg-yellow-500/10 text-yellow-500'
                    }`}>
                      {inv.status === 'void' ? 'void' : inv.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">{new Date(inv.issued_at).toLocaleString()}</td>
                  <td className="px-4 py-3">{inv.paid_at ? new Date(inv.paid_at).toLocaleString() : '-'}</td>
                  <td className="px-4 py-3 text-right">
                    <a 
                      href={`/api/invoices/${inv.id}/html`} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="btn btn-secondary btn-sm"
                      style={{ textDecoration: 'none', display: 'inline-block' }}
                    >
                      View Invoice
                    </a>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
