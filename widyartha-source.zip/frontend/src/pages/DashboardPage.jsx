import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import api from '../lib/api';
import { MessageCircle, Bot, AlertTriangle, Users, Plug, Zap, TrendingUp, Activity } from 'lucide-react';
import { useState } from 'react';

const COLORS = ['#6366f1', '#22c55e', '#f59e0b', '#ef4444'];

export default function DashboardPage() {
  const [aiMsg, setAiMsg] = useState('');
  const [aiHistory, setAiHistory] = useState([]);
  const [aiLoading, setAiLoading] = useState(false);

  const { data: stats } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: () => api.get('/dashboard/stats').then(r => r.data),
    refetchInterval: 30000,
  });

  const { data: activity } = useQuery({
    queryKey: ['dashboard-activity'],
    queryFn: () => api.get('/dashboard/recent-activity').then(r => r.data),
    refetchInterval: 15000,
  });

  const { data: activeSessions } = useQuery({
    queryKey: ['dashboard-active'],
    queryFn: () => api.get('/dashboard/active-sessions').then(r => r.data),
    refetchInterval: 10000,
  });

  const t = stats?.today || {};
  const trend = stats?.weeklyTrend || [];

  const sendAiMessage = async () => {
    if (!aiMsg.trim()) return;
    const msg = aiMsg;
    setAiMsg('');
    const newHistory = [...aiHistory, { role: 'user', content: msg }];
    setAiHistory(newHistory);
    setAiLoading(true);
    try {
      const res = await api.post('/llm/assistant', { message: msg, history: aiHistory });
      setAiHistory([...newHistory, { role: 'assistant', content: res.data.content }]);
    } catch {
      setAiHistory([...newHistory, { role: 'assistant', content: '⚠️ AI tidak tersedia saat ini.' }]);
    }
    setAiLoading(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
      <div className="page-header">
        <div>
          <div className="page-title">Dashboard</div>
          <div className="page-subtitle">Overview realtime sistem Widyartha</div>
        </div>
        <Link to="/inbox" className="btn btn-primary"><Inbox size={14}/>Buka Inbox</Link>
      </div>

      <div className="page-content" style={{ flex: 1, overflowY: 'auto' }}>
        {/* Stat cards */}
        <div className="stat-grid mb-6">
          {[
            { label: 'Total Chat Hari Ini', value: t.totalSessions ?? 0, icon: <MessageCircle size={18}/>, color: 'purple', sub: `${t.activeSessions ?? 0} aktif sekarang` },
            { label: 'Diselesaikan AI', value: t.aiHandled ?? 0, icon: <Bot size={18}/>, color: 'green', sub: `${t.totalSessions ? Math.round((t.aiHandled/t.totalSessions)*100) : 0}% AI resolve rate` },
            { label: 'Eskalasi ke CS', value: t.escalated ?? 0, icon: <AlertTriangle size={18}/>, color: 'orange', sub: 'Dialihkan ke manusia' },
            { label: 'Avg Response Time', value: `${t.avgResponseTime ?? 0}m`, icon: <Zap size={18}/>, color: 'blue', sub: 'Rata-rata waktu respons' },
            { label: 'Connector Aktif', value: stats?.connectors?.active ?? 0, icon: <Plug size={18}/>, color: 'purple', sub: `${stats?.connectors?.totalTools ?? 0} tools tersedia` },
          ].map(({ label, value, icon, color, sub }) => (
            <div key={label} className="stat-card">
              <div className={`stat-icon ${color}`}>{icon}</div>
              <div className="stat-value">{value}</div>
              <div className="stat-label">{label}</div>
              <div className="stat-change" style={{ color: 'var(--text-muted)' }}>{sub}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
          {/* Weekly trend chart */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <TrendingUp size={16} style={{ color: 'var(--accent)' }}/>
              <span style={{ fontWeight: 600 }}>Tren 7 Hari</span>
            </div>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={trend}>
                <defs>
                  <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="100%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}/>
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} tickLine={false} axisLine={false}/>
                <Tooltip contentStyle={{ background: '#1e2130', border: '1px solid #2a2d3e', borderRadius: 8, fontSize: 12 }}/>
                <Area type="monotone" dataKey="sessions" stroke="#6366f1" fill="url(#grad)" strokeWidth={2}/>
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Channel breakdown */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <Activity size={16} style={{ color: 'var(--accent)' }}/>
              <span style={{ fontWeight: 600 }}>Channel Breakdown</span>
            </div>
            {stats?.channelBreakdown?.length > 0 ? (
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={stats.channelBreakdown} dataKey="sessions" nameKey="type" cx="50%" cy="50%" outerRadius={60} label={({ type, percent }) => `${type} ${(percent*100).toFixed(0)}%`} labelLine={false}>
                    {stats.channelBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#1e2130', border: '1px solid #2a2d3e', borderRadius: 8, fontSize: 12 }}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="empty-state" style={{ padding: 24 }}>
                <div className="empty-icon">📊</div>
                <div className="empty-desc">Belum ada data hari ini</div>
              </div>
            )}
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Active Sessions */}
          <div className="card">
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <span style={{ fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
                <Users size={16} style={{ color: 'var(--accent)' }}/>Sesi Aktif
              </span>
              <Link to="/inbox" className="btn btn-ghost btn-sm">Lihat Semua</Link>
            </div>
            {activeSessions?.length > 0 ? activeSessions.slice(0, 5).map(s => (
              <div key={s.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <div className="avatar sm">{s.customer_name?.[0] || '?'}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{s.customer_name}</div>
                  <div className="truncate text-muted" style={{ fontSize: 11 }}>{s.last_message}</div>
                </div>
                <span className={`badge ${s.mode === 'ai' ? 'badge-purple' : 'badge-blue'}`}>{s.mode === 'ai' ? '🤖 AI' : '👤 CS'}</span>
              </div>
            )) : <div className="empty-state" style={{ padding: 24 }}><div className="empty-icon">💬</div><div className="empty-desc">Tidak ada sesi aktif</div></div>}
          </div>

          {/* AI Assistant */}
          <div className="card" style={{ display: 'flex', flexDirection: 'column', height: 320 }}>
            <div style={{ fontWeight: 600, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
              <Bot size={16} style={{ color: 'var(--accent)' }}/>AI Assistant
            </div>
            <div style={{ flex: 1, overflowY: 'auto', marginBottom: 10 }}>
              {aiHistory.length === 0 && (
                <div style={{ color: 'var(--text-muted)', fontSize: 12, textAlign: 'center', marginTop: 16 }}>
                  Tanya apapun tentang sistem, konfigurasi, atau analytics...
                </div>
              )}
              {aiHistory.map((m, i) => (
                <div key={i} className={`chat-bubble ${m.role === 'user' ? 'customer' : 'ai'}`} style={{ marginBottom: 8 }}>
                  {m.content}
                </div>
              ))}
              {aiLoading && <div className="chat-bubble customer"><div className="typing-dots"><span/><span/><span/></div></div>}
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <input className="form-input" style={{ flex: 1 }} value={aiMsg} onChange={e => setAiMsg(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendAiMessage()} placeholder="Ketik pertanyaan..."/>
              <button className="btn btn-primary btn-sm" onClick={sendAiMessage} disabled={aiLoading}>↑</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Inbox({ size }) { return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>; }
