import { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { io } from 'socket.io-client';
import api from '../lib/api';
import { Plus, Trash2, TestTube, Download, Edit } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

let socket;

function getSocket(token) {
  if (!socket) {
    socket = io('/', { auth: { token }, transports: ['websocket', 'polling'] });
  }
  return socket;
}

export default function LLMPage() {
  const [showAdd, setShowAdd] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const defaultForm = { name: '', provider: 'ollama', model: '', api_key: '', base_url: 'http://127.0.0.1:11434', is_active: false, threshold: 75, system_prompt: '' };
  const [form, setForm] = useState(defaultForm);
  const [testing, setTesting] = useState(null);
  const [testResult, setTestResult] = useState(null);
  const [pulling, setPulling] = useState({});

  const [showRuleModal, setShowRuleModal] = useState(false);
  const [editingRuleId, setEditingRuleId] = useState(null);
  const [ruleForm, setRuleForm] = useState({ rule_text: '', is_active: true });

  const [ruleToDelete, setRuleToDelete] = useState(null);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [showListModal, setShowListModal] = useState(false);
  const [modelToDelete, setModelToDelete] = useState(null);
  const [downloadModelName, setDownloadModelName] = useState('');
  const [useExternalUrl, setUseExternalUrl] = useState(false);

  const [fetchingModels, setFetchingModels] = useState(false);
  const [remoteModels, setRemoteModels] = useState({});

  const fetchRemoteModels = async () => {
    if (!form.api_key) return alert('Please enter API Key first');
    setFetchingModels(true);
    try {
      const res = await api.post('/llm/remote-models', { provider: form.provider, api_key: form.api_key, base_url: form.base_url });
      if (res.data.models && res.data.models.length > 0) {
        setRemoteModels(p => ({ ...p, [form.provider]: res.data.models }));
        if (!res.data.models.includes(form.model)) {
          setForm(p => ({ ...p, model: res.data.models[0] }));
        }
      } else {
        alert('No models found for this API Key.');
      }
    } catch (err) {
      alert(err.response?.data?.error || err.message);
    }
    setFetchingModels(false);
  };

  const [downloadProgress, setDownloadProgress] = useState(null);
  const { token } = useAuthStore();

  const qc = useQueryClient();

  const { data: configs = [] } = useQuery({ queryKey: ['llm-configs'], queryFn: () => api.get('/llm/configs').then(r => r.data) });
  const { data: status, refetch: refetchStatus } = useQuery({ queryKey: ['llm-status'], queryFn: () => api.get('/llm/status').then(r => r.data), refetchInterval: 5000 });
  const { data: rules = [] } = useQuery({ queryKey: ['system-rules'], queryFn: () => api.get('/llm/rules').then(r => r.data) });

  const saveConfig = async (e) => {
    e.preventDefault();
    if (editingId) {
      await api.patch(`/llm/configs/${editingId}`, form);
    } else {
      await api.post('/llm/configs', form);
    }
    qc.invalidateQueries(['llm-configs']);
    setShowAdd(false);
    setEditingId(null);
  };

  const openAdd = () => {
    setForm({
      ...defaultForm,
      base_url: 'http://ollama:11434',
      model: ''
    });
    setUseExternalUrl(false);
    setEditingId(null);
    setShowAdd(true);
  };

  const openEdit = (c) => {
    setForm(c);
    setUseExternalUrl(c.base_url !== 'http://ollama:11434' && c.base_url !== 'http://127.0.0.1:11434');
    setEditingId(c.id);
    setShowAdd(true);
  };

  const pullModel = async (config) => {
    setPulling(p => ({ ...p, [config.id]: true }));
    try {
      await api.post('/llm/pull', { model: config.model, base_url: config.base_url });
    } catch (e) { }
  };

  useEffect(() => {
    if (status?.models) {
      const newPulling = { ...pulling };
      let changed = false;
      Object.keys(pulling).forEach(key => {
        const c = configs.find(c => c.id == key);
        const modelName = c ? c.model : key;

        if (status.models.includes(modelName)) {
          delete newPulling[key];
          changed = true;
          // setTimeout(() => alert(`Model ${modelName} sudah selesai diunduh!`), 100);
        }
      });
      if (changed) setPulling(newPulling);
    }
  }, [status, configs, pulling]);

  useEffect(() => {
    const sock = getSocket(token);
    sock.on('model_download_progress', (data) => {
      setDownloadProgress(data);
      if (data.isCompleted) {
        setTimeout(() => {
          setDownloadProgress(null);
          refetchStatus();
        }, 5000); // hilangkan setelah 5 detik
      }
    });
    return () => { sock.off('model_download_progress'); };
  }, [token, refetchStatus]);

  const deleteConfig = async (id) => { await api.delete(`/llm/configs/${id}`); qc.invalidateQueries(['llm-configs']); };

  const requestDeleteModel = (modelName) => {
    setModelToDelete(modelName);
  };

  const confirmDeleteModel = async () => {
    if (!modelToDelete) return;
    try {
      await api.delete('/llm/model', { data: { model: modelToDelete } });
      refetchStatus();
      setModelToDelete(null);
    } catch (err) {
      alert(err.response?.data?.error || err.message);
    }
  };

  const activateConfig = async (id) => {
    await api.patch(`/llm/configs/${id}`, { ...configs.find(c => c.id === id), is_active: true });
    qc.invalidateQueries(['llm-configs']);
  };

  const testConfig = async (config) => {
    setTesting(config.id); setTestResult(null);
    try {
      const res = await api.post('/llm/test', { provider: config.provider, model: config.model, api_key: config.api_key, base_url: config.base_url });
      setTestResult({ id: config.id, success: true, response: res.data.response });
    } catch (err) { setTestResult({ id: config.id, success: false, error: err.response?.data?.error || err.message }); }
    setTesting(null);
  };

  const providerModels = {
    ollama: status?.models?.length > 0 ? status.models : ['(No models available yet)'],
    openai: ['gpt-4o', 'gpt-4o-mini', 'gpt-3.5-turbo'],
    anthropic: ['claude-sonnet-4-6', 'claude-3-5-haiku-20241022', 'claude-opus-4-5'],
    gemini: ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash'],
    sumopod: ['sumopod-model'],
  };

  const openAddRule = () => { setRuleForm({ rule_text: '', is_active: true }); setEditingRuleId(null); setShowRuleModal(true); };
  const openEditRule = (r) => { setRuleForm({ rule_text: r.rule_text, is_active: r.is_active === 1 }); setEditingRuleId(r.id); setShowRuleModal(true); };

  const saveRule = async (e) => {
    e.preventDefault();
    try {
      if (editingRuleId) {
        await api.patch(`/llm/rules/${editingRuleId}`, { ...ruleForm, is_active: ruleForm.is_active ? 1 : 0 });
      } else {
        await api.post('/llm/rules', { ...ruleForm, is_active: ruleForm.is_active ? 1 : 0 });
      }
      qc.invalidateQueries(['system-rules']);
      setShowRuleModal(false);
    } catch (err) { alert(err.response?.data?.error || err.message); }
  };

  const requestDeleteRule = (r) => {
    setRuleToDelete(r);
  };

  const confirmDeleteRule = async () => {
    if (!ruleToDelete) return;
    try {
      await api.delete(`/llm/rules/${ruleToDelete.id}`);
      qc.invalidateQueries(['system-rules']);
      setRuleToDelete(null);
    } catch (err) {
      alert(err.response?.data?.error || err.message);
    }
  };


  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div className="page-header">
        <div><div className="page-title">AI & LLM Config</div><div className="page-subtitle">Manage AI providers and tool calling configuration</div></div>
        <button className="btn btn-primary" onClick={openAdd}><Plus size={14} />Add Provider</button>
      </div>

      <div className="page-content">
        {/* Ollama Status */}
        <div className="card mb-6" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ fontSize: 24 }}>🦙</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600 }}>Ollama Status</div>
            <div className="text-muted text-sm">{status?.ollama ? `${status.models?.length} models available` : 'Not connected'}</div>
          </div>
          <span className={`badge ${status?.ollama ? 'badge-green' : 'badge-red'}`}>
            {status?.ollama ? '✅ Online' : '❌ Offline'}
          </span>
          {status?.ollama && (
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-secondary btn-sm" onClick={() => setShowListModal(true)}>
                View Models
              </button>
              <button className="btn btn-secondary btn-sm" onClick={() => setShowDownloadModal(true)}>
                <Download size={14} /> Download Model
              </button>
            </div>
          )}
        </div>

        {showListModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 500, maxHeight: '80vh', display: 'flex', flexDirection: 'column' }}>
              <div className="modal-header" style={{ marginBottom: 16 }}>
                <div className="modal-title">Ollama Models List</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowListModal(false)}>✕</button>
              </div>
              <div style={{ overflowY: 'auto', flex: 1, paddingRight: 4 }}>
                {status?.models?.length === 0 ? (
                  <div className="text-muted text-center py-4">No models downloaded yet.</div>
                ) : (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {status?.models?.map(m => (
                      <div key={m} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', border: '1px solid var(--border)', borderRadius: 8 }}>
                        <div style={{ fontWeight: 500, fontSize: 14 }}>{m}</div>
                        <button className="btn btn-danger btn-sm" onClick={() => requestDeleteModel(m)} title="Delete this model">
                          <Trash2 size={14} /> Delete
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {modelToDelete && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 400 }}>
              <div className="modal-header">
                <div className="modal-title">Confirm Deletion</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setModelToDelete(null)}>✕</button>
              </div>
              <div style={{ padding: '12px 0 24px' }}>
                Delete model <strong>{modelToDelete}</strong> from Ollama server? Deleted models must be re-downloaded to be used again.
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={() => setModelToDelete(null)}>Cancel</button>
                <button className="btn btn-danger" onClick={confirmDeleteModel}>Yes, Delete</button>
              </div>
            </div>
          </div>
        )}

        {showAdd && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 600, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="modal-header">
                <div className="modal-title">{editingId ? 'Edit LLM Provider' : 'Add LLM Provider'}</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowAdd(false)}>✕</button>
              </div>
              <form onSubmit={saveConfig}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="form-group"><label className="form-label">Name</label><input className="form-input" required value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} /></div>
                  <div className="form-group">
                    <label className="form-label">Provider</label>
                    <select className="form-input form-select" value={form.provider} onChange={e => {
                      const pName = e.target.value;
                      setForm(p => ({
                        ...p,
                        provider: pName,
                        model: '',
                        ...(pName === 'ollama' && !useExternalUrl ? { base_url: 'http://ollama:11434' } : {})
                      }));
                    }}>
                      <option value="ollama">Ollama (Local)</option>
                      <option value="openai">OpenAI</option>
                      <option value="anthropic">Anthropic Claude</option>
                      <option value="gemini">Google Gemini</option>
                      <option value="sumopod">Sumopod</option>
                    </select>
                  </div>
                  {form.provider !== 'ollama' && <div className="form-group"><label className="form-label">API Key</label><input type="password" className="form-input" value={form.api_key} onChange={e => setForm(p => ({ ...p, api_key: e.target.value }))} placeholder="sk-..." /></div>}
                  <div className="form-group">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                      <label className="form-label" style={{ marginBottom: 0 }}>Model</label>
                      {['gemini', 'openai', 'sumopod'].includes(form.provider) && (
                        <button type="button" className="btn btn-secondary btn-sm" onClick={fetchRemoteModels} disabled={fetchingModels}>
                          {fetchingModels ? 'Checking...' : 'Check Available Models'}
                        </button>
                      )}
                    </div>
                    <select className="form-input form-select" required value={form.model} onChange={e => setForm(p => ({ ...p, model: e.target.value }))}>
                      <option value="" disabled>Select Model...</option>
                      {(remoteModels[form.provider] || providerModels[form.provider] || []).map(m => (
                        <option key={m} value={m} disabled={m === '(No models available yet)'}>{m}</option>
                      ))}
                    </select>
                  </div>
                  {form.provider === 'ollama' && (
                    <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                        <input type="checkbox" id="useExt" checked={useExternalUrl} onChange={e => {
                          setUseExternalUrl(e.target.checked);
                          if (!e.target.checked) setForm(p => ({ ...p, base_url: 'http://ollama:11434' }));
                        }} />
                        <label htmlFor="useExt" style={{ margin: 0, cursor: 'pointer' }}>Use External URL (Ollama)</label>
                      </div>
                      {useExternalUrl && (
                        <div>
                          <label className="form-label">Base URL</label>
                          <input className="form-input" value={form.base_url} onChange={e => setForm(p => ({ ...p, base_url: e.target.value }))} placeholder="http://..." />
                        </div>
                      )}
                    </div>
                  )}
                  {form.provider === 'sumopod' && (
                    <div className="form-group" style={{ gridColumn: '1 / -1' }}>
                      <label className="form-label">Base URL</label>
                      <input className="form-input" value={form.base_url} onChange={e => setForm(p => ({ ...p, base_url: e.target.value }))} placeholder="https://api.sumopod.com/v1" />
                    </div>
                  )}
                  <div className="form-group"><label className="form-label">Confidence Threshold (%)</label><input type="number" className="form-input" value={form.threshold} onChange={e => setForm(p => ({ ...p, threshold: parseInt(e.target.value) }))} min={0} max={100} /></div>
                </div>
                <div className="form-group">
                  <label className="form-label">System Prompt (Persona AI)</label>
                  <textarea className="form-input form-textarea" value={form.system_prompt} onChange={e => setForm(p => ({ ...p, system_prompt: e.target.value }))} placeholder="AI persona instructions..." style={{ minHeight: 120 }} />
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                  <button type="submit" className="btn btn-primary">Save Configuration</button>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowAdd(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div style={{ display: 'grid', gap: 12 }}>
          {configs.map(c => (
            <div key={c.id} className={`card${c.is_active ? ' active' : ''}`} style={{ border: c.is_active ? '1px solid var(--accent)' : '' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ fontSize: 24 }}>{{ ollama: '🦙', openai: '🤖', anthropic: '🧠', gemini: '✨', sumopod: '☁️' }[c.provider] || '🤖'}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{c.name || c.provider}</div>
                  <div className="text-muted text-sm">{c.model} · threshold {c.threshold}%{c.is_fallback ? ' · fallback' : ''}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  {c.is_active && <span className="badge badge-green">✅ Active</span>}
                  {!c.is_active && <button className="btn btn-secondary btn-sm" onClick={() => activateConfig(c.id)}>Activate</button>}

                  {c.provider === 'ollama' && status?.ollama && !status?.models?.includes(c.model) && (
                    <button className="btn btn-primary btn-sm" onClick={() => pullModel(c)} disabled={pulling[c.id]} style={{ background: pulling[c.id] ? 'var(--gray-600)' : 'var(--accent)' }}>
                      <Download size={12} /> {pulling[c.id] ? 'Downloading...' : 'Download Model'}
                    </button>
                  )}

                  <button className="btn btn-secondary btn-sm" onClick={() => openEdit(c)}><Edit size={12} />Edit</button>

                  <button className={`btn btn-secondary btn-sm${testing === c.id ? ' btn-loading' : ''}`} onClick={() => testConfig(c)} disabled={testing === c.id}>
                    {testing !== c.id && <><TestTube size={12} />Test</>}
                  </button>
                  <button className="btn btn-danger btn-sm btn-icon" onClick={() => deleteConfig(c.id)}><Trash2 size={13} /></button>
                </div>
              </div>
              {testResult?.id === c.id && (
                <div style={{ marginTop: 10, padding: 10, borderRadius: 8, background: testResult.success ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)', border: `1px solid ${testResult.success ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'}`, fontSize: 12 }}>
                  {testResult.success ? `✅ ${testResult.response}` : `❌ ${testResult.error}`}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-8 mb-4" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontWeight: 600, fontSize: 16 }}>System Guardrails</div>
            <div className="text-muted text-sm">Anti-hallucination rules that will be automatically appended to every chat session</div>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={openAddRule}><Plus size={14} /> Add Rule</button>
        </div>

        <div className="card" style={{ padding: 0 }}>
          <table style={{ width: '100%' }}>
            <thead>
              <tr>
                <th style={{ width: 40 }}>#</th>
                <th>Rule Content</th>
                <th style={{ width: 100 }}>Status</th>
                <th style={{ width: 150, textAlign: 'right' }}>Action</th>
              </tr>
            </thead>
            <tbody>
              {rules.length === 0 ? (
                <tr><td colSpan="4" style={{ textAlign: 'center', padding: 20 }}>No system rules yet</td></tr>
              ) : (
                rules.map((r, i) => (
                  <tr key={r.id}>
                    <td>{i + 1}</td>
                    <td style={{ opacity: r.is_active ? 1 : 0.5 }}>{r.rule_text}</td>
                    <td>{r.is_active ? <span className="badge badge-green">Active</span> : <span className="badge badge-gray">Inactive</span>}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                        <button className="btn btn-secondary btn-sm btn-icon" onClick={() => openEditRule(r)}><Edit size={13} /></button>
                        <button className="btn btn-danger btn-sm btn-icon" onClick={() => requestDeleteRule(r)}><Trash2 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {ruleToDelete && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 400 }}>
              <div className="modal-header">
                <div className="modal-title">Confirm Deletion</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setRuleToDelete(null)}>✕</button>
              </div>
              <div style={{ padding: '12px 0 24px' }}>
                Are you sure you want to delete this rule?
                <div style={{ marginTop: 8, padding: 8, background: 'var(--muted)', borderRadius: 4, fontStyle: 'italic', fontSize: 14 }}>
                  "{ruleToDelete.rule_text}"
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={() => setRuleToDelete(null)}>Cancel</button>
                <button className="btn btn-danger" onClick={confirmDeleteRule}>Yes, Delete</button>
              </div>
            </div>
          </div>
        )}

        {showRuleModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 500 }}>
              <div className="modal-header">
                <div className="modal-title">{editingRuleId ? 'Edit Rule' : 'Add Rule'}</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowRuleModal(false)}>✕</button>
              </div>
              <form onSubmit={saveRule}>
                <div className="form-group">
                  <label className="form-label">Rule Text</label>
                  <textarea className="form-input form-textarea" required value={ruleForm.rule_text} onChange={e => setRuleForm(p => ({ ...p, rule_text: e.target.value }))} rows={4} placeholder="Example: NEVER make up data..." />
                </div>
                <div className="form-group" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <input type="checkbox" id="is_active" checked={ruleForm.is_active} onChange={e => setRuleForm(p => ({ ...p, is_active: e.target.checked }))} />
                  <label htmlFor="is_active" style={{ margin: 0, cursor: 'pointer' }}>Active Rule</label>
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                  <button type="submit" className="btn btn-primary">Save Rule</button>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowRuleModal(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showDownloadModal && (
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.6)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div className="card" style={{ width: '100%', maxWidth: 500 }}>
              <div className="modal-header">
                <div className="modal-title">Download LLM (Ollama)</div>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowDownloadModal(false)}>✕</button>
              </div>
              <form onSubmit={async (e) => {
                e.preventDefault();
                if (!downloadModelName.trim()) return;
                setPulling(p => ({ ...p, [downloadModelName.trim()]: true }));
                setDownloadProgress({ model: downloadModelName.trim(), status: 'Starting...', progress: 0, isCompleted: false });
                try {
                  await api.post('/llm/pull', { model: downloadModelName.trim() });
                } catch (err) { }
                setShowDownloadModal(false);
                setDownloadModelName('');
              }}>
                <div className="form-group">
                  <label className="form-label">Model Name</label>
                  <input className="form-input" required value={downloadModelName} onChange={e => setDownloadModelName(e.target.value)} placeholder="Example: llama3:8b, mistral, etc..." />
                  <div className="text-muted text-sm mt-1">Model will be downloaded in the background. You will receive a notification when finished.</div>
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
                  <button type="submit" className="btn btn-primary">Start Download</button>
                  <button type="button" className="btn btn-secondary" onClick={() => setShowDownloadModal(false)}>Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Progress Modal Floating di Pojok Kiri Bawah */}
        {downloadProgress && (
          <div className="card" style={{
            position: 'fixed',
            bottom: 20,
            left: 20,
            width: 320,
            zIndex: 9999,
            boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)',
            border: '1px solid var(--border)',
            padding: 16
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>Downloading: {downloadProgress.model}</div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{downloadProgress.status}</div>
              </div>
              <button className="btn btn-ghost btn-sm btn-icon" onClick={() => setDownloadProgress(null)} style={{ margin: '-4px' }}>✕</button>
            </div>

            <div style={{ width: '100%', height: 6, backgroundColor: 'var(--gray-200)', borderRadius: 3, overflow: 'hidden', marginBottom: 8 }}>
              <div style={{
                height: '100%',
                backgroundColor: downloadProgress.status === 'error' ? 'var(--danger)' : downloadProgress.isCompleted ? 'var(--success)' : 'var(--accent)',
                width: `${downloadProgress.progress || 0}%`,
                transition: 'width 0.3s ease'
              }} />
            </div>

            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text-muted)' }}>
              <span>{downloadProgress.progress || 0}%</span>
              {downloadProgress.total ? (
                <span>{(downloadProgress.completed / 1024 / 1024 / 1024).toFixed(2)} GB / {(downloadProgress.total / 1024 / 1024 / 1024).toFixed(2)} GB</span>
              ) : null}
            </div>

            {downloadProgress.status === 'error' && (
              <div style={{ marginTop: 8, fontSize: 12, color: 'var(--danger)' }}>
                Error: {downloadProgress.error}
              </div>
            )}

            {downloadProgress.isCompleted && downloadProgress.status !== 'error' && (
              <div style={{ marginTop: 8, fontSize: 12, color: 'var(--success)', fontWeight: 500 }}>
                ✅ Download Complete!
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
