import re, base64
with open('frontend/src/assets/logo.svg', 'r') as f:
    svg = f.read()
match = re.search(r'base64,(.*?)(\"|\')', svg)
if match:
    with open('temp.png', 'wb') as f:
        f.write(base64.b64decode(match.group(1)))
    print("Extracted to temp.png")
else:
    print("No base64 found")
